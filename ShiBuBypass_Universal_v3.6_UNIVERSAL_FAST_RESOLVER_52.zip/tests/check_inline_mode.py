from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / "lib" / "main.dart").read_text()
native = (root / "android_patch" / "NativeInlineWebView.kt").read_text()
activity = (root / "android_patch" / "MainActivity.kt").read_text()

checks = {
    "inline AndroidView exists": "viewType: _nativeInlineWebViewType" in main,
    "Link4m .org supported": "h == 'link4m.org'" in main,
    "Link4m .net supported": "h == 'link4m.net'" in main,
    "resolve tries public redirects first": "final probe = await _probeRedirect(client, uri);" in main,
    "paste uses fast resolver first": "Universal Fast Resolver: always try public redirect resolution first" in main,
    "HTML meta refresh supported": "metaTags = RegExp" in main and "HTML/JS redirect" in main,
    "simple JS navigation supported": "location\.(?:replace|assign)" in main,
    "main-frame poll avoids popup capture": "currentMainUrl" in main and '"currentMainUrl" -> result.success(mainWebView.url)' in native,
    "native view registered": 'registerViewFactory(' in activity and 'shibu/native_inline_webview' in activity,
    "stock UA preserved": 'userAgentString =' not in native,
    "third-party cookies enabled": "setAcceptThirdPartyCookies(target, true)" in native,
    "popup supported": "onCreateWindow" in native,
    "verification UI detection event": 'verificationState' in native and 'detectVerificationUi' in native,
    "auto captures final URL": "Đã bắt và sao chép URL đích" in main and "_capturedFinalUrl" in main,
    "no CAPTCHA automation hooks": all(x not in native.lower() for x in ["grecaptcha.execute", "captcha token", "recaptcha token", ".click()", "dispatchEvent"]),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit("Static checks failed: " + ", ".join(failed))
