import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const ShiBuApp());
}

const _mint = Color(0xFF63F3C1);
const _cyan = Color(0xFF3BCFE7);
const _deep = Color(0xFF071416);
const _panel = Color(0xFF102326);
const _panel2 = Color(0xFF172A34);

const _nativeWebViewChannel = MethodChannel('shibu/native_webview');

class ShiBuApp extends StatelessWidget {
  const ShiBuApp({super.key});

  @override
  Widget build(BuildContext context) {
    final scheme = ColorScheme.fromSeed(
      seedColor: _mint,
      brightness: Brightness.dark,
      surface: _panel,
    );
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ShiBu Bypass',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: scheme,
        scaffoldBackgroundColor: _deep,
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: _panel2,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: Color(0x334EF2C0)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(18),
            borderSide: const BorderSide(color: _mint, width: 1.5),
          ),
        ),
        snackBarTheme: const SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class RedirectHop {
  final Uri uri;
  final int? statusCode;
  final String kind;

  const RedirectHop(this.uri, {this.statusCode, required this.kind});
}

class LinkAssessment {
  final String label;
  final String detail;
  final bool manualVerificationLikely;
  final bool sensitiveParameters;

  const LinkAssessment({
    required this.label,
    required this.detail,
    this.manualVerificationLikely = false,
    this.sensitiveParameters = false,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with WidgetsBindingObserver {
  final _controller = TextEditingController();
  final List<RedirectHop> _hops = [];
  List<String> _history = [];
  bool _busy = false;
  Uri? _current;
  String _status = 'Sẵn sàng nhận link';
  LinkAssessment _assessment = const LinkAssessment(
    label: 'Chưa phân loại',
    detail: 'Dán hoặc nhập URL để app nhận diện loại link.',
  );
  int _tab = 0;
  static const MethodChannel _shareChannel = MethodChannel('shibu/share');
  bool _consumingShare = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (Platform.isAndroid) {
      _shareChannel.setMethodCallHandler((call) async {
        if (call.method == 'sharedText' && call.arguments is String) {
          await _handleSharedText(call.arguments as String, source: 'Chrome');
        }
      });
    }
    _loadHistory();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      unawaited(_consumeAndroidShare());
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_consumeAndroidShare());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    if (Platform.isAndroid) {
      _shareChannel.setMethodCallHandler(null);
    }
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadHistory() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _history = prefs.getStringList('history') ?? []);
  }

  Future<void> _saveHistory(String url) async {
    final next = <String>[url, ..._history.where((e) => e != url)].take(30).toList();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('history', next);
    if (mounted) setState(() => _history = next);
  }

  Uri? _parseInput(String raw) {
    var value = raw.trim();
    if (value.isEmpty) return null;
    if (!value.contains('://')) value = 'https://$value';
    final uri = Uri.tryParse(value);
    if (uri == null || !{'http', 'https'}.contains(uri.scheme.toLowerCase())) return null;
    if (uri.host.isEmpty || uri.userInfo.isNotEmpty) return null;
    return uri;
  }

  bool _isLikelyIntermediatePage(Uri uri) {
    final host = uri.host.toLowerCase();
    final path = uri.path.toLowerCase();

    // Known examples where the visible page is commonly a gate/intermediate page.
    // This only changes UI classification; it does not skip or automate verification.
    if ((host == 'link4m.org' || host.endsWith('.link4m.org')) &&
        (path.startsWith('/go/') || path.contains('/verify'))) {
      return true;
    }

    const manualPathHints = <String>[
      '/captcha', '/challenge', '/verify', '/verification', '/checkpoint',
    ];
    return manualPathHints.any(path.contains);
  }

  bool _meaningfullyDifferent(Uri a, Uri b) {
    String cleanHost(Uri u) => u.host.toLowerCase().replaceFirst(RegExp(r'^www\.'), '');
    final sameHost = cleanHost(a) == cleanHost(b);
    final samePath = a.path == b.path;
    final sameQuery = a.query == b.query;
    return !(sameHost && samePath && sameQuery);
  }

  LinkAssessment _assessUri(Uri uri) {
    final host = uri.host.toLowerCase();
    final path = uri.path.toLowerCase();
    final keys = uri.queryParameters.keys.map((e) => e.toLowerCase()).toSet();

    final sensitiveKeys = <String>{
      'token', 'access_token', 'id_token', 'code', 'state', 'key', 'ticket',
      'session', 'session_id', 'auth', 'authorization', 'sig', 'signature',
      'd', 'jwt', 'nonce', 'api_key',
    };
    final hasSensitive = keys.any(sensitiveKeys.contains);

    if (_isLikelyIntermediatePage(uri)) {
      return LinkAssessment(
        label: 'Trang trung gian · cần xác minh',
        detail: 'URL hiện tại vẫn là trang trung gian. Hãy mở trang và hoàn thành thủ công CAPTCHA/mã/timer hoặc bước xác minh nếu website yêu cầu; app chỉ ghi nhận URL sau khi trang thật sự chuyển tiếp.',
        manualVerificationLikely: true,
        sensitiveParameters: hasSensitive,
      );
    }

    if (_knownWrapperTarget(uri) != null) {
      return LinkAssessment(
        label: 'Link-wrapper mạng xã hội',
        detail: 'Có URL đích nằm trong tham số của trang trung gian và có thể tách tự động.',
        sensitiveParameters: hasSensitive,
      );
    }

    const shortHosts = <String>{
      'bit.ly', 't.co', 'tinyurl.com', 'cutt.ly', 'is.gd', 'rb.gy',
      'shorturl.at', 'tiny.one', 'rebrand.ly', 'buff.ly', 'ow.ly',
      'vm.tiktok.com', 'youtu.be',
    };
    if (shortHosts.contains(host)) {
      return LinkAssessment(
        label: 'Shortlink / redirect',
        detail: 'Thường có thể lần theo chuỗi HTTP redirect để tìm URL cuối.',
        sensitiveParameters: hasSensitive,
      );
    }

    final authHost = host.startsWith('auth.') ||
        host.contains('.auth.') ||
        host.startsWith('login.') ||
        host.startsWith('sso.');
    final authPath = <String>['/auth', '/authorize', '/oauth', '/login', '/signin', '/verify', '/verification']
        .any(path.contains);
    final authKeys = <String>{
      'client_id', 'redirect_uri', 'response_type', 'scope', 'code', 'state',
      'token', 'access_token', 'ticket', 'session', 'd',
    };
    final authQuery = keys.any(authKeys.contains);

    if (authHost || authPath || (authQuery && hasSensitive)) {
      return LinkAssessment(
        label: 'Link xác thực / phiên',
        detail: hasSensitive
            ? 'Phát hiện tham số phiên hoặc xác thực. App không hiển thị giá trị token và có thể yêu cầu bạn xác minh thủ công trong WebView.'
            : 'Đường dẫn có dấu hiệu đăng nhập/xác thực và có thể yêu cầu thao tác thủ công.',
        manualVerificationLikely: true,
        sensitiveParameters: hasSensitive,
      );
    }

    final redirectKeys = <String>{
      'url', 'u', 'q', 'target', 'destination', 'redirect', 'redirect_url',
      'return', 'return_url', 'continue', 'next', 'goto', 'dest',
    };
    final looksLikeRedirect = path.contains('redirect') || path.contains('/go/') || keys.any(redirectKeys.contains);
    if (looksLikeRedirect) {
      final likelyManual = path.contains('/go/') || path.contains('verify');
      return LinkAssessment(
        label: likelyManual ? 'Trang trung gian / redirect' : 'Link chuyển tiếp',
        detail: likelyManual
            ? 'Có dấu hiệu là trang trung gian động. Nếu HTTP redirect chưa đưa sang trang khác, hãy mở trang và hoàn thành bước xác minh thủ công.'
            : 'Có dấu hiệu là redirect. App sẽ thử theo HTTP redirect và ghi lại từng bước.',
        manualVerificationLikely: likelyManual,
        sensitiveParameters: hasSensitive,
      );
    }

    return LinkAssessment(
      label: 'Web URL thông thường',
      detail: 'Không phát hiện mẫu auth hoặc link-wrapper đặc biệt. App vẫn có thể kiểm tra HTTP redirect.',
      sensitiveParameters: hasSensitive,
    );
  }

  void _classifyInput(String raw) {
    final uri = _parseInput(raw);
    final next = uri == null
        ? const LinkAssessment(
            label: 'Chưa phân loại',
            detail: 'URL chưa hợp lệ hoặc chưa đầy đủ.',
          )
        : _assessUri(uri);
    if (mounted) setState(() => _assessment = next);
  }

  Uri? _knownWrapperTarget(Uri uri) {
    final host = uri.host.toLowerCase();
    final path = uri.path.toLowerCase();
    final allowedWrapper =
        host == 'l.facebook.com' ||
        host == 'lm.facebook.com' ||
        host == 'l.messenger.com' ||
        host == 'l.instagram.com' ||
        ((host == 'www.google.com' || host == 'google.com') && path == '/url') ||
        ((host == 'youtube.com' || host == 'www.youtube.com') && path == '/redirect') ||
        (host == 'discord.com' && path.contains('redirect'));
    if (!allowedWrapper) return null;

    for (final key in const ['u', 'url', 'q', 'target', 'redirect_url', 'destination']) {
      final value = uri.queryParameters[key];
      if (value == null || value.isEmpty) continue;
      final parsed = _parseInput(value);
      if (parsed != null) return parsed;
    }
    return null;
  }

  Future<http.StreamedResponse> _headOrTinyGet(http.Client client, Uri uri) async {
    final head = http.Request('HEAD', uri)
      ..followRedirects = false
      ..headers['User-Agent'] = 'ShiBuResolver/3.6';
    try {
      final response = await client.send(head).timeout(const Duration(seconds: 12));
      if (response.statusCode != 405 && response.statusCode != 501) return response;
    } catch (_) {
      // Fall back to a tiny GET for servers that do not support HEAD.
    }
    final get = http.Request('GET', uri)
      ..followRedirects = false
      ..headers['Range'] = 'bytes=0-0'
      ..headers['User-Agent'] = 'ShiBuResolver/3.6';
    return client.send(get).timeout(const Duration(seconds: 12));
  }

  Uri? _extractSharedUrl(String raw) {
    final direct = _parseInput(raw);
    if (direct != null) return direct;
    final match = RegExp(r'''https?://[^\s<>\"']+''').firstMatch(raw);
    if (match == null) return null;
    return _parseInput(match.group(0) ?? '');
  }

  Future<void> _handleSharedText(String shared, {required String source}) async {
    if (!mounted || shared.trim().isEmpty) return;
    final uri = _extractSharedUrl(shared);
    if (uri == null) {
      _toast('Nội dung được chia sẻ không có URL http/https hợp lệ.');
      return;
    }
    await _continueFromVerifiedUrl(uri, source: source);
  }

  Future<void> _consumeAndroidShare() async {
    if (!Platform.isAndroid || _consumingShare || !mounted) return;
    _consumingShare = true;
    try {
      final shared = await _shareChannel.invokeMethod<String>('getSharedText');
      if (shared == null || shared.trim().isEmpty || !mounted) return;
      await _handleSharedText(shared, source: 'Chrome');
    } on MissingPluginException {
      // Desktop/iOS builds do not install the Android share bridge.
    } catch (_) {
      if (mounted) _toast('Không đọc được URL được chia sẻ.');
    } finally {
      _consumingShare = false;
    }
  }

  Future<void> _continueFromVerifiedUrl(Uri uri, {required String source}) async {
    if (!mounted) return;
    setState(() {
      _tab = 0;
      _controller.text = uri.toString();
      _current = uri;
      _assessment = _assessUri(uri);
      _status = 'Đã nhận URL sau xác minh từ $source · đang tiếp tục…';
    });
    await _saveHistory(uri.toString());
    await _resolve();
    if (!mounted || _current == null) return;

    final current = _current!;
    final manual = _isLikelyIntermediatePage(current) || _assessment.manualVerificationLikely;
    if (manual) {
      setState(() {
        _status = '⚠️ URL nhận về vẫn là trang trung gian — chưa có URL đích';
      });
      return;
    }

    await Clipboard.setData(ClipboardData(text: current.toString()));
    if (mounted) {
      setState(() => _status = '✅ Đã tiếp tục sau xác minh và sao chép URL cuối');
    }
    _toast('Đã sao chép URL cuối.');
  }

  Future<void> _resolve() async {
    final start = _parseInput(_controller.text);
    if (start == null) {
      _toast('Link không hợp lệ. Chỉ hỗ trợ http/https.');
      return;
    }

    FocusScope.of(context).unfocus();
    setState(() {
      _busy = true;
      _hops.clear();
      _current = start;
      _assessment = _assessUri(start);
      _status = 'Đang phân tích redirect…';
    });

    final client = http.Client();
    var uri = start;
    final seen = <String>{};

    try {
      for (var i = 0; i < 20; i++) {
        if (!seen.add(uri.toString())) {
          _hops.add(RedirectHop(uri, kind: 'Phát hiện vòng lặp'));
          _status = 'Dừng vì redirect lặp';
          break;
        }

        final wrapper = _knownWrapperTarget(uri);
        if (wrapper != null && wrapper != uri) {
          _hops.add(RedirectHop(uri, kind: 'Link-wrapper mạng xã hội'));
          uri = wrapper;
          _current = uri;
          _assessment = _assessUri(uri);
          continue;
        }

        final response = await _headOrTinyGet(client, uri);
        final status = response.statusCode;
        final location = response.headers['location'];
        _hops.add(RedirectHop(uri, statusCode: status, kind: 'HTTP'));
        unawaited(response.stream.drain<void>().catchError((_) {}));

        if ({301, 302, 303, 307, 308}.contains(status) && location != null) {
          final next = uri.resolve(location);
          if (!{'http', 'https'}.contains(next.scheme.toLowerCase())) {
            _status = 'Redirect sang giao thức không hỗ trợ';
            break;
          }
          uri = next;
          _current = uri;
          _assessment = _assessUri(uri);
          if (mounted) setState(() {});
          continue;
        }

        _current = uri;
        _assessment = _assessUri(uri);
        _status = _isLikelyIntermediatePage(uri)
            ? '⚠️ Trang trung gian — cần xác minh thủ công'
            : (_assessment.manualVerificationLikely
                ? 'Có thể cần xác minh thủ công trước khi có URL đích'
                : '✅ Đã tới URL cuối có thể xác định tự động');
        break;
      }

      if (_current != null) {
        _controller.text = _current.toString();
        await _saveHistory(_current.toString());
      }
    } on TimeoutException {
      _status = 'Máy chủ phản hồi quá lâu';
    } catch (e) {
      _status = 'Không thể giải redirect tự động';
    } finally {
      client.close();
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openPage({Uri? initialUri}) async {
    // For verification flows, open the original URL instead of the URL produced
    // by the HTTP resolver. This lets WebView perform the site's normal GET ->
    // redirect -> cookie/session sequence itself (important for Link4m /go pages).
    final uri = initialUri ?? _parseInput(_controller.text) ?? _current;
    if (uri == null) {
      _toast('Chưa có URL để mở.');
      return;
    }

    if (Platform.isAndroid) {
      try {
        // Android v3.6 Native Popup Final deliberately hands the complete browsing
        // session to android.webkit.WebView. The native activity does not
        // intercept or replay form POSTs; it lets Chromium/WebView own the
        // navigation stack exactly like the older ShiBu Android build.
        final result = await _nativeWebViewChannel.invokeMethod<String>(
          'open',
          <String, dynamic>{'url': uri.toString()},
        );
        if (result != null && result.isNotEmpty) {
          final parsed = _parseInput(result);
          if (parsed != null) {
            await _continueFromVerifiedUrl(parsed, source: 'Native WebView');
          }
        }
      } on PlatformException catch (e) {
        _toast('Không mở được Native WebView: ${e.message ?? e.code}');
      }
      return;
    }

    if (Platform.isIOS || Platform.isMacOS) {
      final result = await Navigator.of(context).push<String>(
        MaterialPageRoute(builder: (_) => WebViewPage(initialUri: uri)),
      );
      if (result != null && result.isNotEmpty) {
        final parsed = _parseInput(result);
        if (parsed != null) {
          await _continueFromVerifiedUrl(parsed, source: 'WebView');
        }
      }
      return;
    }

    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) _toast('Không mở được trình duyệt hệ thống.');
  }

  Future<void> _openExternal() async {
    final uri = _parseInput(_controller.text) ?? _current;
    if (uri == null) return;
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) _toast('Không mở được URL.');
  }

  Future<void> _paste() async {
    if (_busy) return;
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text == null) {
      _toast('Clipboard chưa có link.');
      return;
    }

    final value = data!.text!.trim();
    final parsed = _parseInput(value);
    if (parsed == null) {
      setState(() {
        _controller.text = value;
        _assessment = const LinkAssessment(
          label: 'Chưa phân loại',
          detail: 'URL chưa hợp lệ hoặc chưa đầy đủ.',
        );
      });
      _toast('Clipboard không chứa URL http/https hợp lệ.');
      return;
    }

    // Keep the exact user-entered URL. The HTTP resolver may turn a short
    // Link4m URL into /go/..., but opening /go/... directly can miss the
    // browser session established by the original navigation.
    final originalUri = parsed;

    setState(() {
      _controller.text = parsed.toString();
      _current = parsed;
      _assessment = _assessUri(parsed);
      _status = 'Đã dán link · đang tự xử lý…';
    });

    await _resolve();
    if (!mounted || _current == null) return;

    final current = _current!;
    final manual = _isLikelyIntermediatePage(current) ||
        _assessment.manualVerificationLikely;

    if (!manual) {
      await Clipboard.setData(ClipboardData(text: current.toString()));
      if (mounted) {
        setState(() => _status = '✅ Đã tự xử lý và sao chép URL cuối');
      }
      _toast('Đã sao chép URL cuối.');
      return;
    }

    if (mounted) {
      setState(() {
        _status =
            '⚠️ Cần xác minh thủ công · đang mở bằng Android Native WebView';
      });
      // WebView-first: replay the complete site navigation from the original
      // short URL. Do not jump straight to a resolved /go/ URL.
      await _openPage(initialUri: originalUri);
    }
  }

  Future<void> _copy() async {
    final value = (_current?.toString() ?? _controller.text).trim();
    if (value.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: value));
    _toast('Đã sao chép URL');
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF051112), Color(0xFF0B2424), Color(0xFF111424)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _header(),
              Expanded(
                child: IndexedStack(
                  index: _tab,
                  children: [_homeTab(), _historyTab(), _aboutTab()],
                ),
              ),
              _bottomNav(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
      child: Row(
        children: [
          Container(
            width: 66,
            height: 66,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              gradient: const LinearGradient(colors: [_mint, _cyan]),
              boxShadow: const [BoxShadow(color: Color(0x5537F0BF), blurRadius: 18)],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: Image.asset('assets/shibu_icon.png', fit: BoxFit.cover),
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ShiBu Bypass', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
                SizedBox(height: 2),
                Text('Universal URL Resolver', style: TextStyle(color: _mint, fontSize: 14, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(color: const Color(0x223AF2C0), borderRadius: BorderRadius.circular(99)),
            child: const Text('v3.6', style: TextStyle(color: _mint, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Widget _homeTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
      children: [
        _glass(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Row(
                children: [
                  Icon(Icons.link_rounded, color: _mint),
                  SizedBox(width: 8),
                  Text('Nhập link', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                ],
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _controller,
                keyboardType: TextInputType.url,
                autocorrect: false,
                enableSuggestions: false,
                minLines: 1,
                maxLines: 3,
                onChanged: _classifyInput,
                onSubmitted: (_) {
                  if (!_busy) unawaited(_resolve());
                },
                decoration: const InputDecoration(hintText: 'https://…'),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _softButton(Icons.auto_awesome_rounded, 'Dán & chạy', _paste)),
                  const SizedBox(width: 10),
                  Expanded(child: _gradientButton(Icons.route_rounded, _busy ? 'Đang xử lý' : 'Giải redirect', _busy ? null : _resolve)),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _softButton(Icons.language_rounded, 'Mở trang', _openPage)),
                  const SizedBox(width: 10),
                  Expanded(child: _softButton(Icons.copy_rounded, 'Sao chép', _copy)),
                  const SizedBox(width: 10),
                  Expanded(child: _softButton(Icons.open_in_new_rounded, 'Mở ngoài', _openExternal)),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        _statusCard(),
        const SizedBox(height: 14),
        _glass(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Chuỗi redirect', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              if (_hops.isEmpty)
                const Text('Chưa có dữ liệu HTTP. Với trang trung gian dùng JavaScript/xác minh, hãy mở trang; app sẽ chỉ ghi nhận URL hiện tại sau thao tác thủ công.', style: TextStyle(color: Colors.white60, height: 1.45))
              else
                ..._hops.asMap().entries.map((e) => _hopTile(e.key + 1, e.value)),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: const Color(0x1AF4C95D),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: const Color(0x44F4C95D)),
          ),
          child: const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.verified_user_outlined, color: Color(0xFFF4C95D)),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'CAPTCHA, anti-bot, timer bắt buộc, quảng cáo/xác minh và hệ thống cấp key vẫn cần hoàn thành thủ công. v3.6 Native Popup Final dùng Android WebView native để giữ chuỗi điều hướng, cookie và POST giống bản Android cũ; Chrome chỉ dùng khi thật sự cần.',
                  style: TextStyle(color: Colors.white70, height: 1.4),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _statusCard() {
    final current = _current?.toString();
    return _glass(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              if (_busy)
                const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: _mint))
              else
                const Icon(Icons.bolt_rounded, color: _mint),
              const SizedBox(width: 8),
              Expanded(child: Text(_status, style: const TextStyle(fontWeight: FontWeight.w800))),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: _assessment.manualVerificationLikely
                      ? const Color(0x22F4C95D)
                      : const Color(0x223AF2C0),
                  borderRadius: BorderRadius.circular(99),
                  border: Border.all(
                    color: _assessment.manualVerificationLikely
                        ? const Color(0x66F4C95D)
                        : const Color(0x553AF2C0),
                  ),
                ),
                child: Text(
                  _assessment.label,
                  style: TextStyle(
                    color: _assessment.manualVerificationLikely ? const Color(0xFFF4C95D) : _mint,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ),
              if (_assessment.sensitiveParameters) ...[
                const SizedBox(width: 8),
                const Tooltip(
                  message: 'URL có tham số nhạy cảm; app không cần hiển thị giá trị token để phân loại.',
                  child: Icon(Icons.lock_outline_rounded, size: 18, color: Colors.white54),
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Text(_assessment.detail, style: const TextStyle(color: Colors.white60, height: 1.4)),
          if (_assessment.manualVerificationLikely) ...[
            const SizedBox(height: 8),
            const Text(
              'Trạng thái: Cần xác minh thủ công nếu trang yêu cầu CAPTCHA, đăng nhập, timer, quảng cáo hoặc cấp key.',
              style: TextStyle(color: Color(0xFFF4C95D), fontSize: 12.5, height: 1.35),
            ),
          ],
          if (current != null) ...[
            const SizedBox(height: 12),
            const Text('URL hiện tại', style: TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(height: 4),
            SelectableText(current, style: const TextStyle(color: _mint, height: 1.35)),
          ],
        ],
      ),
    );
  }

  Widget _hopTile(int index, RedirectHop hop) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0x263AF2C0)),
            child: Text('$index', style: const TextStyle(color: _mint, fontWeight: FontWeight.w800)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${hop.kind}${hop.statusCode == null ? '' : ' · ${hop.statusCode}'}', style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(hop.uri.toString(), style: const TextStyle(color: Colors.white60, fontSize: 12.5), maxLines: 3, overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _historyTab() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
      children: [
        _glass(
          child: Row(
            children: [
              const Expanded(child: Text('Lịch sử gần đây', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
              TextButton.icon(
                onPressed: _history.isEmpty
                    ? null
                    : () async {
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.remove('history');
                        if (mounted) setState(() => _history = []);
                      },
                icon: const Icon(Icons.delete_sweep_outlined),
                label: const Text('Xóa'),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (_history.isEmpty)
          _glass(child: const Text('Chưa có lịch sử.', style: TextStyle(color: Colors.white60)))
        else
          ..._history.map(
            (url) => Padding(
              padding: const EdgeInsets.only(bottom: 9),
              child: Material(
                color: _panel.withOpacity(.82),
                borderRadius: BorderRadius.circular(16),
                child: ListTile(
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  leading: const Icon(Icons.history_rounded, color: _mint),
                  title: Text(url, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () {
                    setState(() {
                      _tab = 0;
                      _controller.text = url;
                      _current = Uri.tryParse(url);
                      if (_current != null) _assessment = _assessUri(_current!);
                    });
                  },
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _aboutTab() {
    final platform = Platform.operatingSystem;
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 24),
      children: [
        _glass(
          child: Column(
            children: [
              ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/shibu_icon.png', width: 150, height: 150)),
              const SizedBox(height: 16),
              const Text('ShiBu Bypass Universal v3.6', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('Đang chạy trên $platform', style: const TextStyle(color: _mint)),
              const SizedBox(height: 14),
              const Text(
                'Bản Universal v3.6 Native Popup Final: trên Android, trang được mở bằng android.webkit.WebView native từ URL gốc để giữ chuỗi GET/redirect, cookie, session và form navigation gần bản cũ nhất. Sau khi bạn hoàn thành bước xác minh, ShiBu theo dõi URL mới và tiếp tục redirect; Chrome chỉ là phương án dự phòng khi WebView thực sự không tải được.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white60, height: 1.5),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _bottomNav() {
    return Container(
      margin: const EdgeInsets.fromLTRB(18, 0, 18, 14),
      decoration: BoxDecoration(
        color: const Color(0xEE0B1A1D),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x333AF2C0)),
      ),
      child: NavigationBar(
        height: 68,
        backgroundColor: Colors.transparent,
        indicatorColor: const Color(0x333AF2C0),
        selectedIndex: _tab,
        onDestinationSelected: (value) => setState(() => _tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'Trang chủ'),
          NavigationDestination(icon: Icon(Icons.history_outlined), selectedIcon: Icon(Icons.history_rounded), label: 'Lịch sử'),
          NavigationDestination(icon: Icon(Icons.info_outline_rounded), selectedIcon: Icon(Icons.info_rounded), label: 'Thông tin'),
        ],
      ),
    );
  }

  Widget _glass({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _panel.withOpacity(.88),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: const Color(0x303AF2C0)),
        boxShadow: const [BoxShadow(color: Color(0x33000000), blurRadius: 18, offset: Offset(0, 8))],
      ),
      child: child,
    );
  }

  Widget _gradientButton(IconData icon, String label, VoidCallback? onPressed) {
    return DecoratedBox(
      decoration: BoxDecoration(
        gradient: onPressed == null ? null : const LinearGradient(colors: [_mint, _cyan]),
        color: onPressed == null ? Colors.white12 : null,
        borderRadius: BorderRadius.circular(16),
      ),
      child: ElevatedButton.icon(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          foregroundColor: const Color(0xFF05211C),
          shadowColor: Colors.transparent,
          padding: const EdgeInsets.symmetric(vertical: 15),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        icon: Icon(icon),
        label: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
      ),
    );
  }

  Widget _softButton(IconData icon, String label, VoidCallback onPressed) {
    return FilledButton.tonalIcon(
      onPressed: onPressed,
      style: FilledButton.styleFrom(
        backgroundColor: const Color(0xFF20343E),
        foregroundColor: Colors.white,
        padding: const EdgeInsets.symmetric(vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      icon: Icon(icon, size: 19),
      label: Text(label, maxLines: 1, overflow: TextOverflow.fade),
    );
  }
}

class WebViewPage extends StatefulWidget {
  final Uri initialUri;

  const WebViewPage({super.key, required this.initialUri});

  @override
  State<WebViewPage> createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  late final WebViewController _web;
  String _current = '';
  int _progress = 0;
  String? _mainFrameError;
  bool _cacheMiss = false;
  Uri? _lastCompletedUri;
  Timer? _autoReturnTimer;
  bool _autoReturned = false;

  bool _isHttpUrl(String? value) {
    if (value == null || value.isEmpty) return false;
    final uri = Uri.tryParse(value);
    return uri != null && {'http', 'https'}.contains(uri.scheme.toLowerCase());
  }

  void _setCurrent(String? url) {
    if (!_isHttpUrl(url) || !mounted) return;
    setState(() => _current = url!);
  }

  bool _isIntermediateLike(Uri uri) {
    final host = uri.host.toLowerCase();
    final path = uri.path.toLowerCase();
    if ((host == 'link4m.org' || host.endsWith('.link4m.org')) &&
        (path.startsWith('/go/') || path.contains('/verify'))) {
      return true;
    }
    const hints = <String>[
      '/captcha', '/challenge', '/verify', '/verification', '/checkpoint',
      '/login', '/signin', '/authorize',
    ];
    return hints.any(path.contains);
  }

  bool _differentFromInitial(Uri uri) {
    final a = widget.initialUri;
    String cleanHost(Uri u) => u.host.toLowerCase().replaceFirst(RegExp(r'^www\.'), '');
    return cleanHost(a) != cleanHost(uri) || a.path != uri.path || a.query != uri.query;
  }

  void _scheduleAutoReturn(String? value) {
    if (_autoReturned || !_isHttpUrl(value)) return;
    final uri = Uri.tryParse(value!);
    if (uri == null || !_differentFromInitial(uri) || _isIntermediateLike(uri)) return;
    _autoReturnTimer?.cancel();
    _autoReturnTimer = Timer(const Duration(milliseconds: 1200), () {
      if (!mounted || _autoReturned) return;
      _autoReturned = true;
      Navigator.of(context).pop(uri.toString());
    });
  }

  void _handleWebError(WebResourceError error) {
    // webview_flutter reports failures for subresources too. A broken image, ad,
    // font, iframe or tracking request must NOT cover a page that is otherwise
    // usable. Only a confirmed main-frame error gets an error card.
    if (error.isForMainFrame == false) return;

    final upper = error.description.toUpperCase();
    // Android WebView code -12 is ERROR_BAD_URL, not ERR_CACHE_MISS. v3.6 FIX
    // therefore classifies cache miss only from the actual error description.
    final isCacheMiss = upper.contains('ERR_CACHE_MISS') ||
        upper.contains('CACHE_MISS');
    final type = error.errorType?.name ?? 'unknown';
    final failingUrl = error.url?.trim();
    final urlText = (failingUrl != null && failingUrl.isNotEmpty)
        ? failingUrl
        : _current;

    if (!mounted) return;
    setState(() {
      _cacheMiss = isCacheMiss;
      _mainFrameError = isCacheMiss
          ? 'WebView báo ERR_CACHE_MISS ở main frame. Không tự lặp POST/biểu mẫu cũ.\n'
              'Mã: ${error.errorCode} · loại: $type\nURL lỗi: $urlText'
          : 'Lỗi main frame: ${error.description}\n'
              'Mã: ${error.errorCode} · loại: $type\nURL lỗi: $urlText';
    });
  }

  Future<void> _restartOriginalFlow() async {
    if (mounted) {
      setState(() {
        _mainFrameError = null;
        _cacheMiss = false;
        _progress = 0;
      });
    }
    try {
      // Restart from the short/original URL so the site can recreate cookies,
      // session state and redirects in the same WebView cookie jar.
      await _web.loadRequest(widget.initialUri);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không thể chạy lại luồng gốc. Hãy thử Mở ngoài.')),
        );
      }
    }
  }

  Future<void> _retryCurrentAsGet({bool silent = false}) async {
    final uri = Uri.tryParse(_current) ?? widget.initialUri;
    if (!{'http', 'https'}.contains(uri.scheme.toLowerCase())) return;

    if (mounted) {
      setState(() {
        _mainFrameError = null;
        _cacheMiss = false;
        _progress = 0;
      });
    }

    // loadRequest creates a new GET request instead of asking Android WebView
    // to resubmit a previous POST body that may no longer exist in cache.
    try {
      await _web.loadRequest(uri);
    } catch (_) {
      if (!silent && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Không thể tải lại URL bằng GET. Hãy thử Mở ngoài.')),
        );
      }
    }
  }

  Future<void> _openCurrentExternally() async {
    final uri = Uri.tryParse(_current) ?? widget.initialUri;
    if (!{'http', 'https'}.contains(uri.scheme.toLowerCase())) return;
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Không mở được trình duyệt hệ thống.')),
      );
    }
  }

  Future<void> _prepareAndroidWebViewAndLoad() async {
    // Some multi-domain login/verification/session flows use cookies from an
    // embedded/redirected domain. Android WebView treats those as third-party
    // cookies. Keep them enabled so the site's normal browser session can be
    // preserved. This does not automate any verification step.
    if (Platform.isAndroid) {
      try {
        final platformController = _web.platform;
        final cookieManager = WebViewCookieManager();
        final platformCookieManager = cookieManager.platform;
        if (platformController is AndroidWebViewController &&
            platformCookieManager is AndroidWebViewCookieManager) {
          await platformCookieManager.setAcceptThirdPartyCookies(
            platformController,
            true,
          );
        }
      } catch (_) {
        // Fall back to the platform defaults if the installed WebView/plugin
        // does not expose the Android-specific cookie setting.
      }
    }

    try {
      await _web.loadRequest(widget.initialUri);
    } catch (_) {
      if (mounted) {
        setState(() {
          _mainFrameError = 'Không thể mở URL gốc trong WebView.';
          _cacheMiss = false;
        });
      }
    }
  }

  @override
  void initState() {
    super.initState();
    _current = widget.initialUri.toString();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF071416))
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (value) {
            if (mounted) setState(() => _progress = value);
          },
          onPageStarted: (url) {
            if (!mounted) return;
            setState(() {
              _current = url;
              _progress = 0;
              _mainFrameError = null;
              _cacheMiss = false;
            });
          },
          onUrlChange: (change) {
            _setCurrent(change.url);
            _scheduleAutoReturn(change.url);
          },
          onPageFinished: (url) {
            final parsed = Uri.tryParse(url);
            if (!mounted) return;
            setState(() {
              _current = url;
              _progress = 100;
              if (parsed != null && {'http', 'https'}.contains(parsed.scheme.toLowerCase())) {
                _lastCompletedUri = parsed;
              }
            });
            _scheduleAutoReturn(url);
          },
          onWebResourceError: _handleWebError,
          onNavigationRequest: (request) {
            final uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.prevent;
            final scheme = uri.scheme.toLowerCase();
            // Normal network navigation plus browser-internal document schemes
            // used by forms/iframes are allowed inside this WebView. Local file,
            // content and unknown external schemes stay blocked.
            if ({'http', 'https', 'about', 'data', 'blob'}.contains(scheme)) {
              return NavigationDecision.navigate;
            }
            return NavigationDecision.prevent;
          },
        ),
      );

    // Apply Android cookie policy before the first request.
    unawaited(_prepareAndroidWebViewAndLoad());
  }

  @override
  void dispose() {
    _autoReturnTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _deep,
      appBar: AppBar(
        backgroundColor: const Color(0xFF0B1D20),
        titleSpacing: 0,
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('ShiBu WebView', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
            Text(_current, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, color: Colors.white60)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Mở ngoài',
            onPressed: _openCurrentExternally,
            icon: const Icon(Icons.open_in_new_rounded),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, _current),
            child: const Text('Dùng URL này', style: TextStyle(color: _mint, fontWeight: FontWeight.w800)),
          ),
        ],
        bottom: _progress < 100
            ? PreferredSize(
                preferredSize: const Size.fromHeight(3),
                child: LinearProgressIndicator(value: _progress / 100, minHeight: 3, color: _mint, backgroundColor: Colors.white10),
              )
            : null,
      ),
      body: Stack(
        children: [
          Positioned.fill(child: WebViewWidget(controller: _web)),
          if (_mainFrameError != null)
            Positioned(
              left: 12,
              right: 12,
              top: 12,
              child: Material(
                elevation: 8,
                color: const Color(0xF21A2C30),
                borderRadius: BorderRadius.circular(16),
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Row(
                        children: [
                          Icon(_cacheMiss ? Icons.cached_rounded : Icons.error_outline_rounded, color: _cacheMiss ? const Color(0xFFFFD166) : Colors.orangeAccent),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _cacheMiss ? 'Lỗi cache của WebView' : 'Lỗi tải trang',
                              style: const TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(_mainFrameError!, style: const TextStyle(color: Colors.white70, height: 1.35)),
                      if (_cacheMiss) ...[
                        const SizedBox(height: 6),
                        const Text(
                          'Không tự gửi lại POST cũ. Hãy chạy lại từ URL gốc để website tự tạo lại cookie/session trong cùng WebView; chỉ dùng Chrome nếu vẫn lỗi.',
                          style: TextStyle(color: Colors.white54, fontSize: 12.5, height: 1.35),
                        ),
                      ],
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          FilledButton.icon(
                            onPressed: _restartOriginalFlow,
                            icon: const Icon(Icons.restart_alt_rounded),
                            label: const Text('Chạy lại từ link gốc'),
                          ),
                          OutlinedButton.icon(
                            onPressed: _openCurrentExternally,
                            icon: const Icon(Icons.open_in_new_rounded),
                            label: const Text('Mở ngoài'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          color: const Color(0xFF0B1D20),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              IconButton(onPressed: () async { if (await _web.canGoBack()) await _web.goBack(); }, icon: const Icon(Icons.arrow_back_rounded)),
              IconButton(
                tooltip: 'Chạy lại từ URL gốc',
                onPressed: _restartOriginalFlow,
                icon: const Icon(Icons.refresh_rounded),
              ),
              IconButton(onPressed: () async { if (await _web.canGoForward()) await _web.goForward(); }, icon: const Icon(Icons.arrow_forward_rounded)),
              IconButton(
                onPressed: () async {
                  await Clipboard.setData(ClipboardData(text: _current));
                  if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Đã sao chép URL hiện tại')));
                },
                icon: const Icon(Icons.copy_rounded),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

