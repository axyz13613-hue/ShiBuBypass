# ShiBu Bypass Universal v3.5

Cross-platform URL resolver / redirect inspector.

## v3.5 Verify & Continue
- `Dán & chạy` automatically resolves normal HTTP/HTTPS redirects.
- For manual-verification pages that work in WebView, the app opens WebView automatically and watches navigation. After the user manually completes the website-required step and the page moves to a non-intermediate URL, ShiBu returns that URL to the home screen, continues safe redirect resolution, and copies the final URL.
- For Link4m on Android, ShiBu opens Chrome to avoid WebView `ERR_CACHE_MISS`. After the user manually completes the required step, use **Chrome → Chia sẻ → ShiBu Bypass**. The Android share bridge receives the shared URL, resumes redirect resolution, and copies the final URL when it is no longer an intermediate/manual-verification page.
- Normal redirect chains, common social outbound wrappers, history, clipboard, and external browser fallback are retained.

## Manual-only boundary
ShiBu does not solve or bypass CAPTCHA/reCAPTCHA, anti-bot checks, mandatory codes/timers/ads, login/access controls, or key-generation/key-gating systems. It only continues automatically after the user has completed any website-required step.

## Platforms
Android, iOS, Windows, macOS, and Linux are built from the same Flutter source. The Android build adds a text-share intent so Chrome can share the current URL back to ShiBu. iOS CI output remains unsigned.
