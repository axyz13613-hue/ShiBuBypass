# ShiBu Bypass Universal v3.3

Cross-platform URL resolver with a redesigned dark mint/cyan UI based on the ShiBu avatar.

## What it does
- Resolves standard HTTP/HTTPS redirects (301/302/303/307/308).
- Unwraps common outbound-link wrappers from Facebook/Messenger/Instagram/Google/YouTube/Discord.
- Shows redirect chain and current/final URL.
- Detects auth/session links, shortlinks, redirect-like URLs, and likely manual-verification pages without exposing token values.
- Local history and clipboard actions.
- Embedded WebView on Android/iOS/macOS; external browser fallback on Windows/Linux.
- Lets the user return the current WebView URL after manually completing a page.

## What it intentionally does not automate
CAPTCHA, anti-bot challenges, mandatory timers, ad/verification gates, access controls, or key-generation systems must be completed manually.

## Platforms
Android, iOS, Windows, macOS, Linux source is included via Flutter CI bootstrap.

Notes:
- Android output is a normal release APK.
- iOS CI output is unsigned. A physical iPhone requires Apple signing before installation.
- Desktop output is packaged as ZIP/TAR artifacts.

## v3.2 status fix
- Treats Link4m `/go/...` as an intermediate/manual-verification page instead of a final URL.
- After returning from WebView, only labels a URL as a discovered destination when navigation meaningfully changed and the new page is not classified as an intermediate/manual-verification page.


## v3.3 WebView fix
- Tracks JavaScript/history URL changes through WebView navigation callbacks.
- Detects main-frame `ERR_CACHE_MISS` and avoids blindly resubmitting an old POST request.
- Retries the initial cache miss once with a fresh GET; later cache misses show an explicit safe-reload button.
- Keeps the existing WebView cookie/session storage intact; the app does not clear cache/local storage during navigation.
- Replaces the toolbar reload action with a safe GET reload and offers an external-browser fallback.
- Manual CAPTCHA, anti-bot, timer, ad/verification, login and key-gate steps are still not automated.
