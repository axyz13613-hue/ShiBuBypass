# ShiBu Bypass Universal v3.6

Cross-platform URL resolver / redirect inspector / WebView helper.

## v3.6 WebView-first

- Trang trung gian cần thao tác được ưu tiên mở **ngay trong ShiBu WebView**.
- WebView bắt đầu từ **URL gốc người dùng dán**, không nhảy thẳng vào `/go/...`; cách này giúp website tự tạo đúng cookie/session qua chuỗi GET và redirect bình thường.
- Giữ JavaScript và phiên WebView trong cùng màn hình; không tự lặp lại POST khi gặp `ERR_CACHE_MISS`.
- Nếu có `ERR_CACHE_MISS`, nút chính chạy lại **từ link gốc** trong cùng WebView thay vì resubmit POST cũ.
- Sau khi người dùng hoàn thành bước xác minh bắt buộc và URL thật sự chuyển tiếp, ShiBu có thể nhận URL mới, tiếp tục redirect và sao chép URL cuối.
- Chrome là phương án dự phòng khi WebView thật sự không tải được; Android Share vẫn được hỗ trợ để đưa URL trở lại ShiBu.

## Giới hạn

ShiBu chỉ xử lý redirect và theo dõi URL. CAPTCHA/reCAPTCHA, anti-bot, timer/quảng cáo bắt buộc, đăng nhập và hệ thống cấp key phải được hoàn thành theo cơ chế của website.
