package com.shibuhub.linkresolver;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private EditText urlInput;
    private TextView statusText;
    private TextView resultText;
    private LinearLayout resultBox;
    private Button resolveButton;
    private String resolvedUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackground(gradient(Color.rgb(24, 5, 37), Color.rgb(76, 10, 72), 0));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(16), dp(18), dp(16), dp(18));
        card.setBackground(rounded(Color.rgb(53, 19, 63), 28, Color.rgb(181, 75, 183), 1));
        root.addView(card, matchWrap());

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.shibuhub.linkresolver.R.drawable.shibu_bypass_logo);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(118), dp(118));
        logoLp.gravity = Gravity.CENTER_HORIZONTAL;
        logoLp.setMargins(0, 0, 0, dp(10));
        card.addView(logo, logoLp);

        TextView title = text("shibu bypass", 31, Color.rgb(255, 205, 225), true);
        title.setGravity(Gravity.CENTER);
        card.addView(title, matchWrap());

        TextView subtitle = text("✨  TOOL VƯỢT LINK SIÊU TỐC  ✨", 13,
                Color.rgb(226, 175, 221), false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = matchWrap();
        subLp.setMargins(0, dp(4), 0, dp(18));
        card.addView(subtitle, subLp);

        card.addView(chipRow("Octolink.vip", "Link4m", "Layma.net"), matchWrap());
        LinearLayout.LayoutParams row2Lp = matchWrap();
        row2Lp.setMargins(0, dp(7), 0, 0);
        card.addView(chipRow("Traffic4k.com", "trafficuserr.com", "trafficvn.com"), row2Lp);
        LinearLayout.LayoutParams row3Lp = matchWrap();
        row3Lp.setMargins(0, dp(7), 0, dp(18));
        card.addView(chipRow("Phienchoso.com", "Uptolink", "Luarmor"), row3Lp);

        TextView label = text("🔗  Dán URL cần xử lý", 16, Color.rgb(255, 198, 230), true);
        card.addView(label, matchWrap());

        urlInput = new EditText(this);
        urlInput.setTextColor(Color.WHITE);
        urlInput.setHintTextColor(Color.rgb(169, 136, 175));
        urlInput.setHint("https://example.com/short-link");
        urlInput.setSingleLine(false);
        urlInput.setMinLines(2);
        urlInput.setMaxLines(4);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        urlInput.setPadding(dp(16), dp(13), dp(16), dp(13));
        urlInput.setBackground(rounded(Color.rgb(28, 9, 38), 23, Color.rgb(112, 52, 126), 1));
        LinearLayout.LayoutParams inputLp = matchWrap();
        inputLp.setMargins(0, dp(9), 0, dp(10));
        card.addView(urlInput, inputLp);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER);

        Button paste = smallButton("📋 Dán");
        paste.setOnClickListener(v -> pasteClipboard());
        tools.addView(paste, weighted());

        Button clear = smallButton("✕ Xóa");
        clear.setOnClickListener(v -> {
            urlInput.setText("");
            resultBox.setVisibility(View.GONE);
            resolvedUrl = "";
            statusText.setText("Sẵn sàng.");
        });
        LinearLayout.LayoutParams clearLp = weighted();
        clearLp.setMargins(dp(8), 0, 0, 0);
        tools.addView(clear, clearLp);
        card.addView(tools, matchWrap());

        resolveButton = new Button(this);
        resolveButton.setText("🚀 Vượt link");
        resolveButton.setTextColor(Color.WHITE);
        resolveButton.setTextSize(18);
        resolveButton.setAllCaps(false);
        resolveButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        resolveButton.setPadding(dp(12), dp(10), dp(12), dp(10));
        resolveButton.setBackground(gradient(Color.rgb(255, 84, 183), Color.rgb(255, 31, 139), 28));
        resolveButton.setOnClickListener(v -> startResolve());
        LinearLayout.LayoutParams buttonLp = matchWrap();
        buttonLp.setMargins(0, dp(15), 0, dp(13));
        buttonLp.height = dp(58);
        card.addView(resolveButton, buttonLp);

        statusText = text("Sẵn sàng.", 14, Color.rgb(255, 224, 111), true);
        statusText.setGravity(Gravity.CENTER);
        statusText.setPadding(dp(12), dp(14), dp(12), dp(14));
        statusText.setBackground(rounded(Color.rgb(47, 14, 55), 18, Color.rgb(99, 45, 109), 1));
        card.addView(statusText, matchWrap());

        resultBox = new LinearLayout(this);
        resultBox.setOrientation(LinearLayout.VERTICAL);
        resultBox.setPadding(dp(14), dp(14), dp(14), dp(14));
        resultBox.setBackground(rounded(Color.rgb(31, 12, 40), 18, Color.rgb(77, 189, 111), 1));
        resultBox.setVisibility(View.GONE);
        LinearLayout.LayoutParams resultLp = matchWrap();
        resultLp.setMargins(0, dp(13), 0, 0);
        card.addView(resultBox, resultLp);

        TextView ok = text("✅ Link đích / trạng thái", 16, Color.rgb(116, 242, 145), true);
        ok.setGravity(Gravity.CENTER);
        resultBox.addView(ok, matchWrap());

        resultText = text("", 14, Color.WHITE, false);
        resultText.setTextIsSelectable(true);
        resultText.setPadding(dp(10), dp(12), dp(10), dp(12));
        resultText.setBackground(rounded(Color.rgb(22, 8, 29), 14, Color.rgb(77, 39, 86), 1));
        LinearLayout.LayoutParams resTextLp = matchWrap();
        resTextLp.setMargins(0, dp(10), 0, dp(10));
        resultBox.addView(resultText, resTextLp);

        Button copy = smallButton("📋 Sao chép");
        copy.setOnClickListener(v -> copyResult());
        resultBox.addView(copy, matchWrap());

        Button open = smallButton("🌐 Mở trong trình duyệt");
        open.setOnClickListener(v -> openResult());
        LinearLayout.LayoutParams openLp = matchWrap();
        openLp.setMargins(0, dp(8), 0, 0);
        resultBox.addView(open, openLp);

        TextView note = text(
                "Hỗ trợ redirect HTTP/HTTPS công khai. Với trang key/xác minh như Luarmor, app chỉ kiểm tra redirect công khai hoặc mở trang gốc; không giả mạo phiên, referrer, fingerprint hay vượt cơ chế xác minh.",
                12, Color.rgb(200, 167, 202), false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteLp = matchWrap();
        noteLp.setMargins(dp(8), dp(18), dp(8), 0);
        card.addView(note, noteLp);

        TextView footer = text("✦  POWERED BY SHIBU  ✦", 11, Color.rgb(230, 145, 226), true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = matchWrap();
        footerLp.setMargins(0, dp(16), 0, 0);
        card.addView(footer, footerLp);

        return scroll;
    }

    private LinearLayout chipRow(String... labels) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        for (String label : labels) {
            TextView c = chip(label);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            c.setLayoutParams(lp);
            row.addView(c);
        }
        return row;
    }

    private void startResolve() {
        String input = urlInput.getText().toString().trim();
        if (input.isEmpty()) {
            toast("Hãy dán một URL trước.");
            return;
        }
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = "https://" + input;
            urlInput.setText(input);
        }

        final String start = input;
        resolveButton.setEnabled(false);
        resultBox.setVisibility(View.GONE);
        statusText.setText("⏳ Đang kiểm tra redirect công khai…");

        executor.execute(() -> {
            try {
                ResolveResult result = resolve(start);
                main.post(() -> {
                    resolveButton.setEnabled(true);
                    resolvedUrl = result.finalUrl;
                    if (result.hops == 0) {
                        statusText.setText("ℹ️ Không phát hiện redirect HTTP công khai.");
                    } else {
                        statusText.setText(String.format(Locale.getDefault(),
                                "✅ Hoàn tất • %d bước chuyển hướng", result.hops));
                    }
                    String detail = result.finalUrl;
                    if (result.hops == 0) {
                        detail += "\n\nTrang có thể dùng JavaScript, CAPTCHA, key hoặc xác minh trong trình duyệt.";
                    } else {
                        detail += "\n\nChuỗi:\n" + String.join("\n→ ", result.chain);
                    }
                    resultText.setText(detail);
                    resultBox.setVisibility(View.VISIBLE);
                });
            } catch (Exception e) {
                main.post(() -> {
                    resolveButton.setEnabled(true);
                    statusText.setText("❌ Không thể xử lý link: " + friendlyError(e));
                });
            }
        });
    }

    private ResolveResult resolve(String start) throws Exception {
        URL current = new URL(start);
        List<String> chain = new ArrayList<>();
        chain.add(current.toString());

        for (int hop = 0; hop < 10; hop++) {
            ensurePublicHost(current);
            HttpURLConnection conn = (HttpURLConnection) current.openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(9000);
            conn.setRequestProperty("User-Agent", "shibu-bypass/1.1 Android");
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8");
            conn.setRequestMethod("GET");

            int code = conn.getResponseCode();
            if (isRedirect(code)) {
                String location = conn.getHeaderField("Location");
                conn.disconnect();
                if (location == null || location.trim().isEmpty()) {
                    throw new IllegalStateException("Redirect không có Location header");
                }
                URI base = current.toURI();
                URI next = base.resolve(location.trim());
                current = next.toURL();
                if (!current.getProtocol().equalsIgnoreCase("http") &&
                        !current.getProtocol().equalsIgnoreCase("https")) {
                    throw new IllegalArgumentException("Chỉ hỗ trợ HTTP/HTTPS");
                }
                chain.add(current.toString());
                continue;
            }

            conn.disconnect();
            return new ResolveResult(current.toString(), chain.size() - 1, chain);
        }
        throw new IllegalStateException("Quá nhiều bước chuyển hướng (>10)");
    }

    private void ensurePublicHost(URL url) throws Exception {
        String host = url.getHost();
        if (host == null || host.isEmpty()) throw new IllegalArgumentException("URL không hợp lệ");
        String h = host.toLowerCase(Locale.ROOT);
        if (h.equals("localhost") || h.endsWith(".localhost")) {
            throw new SecurityException("Không hỗ trợ địa chỉ nội bộ");
        }
        InetAddress[] addresses = InetAddress.getAllByName(host);
        for (InetAddress a : addresses) {
            if (a.isAnyLocalAddress() || a.isLoopbackAddress() || a.isLinkLocalAddress() ||
                    a.isSiteLocalAddress() || a.isMulticastAddress()) {
                throw new SecurityException("Không hỗ trợ địa chỉ mạng nội bộ");
            }
        }
    }

    private boolean isRedirect(int code) {
        return code == 301 || code == 302 || code == 303 || code == 307 || code == 308;
    }

    private String friendlyError(Exception e) {
        String m = e.getMessage();
        if (m == null || m.trim().isEmpty()) return e.getClass().getSimpleName();
        return m;
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null && cm.hasPrimaryClip() && cm.getPrimaryClip() != null &&
                cm.getPrimaryClip().getItemCount() > 0) {
            CharSequence text = cm.getPrimaryClip().getItemAt(0).coerceToText(this);
            if (text != null) urlInput.setText(text.toString().trim());
        }
    }

    private void copyResult() {
        if (resolvedUrl.isEmpty()) return;
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Resolved URL", resolvedUrl));
            toast("Đã sao chép link.");
        }
    }

    private void openResult() {
        if (resolvedUrl.isEmpty()) return;
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(resolvedUrl)));
    }

    private TextView chip(String s) {
        TextView t = text(s, 11, Color.rgb(244, 216, 235), true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(5), dp(6), dp(5), dp(6));
        t.setBackground(rounded(Color.rgb(84, 43, 89), 18, Color.rgb(132, 80, 128), 1));
        return t;
    }

    private Button smallButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(rounded(Color.rgb(86, 49, 91), 16, Color.rgb(128, 76, 126), 1));
        return b;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable rounded(int fill, float radiusDp, int stroke, int strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) g.setStroke(dp(strokeDp), stroke);
        return g;
    }

    private GradientDrawable gradient(int start, int end, float radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{start, end});
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams weighted() {
        return new LinearLayout.LayoutParams(0, dp(48), 1f);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private static class ResolveResult {
        final String finalUrl;
        final int hops;
        final List<String> chain;
        ResolveResult(String finalUrl, int hops, List<String> chain) {
            this.finalUrl = finalUrl;
            this.hops = hops;
            this.chain = chain;
        }
    }
}
