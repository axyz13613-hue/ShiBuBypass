# No custom ProGuard rules needed for v1.0.
