# shibu bypass

Android link resolver with a purple/pink UI and the user-provided launcher logo.

## What it does
- Expands normal public HTTP/HTTPS 3xx redirects.
- Shows the redirect chain and final public URL.
- Copy/open result in browser.
- UI includes common link domains and a Luarmor label.

## Protected key/verification pages
For protected pages such as `ads.luarmor.net/get_key`, the app only follows public HTTP redirects. It does **not** spoof referrer, browser fingerprint, session state, CAPTCHA, key verification, or anti-bot checks. If there is no public redirect, it shows the original page so you can open it normally in a browser.

## Build APK on GitHub
1. Upload the project to GitHub.
2. Open **Actions** → **Build Android APK** → **Run workflow**.
3. Download artifact **Shibu-Bypass-APK**.
