# Changelog

## 3.2.0 Stability

- Thêm server-side watchdog 24/7.
- Tự phục hồi container bị dừng/mất.
- Tự restart VM khi Android/ADB mất phản hồi liên tiếp.
- Thêm boot grace và restart cooldown chống vòng lặp restart.
- Theo dõi CPU/RAM/OOM qua Docker stats.
- Thêm `desired_state` để VM chủ động dừng không bị watchdog bật lại.
- Thêm chế độ **Giữ game đang mở** và tự mở lại package khi process mất.
- Thêm thống kê watchdog/app restart trong màn chi tiết VM.
- Màn stream tự reconnect khi mất mạng hoặc WebView lỗi.
- Thêm preset Treo 24/7 / Cân bằng / Hiệu năng.
- Backup/restore/reset dùng maintenance window để tránh watchdog can thiệp.
- Nâng server/app version lên 3.2.0.
