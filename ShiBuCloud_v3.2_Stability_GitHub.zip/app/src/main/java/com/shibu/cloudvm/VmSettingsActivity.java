package com.shibu.cloudvm;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class VmSettingsActivity extends AppCompatActivity {
    private String vmId;
    private EditText name, cpu, ram, width, height, dpi, fps;
    private TextView status;
    private Button save;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vm_settings);
        vmId = getIntent().getStringExtra("vm_id");
        if (vmId == null || vmId.isEmpty()) { finish(); return; }
        name = findViewById(R.id.edName);
        cpu = findViewById(R.id.edCpu);
        ram = findViewById(R.id.edRam);
        width = findViewById(R.id.edWidth);
        height = findViewById(R.id.edHeight);
        dpi = findViewById(R.id.edDpi);
        fps = findViewById(R.id.edFps);
        status = findViewById(R.id.txtSettingsStatus);
        save = findViewById(R.id.btnSaveVmSettings);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnPreset720).setOnClickListener(v -> setDisplay(720, 1280, 320, 60));
        findViewById(R.id.btnPreset1080).setOnClickListener(v -> setDisplay(1080, 2400, 420, 60));
        findViewById(R.id.btnPreset24h).setOnClickListener(v -> setPreset(2, 4096, 720, 1280, 320, 30, "Preset treo 24/7: giảm tải GPU/CPU để ưu tiên ổn định."));
        findViewById(R.id.btnPresetBalanced).setOnClickListener(v -> setPreset(4, 4096, 900, 1600, 360, 45, "Preset cân bằng: hình ảnh mượt hơn nhưng vẫn giữ tải vừa phải."));
        findViewById(R.id.btnPresetPerformance).setOnClickListener(v -> setPreset(4, 6144, 1080, 1920, 420, 60, "Preset hiệu năng: cần VPS đủ mạnh để tránh nghẽn CPU/RAM."));
        save.setOnClickListener(v -> save());
        load();
    }

    private void setDisplay(int w, int h, int d, int f) {
        width.setText(String.valueOf(w)); height.setText(String.valueOf(h)); dpi.setText(String.valueOf(d)); fps.setText(String.valueOf(f));
    }

    private void setPreset(int c, int r, int w, int h, int d, int f, String note) {
        cpu.setText(String.valueOf(c));
        ram.setText(String.valueOf(r));
        setDisplay(w, h, d, f);
        status.setText(note);
    }

    private void load() {
        status.setText("Đang tải cài đặt máy...");
        ApiClient.get(this, "/v1/vms/" + vmId, new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    try {
                        JSONObject vm = new JSONObject(body);
                        name.setText(vm.optString("name", "ShiBu Android"));
                        cpu.setText(String.valueOf(vm.optInt("cpu", 2)));
                        ram.setText(String.valueOf(vm.optInt("ram_mb", 3072)));
                        width.setText(String.valueOf(vm.optInt("width", 1080)));
                        height.setText(String.valueOf(vm.optInt("height", 1920)));
                        dpi.setText(String.valueOf(vm.optInt("dpi", 420)));
                        fps.setText(String.valueOf(vm.optInt("fps", 60)));
                        status.setText("Có thể chỉnh CPU/RAM và màn hình riêng cho máy này.");
                    } catch (Exception e) { status.setText("Lỗi dữ liệu: " + e.getMessage()); }
                });
            }
            @Override public void onError(String message) { runOnUiThread(() -> status.setText("Lỗi: " + message)); }
        });
    }

    private int intValue(EditText e, int fallback) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception ignored) { return fallback; }
    }

    private void save() {
        save.setEnabled(false);
        status.setText("Đang áp dụng cài đặt...");
        try {
            JSONObject body = new JSONObject();
            body.put("name", name.getText().toString().trim().isEmpty() ? "ShiBu Android" : name.getText().toString().trim());
            body.put("cpu", intValue(cpu, 2));
            body.put("ram_mb", intValue(ram, 3072));
            body.put("width", intValue(width, 1080));
            body.put("height", intValue(height, 1920));
            body.put("dpi", intValue(dpi, 420));
            body.put("fps", intValue(fps, 60));
            ApiClient.post(this, "/v1/vms/" + vmId + "/settings", body, new ApiClient.Callback() {
                @Override public void onSuccess(String response) {
                    runOnUiThread(() -> {
                        save.setEnabled(true);
                        status.setText("✓ Đã lưu cài đặt.");
                        Toast.makeText(VmSettingsActivity.this, "Đã áp dụng cài đặt", Toast.LENGTH_LONG).show();
                    });
                }
                @Override public void onError(String message) {
                    runOnUiThread(() -> { save.setEnabled(true); status.setText("Lỗi: " + message); });
                }
            });
        } catch (Exception e) {
            save.setEnabled(true); status.setText("Lỗi: " + e.getMessage());
        }
    }
}
