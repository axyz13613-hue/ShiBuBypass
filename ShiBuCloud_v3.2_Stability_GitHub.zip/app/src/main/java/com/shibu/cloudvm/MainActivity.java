package com.shibu.cloudvm;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private LinearLayout container;
    private TextView serverStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        container = findViewById(R.id.vmContainer);
        serverStatus = findViewById(R.id.txtServerStatus);
        findViewById(R.id.btnSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnCreateVm).setOnClickListener(v -> {
            if (Prefs.getServer(this).isEmpty()) startActivity(new Intent(this, SettingsActivity.class));
            else startActivity(new Intent(this, CreateVmActivity.class));
        });
        findViewById(R.id.btnRefresh).setOnClickListener(v -> loadVms());
    }

    @Override protected void onResume() {
        super.onResume();
        loadVms();
    }

    private void loadVms() {
        String base = Prefs.getServer(this);
        if (base.isEmpty()) {
            serverStatus.setText("Chưa kết nối máy chủ");
            renderMessage("Hãy mở ⚙ và nhập địa chỉ VPS chạy ShiBu Server.");
            return;
        }
        serverStatus.setText("Đang kết nối: " + base);
        renderMessage("Đang tải danh sách máy...");
        ApiClient.get(this, "/v1/vms", new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    try {
                        JSONArray arr = new JSONArray(body);
                        container.removeAllViews();
                        if (arr.length() == 0) {
                            renderMessage("Chưa có máy Android nào. Bấm “Tạo máy Android mới”.");
                            serverStatus.setText("● Server đang hoạt động");
                            return;
                        }
                        for (int i = 0; i < arr.length(); i++) addVmCard(arr.getJSONObject(i));
                        serverStatus.setText("● Server online • " + arr.length() + " máy");
                    } catch (Exception e) { renderMessage("Dữ liệu server không hợp lệ: " + e.getMessage()); }
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    serverStatus.setText("● Không kết nối được server");
                    renderMessage("Lỗi: " + message);
                });
            }
        });
    }

    private void renderMessage(String msg) {
        container.removeAllViews();
        TextView t = Ui.text(this, msg, 15, Color.rgb(185,172,191), false);
        t.setPadding(Ui.dp(this, 14), Ui.dp(this, 22), Ui.dp(this, 14), Ui.dp(this, 22));
        container.addView(t);
    }

    private void addVmCard(JSONObject vm) {
        try {
            String id = vm.optString("id");
            String name = vm.optString("name", "ShiBu Android");
            String version = vm.optString("android_label", vm.optString("image_id"));
            String arch = vm.optString("arch", "");
            String state = vm.optString("state", "unknown");

            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(Ui.dp(this, 18), Ui.dp(this, 17), Ui.dp(this, 18), Ui.dp(this, 17));
            card.setBackground(Ui.card(this, Color.rgb(33,23,42), Color.rgb(73,55,90), false));
            card.setLayoutParams(Ui.matchWrap(this, 10));

            TextView title = Ui.text(this, name, 19, Color.rgb(247,242,250), true);
            TextView info = Ui.text(this, version + (arch.isEmpty() ? "" : " • " + arch), 14, Color.rgb(185,172,191), false);
            info.setPadding(0, Ui.dp(this, 5), 0, 0);
            boolean running = "running".equalsIgnoreCase(state);
            TextView status = Ui.text(this, running ? "● Đang chạy trên server" : "● " + state, 14,
                    running ? Color.rgb(89,228,176) : Color.rgb(203,166,255), true);
            status.setPadding(0, Ui.dp(this, 10), 0, 0);

            Button open = new Button(this);
            open.setText(running ? "Vào máy ảo" : "Quản lý máy");
            open.setTextAllCaps(false);
            open.setTextColor(Color.rgb(44,20,59));
            open.setBackgroundResource(R.drawable.bg_primary);
            LinearLayout.LayoutParams bp = Ui.matchWrap(this, 13);
            bp.height = Ui.dp(this, 52);
            open.setLayoutParams(bp);
            open.setOnClickListener(v -> {
                Intent in = new Intent(this, VmDetailActivity.class);
                in.putExtra("vm_id", id);
                startActivity(in);
            });

            card.addView(title); card.addView(info); card.addView(status); card.addView(open);
            container.addView(card);
        } catch (Exception ignored) {}
    }
}
