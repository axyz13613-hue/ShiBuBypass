package com.shibu.cloudvm;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        EditText server = findViewById(R.id.inputServer);
        EditText token = findViewById(R.id.inputToken);
        TextView result = findViewById(R.id.txtResult);
        server.setText(Prefs.getServer(this));
        token.setText(Prefs.getToken(this));
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            String s = server.getText().toString().trim();
            String t = token.getText().toString().trim();
            if (s.endsWith("/")) s = s.substring(0, s.length() - 1);
            Prefs.save(this, s, t);
            result.setText("Đang kiểm tra...");
            ApiClient.get(this, "/health", new ApiClient.Callback() {
                @Override public void onSuccess(String health) {
                    ApiClient.get(SettingsActivity.this, "/v1/images", new ApiClient.Callback() {
                        @Override public void onSuccess(String images) { runOnUiThread(() -> result.setText("✓ Server online và API token hợp lệ. " + health)); }
                        @Override public void onError(String message) { runOnUiThread(() -> result.setText("Server online nhưng token/API lỗi: " + message)); }
                    });
                }
                @Override public void onError(String message) { runOnUiThread(() -> result.setText("Không kết nối được: " + message)); }
            });
        });
    }
}
