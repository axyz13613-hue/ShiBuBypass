package com.shibu.cloudvm;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class VmDetailActivity extends AppCompatActivity {
    private String vmId;
    private String streamUrl = "";
    private String watchedPackage = "";
    private TextView name, androidLabel, arch, status, displayInfo, stability;
    private Button enter, protectGame, unprotectGame;
    private final Handler refreshHandler = new Handler(Looper.getMainLooper());
    private boolean resumed;
    private final Runnable refreshRunnable = new Runnable() {
        @Override public void run() {
            if (!resumed) return;
            load();
            refreshHandler.postDelayed(this, 10000);
        }
    };
    private final ActivityResultLauncher<String> apkPicker = registerForActivityResult(new ActivityResultContracts.GetContent(), this::onApkPicked);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vm_detail);
        vmId = getIntent().getStringExtra("vm_id");
        if (vmId == null || vmId.isEmpty()) { finish(); return; }
        name = findViewById(R.id.txtVmName);
        androidLabel = findViewById(R.id.txtAndroid);
        arch = findViewById(R.id.txtArch);
        status = findViewById(R.id.txtStatus);
        displayInfo = findViewById(R.id.txtDisplayInfo);
        stability = findViewById(R.id.txtStability);
        enter = findViewById(R.id.btnEnter);
        protectGame = findViewById(R.id.btnProtectGame);
        unprotectGame = findViewById(R.id.btnUnprotectGame);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        enter.setOnClickListener(v -> enterVm());
        protectGame.setOnClickListener(v -> protectCurrentGame());
        unprotectGame.setOnClickListener(v -> unprotectGame());
        findViewById(R.id.btnStart).setOnClickListener(v -> action("start", false, "Đang bật máy..."));
        findViewById(R.id.btnRestart).setOnClickListener(v -> action("restart", false, "Đang khởi động lại..."));
        findViewById(R.id.btnStop).setOnClickListener(v -> action("stop", false, "Đang dừng máy..."));
        findViewById(R.id.btnInstallApk).setOnClickListener(v -> apkPicker.launch("application/vnd.android.package-archive"));
        findViewById(R.id.btnImportApps).setOnClickListener(v -> {
            Intent in = new Intent(this, ImportAppsActivity.class);
            in.putExtra("vm_id", vmId);
            startActivity(in);
        });
        findViewById(R.id.btnVmSettings).setOnClickListener(v -> {
            Intent in = new Intent(this, VmSettingsActivity.class);
            in.putExtra("vm_id", vmId);
            startActivity(in);
        });
        findViewById(R.id.btnBackup).setOnClickListener(v -> action("backup", true, "Đang sao lưu máy ảo..."));
        findViewById(R.id.btnRestore).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Khôi phục bản sao lưu gần nhất?")
                .setMessage("Dữ liệu hiện tại trong máy sẽ được thay bằng bản sao lưu gần nhất.")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Khôi phục", (d,w) -> action("restore-latest", true, "Đang khôi phục..."))
                .show());
        findViewById(R.id.btnRepair).setOnClickListener(v -> action("repair", true, "Đang sửa chữa máy..."));
        findViewById(R.id.btnReset).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Đặt lại như máy mới?")
                .setMessage("Toàn bộ ứng dụng và dữ liệu trong máy này sẽ bị xóa. Hệ thống Android sẽ được tạo lại.")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Đặt lại", (d,w) -> action("reset", true, "Đang đặt lại máy..."))
                .show());
        findViewById(R.id.btnDelete).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Xóa máy ảo?")
                .setMessage("Dữ liệu volume của máy này cũng sẽ bị xóa.")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Xóa", (d,w) -> deleteVm()).show());
        load();
    }

    @Override protected void onResume() {
        super.onResume();
        resumed = true;
        refreshHandler.removeCallbacks(refreshRunnable);
        refreshHandler.post(refreshRunnable);
    }

    @Override protected void onPause() {
        resumed = false;
        refreshHandler.removeCallbacks(refreshRunnable);
        super.onPause();
    }

    private void enterVm() {
        if (streamUrl.isEmpty()) {
            Toast.makeText(this, "Máy chưa sẵn sàng để hiển thị.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent in = new Intent(this, StreamActivity.class);
        in.putExtra("stream_url", streamUrl);
        startActivity(in);
    }

    private void load() {
        ApiClient.get(this, "/v1/vms/" + vmId, new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    try {
                        JSONObject vm = new JSONObject(body);
                        name.setText(vm.optString("name", "ShiBu Android"));
                        androidLabel.setText(vm.optString("android_label", vm.optString("image_id")));
                        arch.setText("Kiến trúc: " + vm.optString("arch", "không rõ") + "  •  " + vm.optInt("cpu", 0) + " CPU / " + vm.optInt("ram_mb", 0) + " MB");
                        displayInfo.setText(vm.optInt("width", 1080) + " × " + vm.optInt("height", 1920) + "  •  DPI " + vm.optInt("dpi", 420) + "  •  " + vm.optInt("fps", 60) + " FPS");
                        String st = vm.optString("state", "unknown");
                        boolean running = "running".equalsIgnoreCase(st);
                        boolean ready = vm.optBoolean("boot_ready", false);
                        if (running && ready) status.setText("● Android đang chạy • Sẵn sàng");
                        else if (running) status.setText("● Đang khởi động Android...");
                        else status.setText("● " + st);
                        streamUrl = vm.optString("stream_url", "");
                        enter.setEnabled(running && !streamUrl.isEmpty());
                        enter.setText(ready ? "▶  Vào máy ảo" : running ? "Android đang khởi động..." : "▶  Vào máy ảo");

                        watchedPackage = vm.optString("watch_package", "");
                        int vmRestarts = vm.optInt("watchdog_restarts", 0);
                        int appRestarts = vm.optInt("app_restarts", 0);
                        int failures = vm.optInt("health_failures", 0);
                        JSONObject live = vm.optJSONObject("live");
                        double cpuPct = live == null ? 0 : live.optDouble("cpu_percent", 0);
                        double memPct = live == null ? 0 : live.optDouble("mem_percent", 0);
                        String guard = vm.optBoolean("watchdog_enabled", false) ? "Watchdog ON" : "Watchdog OFF";
                        String game = watchedPackage.isEmpty() ? "Chưa khóa game" : "Đang giữ: " + watchedPackage;
                        stability.setText(guard + "  •  " + game + "\nCPU " + oneDecimal(cpuPct) + "%  •  RAM " + oneDecimal(memPct) + "%  •  lỗi liên tiếp " + failures + "\nTự phục hồi VM: " + vmRestarts + "  •  tự mở lại game: " + appRestarts);
                        protectGame.setEnabled(running && ready);
                        unprotectGame.setEnabled(!watchedPackage.isEmpty());
                    } catch (Exception e) { status.setText("Lỗi dữ liệu: " + e.getMessage()); }
                });
            }
            @Override public void onError(String message) { runOnUiThread(() -> status.setText("Lỗi: " + message)); }
        });
    }

    private String oneDecimal(double value) {
        return String.format(java.util.Locale.US, "%.1f", value);
    }

    private void protectCurrentGame() {
        stability.setText("Đang nhận diện game hiện đang mở trong Android...");
        ApiClient.post(this, "/v1/vms/" + vmId + "/pin-foreground", new JSONObject(), new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    Toast.makeText(VmDetailActivity.this, "Đã bật giữ game 24/7", Toast.LENGTH_LONG).show();
                    load();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    stability.setText("Không bật được giữ game: " + message);
                    new AlertDialog.Builder(VmDetailActivity.this)
                            .setTitle("Chưa nhận diện được game")
                            .setMessage("Hãy bấm Vào máy ảo, mở game và chờ game vào màn hình chính. Sau đó quay lại đây và bấm Giữ game đang mở.")
                            .setPositiveButton("OK", null)
                            .show();
                });
            }
        });
    }

    private void unprotectGame() {
        ApiClient.post(this, "/v1/vms/" + vmId + "/unpin-app", new JSONObject(), new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    Toast.makeText(VmDetailActivity.this, "Đã tắt giữ game", Toast.LENGTH_SHORT).show();
                    load();
                });
            }
            @Override public void onError(String message) { runOnUiThread(() -> stability.setText("Lỗi: " + message)); }
        });
    }

    private void action(String action, boolean longAction, String message) {
        status.setText(message);
        ApiClient.Callback cb = new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    Toast.makeText(VmDetailActivity.this, "Đã hoàn tất", Toast.LENGTH_SHORT).show();
                    load();
                });
            }
            @Override public void onError(String error) { runOnUiThread(() -> status.setText("Lỗi: " + error)); }
        };
        if (longAction) ApiClient.postLong(this, "/v1/vms/" + vmId + "/" + action, new JSONObject(), cb);
        else ApiClient.post(this, "/v1/vms/" + vmId + "/" + action, new JSONObject(), cb);
    }

    private void deleteVm() {
        status.setText("Đang xóa máy...");
        ApiClient.delete(this, "/v1/vms/" + vmId, new ApiClient.Callback() {
            @Override public void onSuccess(String body) { runOnUiThread(() -> { Toast.makeText(VmDetailActivity.this, "Đã xóa máy", Toast.LENGTH_SHORT).show(); finish(); }); }
            @Override public void onError(String message) { runOnUiThread(() -> status.setText("Lỗi: " + message)); }
        });
    }

    private void onApkPicked(Uri uri) {
        if (uri == null) return;
        status.setText("Đang gửi APK lên máy ảo...");
        ApiClient.uploadApk(this, vmId, uri, new ApiClient.Callback() {
            @Override public void onSuccess(String body) { runOnUiThread(() -> { status.setText("✓ Đã cài APK"); Toast.makeText(VmDetailActivity.this, "Cài APK thành công", Toast.LENGTH_LONG).show(); }); }
            @Override public void onError(String message) { runOnUiThread(() -> status.setText("Cài APK lỗi: " + message)); }
        });
    }
}
