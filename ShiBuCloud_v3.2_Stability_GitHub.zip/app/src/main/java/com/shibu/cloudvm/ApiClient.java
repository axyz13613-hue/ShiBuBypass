package com.shibu.cloudvm;

import android.content.Context;
import android.net.Uri;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ApiClient {
    public interface Callback {
        void onSuccess(String body);
        void onError(String message);
    }

    private static final ExecutorService IO = Executors.newCachedThreadPool();
    private ApiClient() {}

    public static void get(Context context, String path, Callback cb) {
        request(context, "GET", path, null, 30000, cb);
    }

    public static void post(Context context, String path, JSONObject body, Callback cb) {
        request(context, "POST", path, body == null ? "{}" : body.toString(), 45000, cb);
    }

    public static void postLong(Context context, String path, JSONObject body, Callback cb) {
        request(context, "POST", path, body == null ? "{}" : body.toString(), 30 * 60 * 1000, cb);
    }

    public static void delete(Context context, String path, Callback cb) {
        request(context, "DELETE", path, null, 45000, cb);
    }

    private static void request(Context context, String method, String path, String json, int readTimeout, Callback cb) {
        String base = Prefs.getServer(context);
        String token = Prefs.getToken(context);
        if (base.isEmpty()) {
            cb.onError("Chưa cấu hình địa chỉ ShiBu Server.");
            return;
        }
        IO.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(base + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod(method);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(readTimeout);
                conn.setRequestProperty("Accept", "application/json");
                if (!token.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + token);
                if (json != null) {
                    byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    conn.setFixedLengthStreamingMode(bytes.length);
                    try (OutputStream os = conn.getOutputStream()) { os.write(bytes); }
                }
                int code = conn.getResponseCode();
                String response = readStream(code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream());
                if (code >= 200 && code < 300) cb.onSuccess(response);
                else cb.onError("HTTP " + code + (response.isEmpty() ? "" : ": " + response));
            } catch (Exception e) {
                cb.onError(e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    public static void uploadApk(Context context, String vmId, Uri uri, Callback cb) {
        uploadStream(context, "/v1/vms/" + vmId + "/install-apk", "upload.apk", "application/vnd.android.package-archive", () -> context.getContentResolver().openInputStream(uri), cb);
    }

    public static void uploadBundle(Context context, String vmId, File file, Callback cb) {
        uploadStream(context, "/v1/vms/" + vmId + "/install-bundle", file.getName(), "application/zip", () -> new FileInputStream(file), cb);
    }

    private interface InputFactory { InputStream open() throws Exception; }

    private static void uploadStream(Context context, String path, String filename, String mime, InputFactory factory, Callback cb) {
        String base = Prefs.getServer(context);
        String token = Prefs.getToken(context);
        if (base.isEmpty()) {
            cb.onError("Chưa cấu hình địa chỉ ShiBu Server.");
            return;
        }
        IO.execute(() -> {
            HttpURLConnection conn = null;
            try {
                String boundary = "----ShiBu" + UUID.randomUUID().toString().replace("-", "");
                conn = (HttpURLConnection) new URL(base + path).openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setChunkedStreamingMode(1024 * 256);
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(10 * 60 * 1000);
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
                if (!token.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + token);

                try (OutputStream out = conn.getOutputStream(); InputStream raw = factory.open(); InputStream in = new BufferedInputStream(raw)) {
                    String head = "--" + boundary + "\r\n" +
                            "Content-Disposition: form-data; name=\"file\"; filename=\"" + filename.replace("\"", "") + "\"\r\n" +
                            "Content-Type: " + mime + "\r\n\r\n";
                    out.write(head.getBytes(StandardCharsets.UTF_8));
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
                }

                int code = conn.getResponseCode();
                String response = readStream(code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream());
                if (code >= 200 && code < 300) cb.onSuccess(response);
                else cb.onError("HTTP " + code + (response.isEmpty() ? "" : ": " + response));
            } catch (Exception e) {
                cb.onError(e.getClass().getSimpleName() + ": " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private static String readStream(InputStream input) throws Exception {
        if (input == null) return "";
        try (BufferedReader br = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            return sb.toString().trim();
        }
    }
}
