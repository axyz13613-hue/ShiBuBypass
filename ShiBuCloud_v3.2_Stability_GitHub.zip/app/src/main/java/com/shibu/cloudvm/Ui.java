package com.shibu.cloudvm;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    private Ui() {}
    public static int dp(Context c, int dp) { return Math.round(dp * c.getResources().getDisplayMetrics().density); }

    public static TextView text(Context c, String value, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    public static GradientDrawable card(Context c, int color, int strokeColor, boolean selected) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, 18));
        d.setStroke(dp(c, selected ? 2 : 1), strokeColor);
        return d;
    }

    public static LinearLayout.LayoutParams matchWrap(Context c, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, top);
        return p;
    }
}
