package com.shibu.cloudvm;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class CreateVmActivity extends AppCompatActivity {
    private LinearLayout container;
    private String selectedId = null;
    private String selectedLabel = null;
    private Button next;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_vm);
        container = findViewById(R.id.imageContainer);
        next = findViewById(R.id.btnNext);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        next.setOnClickListener(v -> askNameAndCreate());
        next.setEnabled(false);
        loadImages();
    }

    private void loadImages() {
        container.removeAllViews();
        TextView loading = Ui.text(this, "Đang tải danh sách hệ thống Android...", 15, Color.rgb(185,172,191), false);
        loading.setPadding(Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18));
        container.addView(loading);
        ApiClient.get(this, "/v1/images", new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    try {
                        JSONArray arr = new JSONArray(body);
                        container.removeAllViews();
                        for (int i = 0; i < arr.length(); i++) addImageCard(arr.getJSONObject(i));
                    } catch (Exception e) { showError("Không đọc được danh sách: " + e.getMessage()); }
                });
            }
            @Override public void onError(String message) { runOnUiThread(() -> showError(message)); }
        });
    }

    private void addImageCard(JSONObject image) {
        String id = image.optString("id");
        String label = image.optString("label", id);
        String arch = image.optString("arch", "");
        boolean enabled = image.optBoolean("enabled", true);
        boolean downloaded = image.optBoolean("downloaded", false);
        long sizeBytes = image.optLong("size_bytes", 0);
        String note = image.optString("note", "");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        card.setLayoutParams(Ui.matchWrap(this, 8));
        card.setBackground(Ui.card(this, Color.rgb(33,23,42), Color.rgb(73,55,90), false));
        card.setTag(id);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView title = Ui.text(this, label, 18, Color.rgb(247,242,250), true);
        TextView sub = Ui.text(this, "Kiến trúc: " + arch, 13, Color.rgb(185,172,191), false);
        sub.setPadding(0, Ui.dp(this, 4), 0, 0);
        String sizeText = sizeBytes > 0 ? String.format("Đã tải • %.1f GB", sizeBytes / 1073741824.0) : (enabled ? "Chưa tải hệ thống" : "Chưa có image tương thích");
        TextView meta = Ui.text(this, sizeText, 12, downloaded ? Color.rgb(89,228,176) : Color.rgb(203,166,255), false);
        meta.setPadding(0, Ui.dp(this, 4), 0, 0);
        texts.addView(title); texts.addView(sub); texts.addView(meta);

        Button action = new Button(this);
        action.setText(!enabled ? "Chưa hỗ trợ" : downloaded ? "Đã tải" : "Tải xuống");
        action.setTextAllCaps(false);
        action.setTextColor(downloaded ? Color.rgb(89,228,176) : Color.rgb(230,199,255));
        action.setBackgroundResource(R.drawable.bg_secondary);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(Ui.dp(this, 112), Ui.dp(this, 48));
        ap.leftMargin = Ui.dp(this, 10);
        action.setLayoutParams(ap);
        action.setEnabled(enabled && !downloaded);
        action.setOnClickListener(v -> pullImage(id, label, action));

        top.addView(texts); top.addView(action);
        card.addView(top);
        if (!note.isEmpty()) {
            TextView n = Ui.text(this, note, 12, Color.rgb(185,172,191), false);
            n.setPadding(0, Ui.dp(this, 8), 0, 0);
            card.addView(n);
        }
        card.setAlpha(enabled ? 1f : 0.58f);
        card.setOnClickListener(v -> {
            if (!enabled) {
                Toast.makeText(this, "Phiên bản này cần image tương thích riêng trên server.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (!downloaded) {
                Toast.makeText(this, "Hãy bấm Tải xuống trước.", Toast.LENGTH_SHORT).show();
                return;
            }
            selectedId = id;
            selectedLabel = label;
            next.setEnabled(true);
            refreshSelection();
        });
        container.addView(card);
    }

    private void pullImage(String id, String label, Button button) {
        button.setEnabled(false);
        button.setText("Đang tải...");
        Toast.makeText(this, "Đang tải " + label + " về server. Có thể mất vài phút.", Toast.LENGTH_LONG).show();
        ApiClient.postLong(this, "/v1/images/" + id + "/pull", new JSONObject(), new ApiClient.Callback() {
            @Override public void onSuccess(String body) {
                runOnUiThread(() -> {
                    Toast.makeText(CreateVmActivity.this, "Đã tải hệ thống " + label, Toast.LENGTH_LONG).show();
                    loadImages();
                });
            }
            @Override public void onError(String message) {
                runOnUiThread(() -> {
                    button.setEnabled(true); button.setText("Tải xuống");
                    Toast.makeText(CreateVmActivity.this, "Tải thất bại: " + message, Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void refreshSelection() {
        for (int i = 0; i < container.getChildCount(); i++) {
            View v = container.getChildAt(i);
            if (v instanceof LinearLayout && v.getTag() != null) {
                boolean selected = v.getTag().toString().equals(selectedId);
                v.setBackground(Ui.card(this, selected ? Color.rgb(44,32,56) : Color.rgb(33,23,42), selected ? Color.rgb(203,166,255) : Color.rgb(73,55,90), selected));
            }
        }
    }

    private void askNameAndCreate() {
        if (selectedId == null) return;
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText((selectedLabel == null ? "Android" : selectedLabel) + "_1");
        input.setSelectAllOnFocus(true);
        input.setPadding(Ui.dp(this, 20), Ui.dp(this, 12), Ui.dp(this, 20), Ui.dp(this, 12));
        new AlertDialog.Builder(this)
                .setTitle("Tên máy Android")
                .setMessage("Mặc định: 2 CPU, 3072 MB RAM, 1080×1920, 420 DPI, 60 FPS. Có thể chỉnh sau.")
                .setView(input)
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Tạo máy", (d, w) -> createVm(input.getText().toString().trim()))
                .show();
    }

    private void createVm(String name) {
        next.setEnabled(false);
        next.setText("Đang tạo máy...");
        try {
            JSONObject body = new JSONObject();
            body.put("image_id", selectedId);
            body.put("name", name.isEmpty() ? "ShiBu Android" : name);
            body.put("cpu", 2);
            body.put("ram_mb", 3072);
            body.put("width", 1080);
            body.put("height", 1920);
            body.put("dpi", 420);
            body.put("fps", 60);
            ApiClient.postLong(this, "/v1/vms", body, new ApiClient.Callback() {
                @Override public void onSuccess(String response) {
                    runOnUiThread(() -> {
                        Toast.makeText(CreateVmActivity.this, "Đã tạo máy Android trên server", Toast.LENGTH_LONG).show();
                        finish();
                    });
                }
                @Override public void onError(String message) {
                    runOnUiThread(() -> {
                        next.setEnabled(true); next.setText("Tiếp theo");
                        showError(message);
                    });
                }
            });
        } catch (Exception e) { showError(e.getMessage()); }
    }

    private void showError(String msg) {
        container.removeAllViews();
        TextView t = Ui.text(this, "Lỗi: " + msg, 14, Color.rgb(255,177,192), false);
        t.setPadding(Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18));
        container.addView(t);
    }
}
