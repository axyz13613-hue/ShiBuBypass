package com.shibu.cloudvm;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String NAME = "shibu_cloud_v3";
    private Prefs() {}

    public static String getServer(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE)
                .getString("server", "").trim().replaceAll("/+$", "");
    }

    public static String getToken(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE)
                .getString("token", "").trim();
    }

    public static void save(Context c, String server, String token) {
        SharedPreferences.Editor e = c.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit();
        e.putString("server", server == null ? "" : server.trim().replaceAll("/+$", ""));
        e.putString("token", token == null ? "" : token.trim());
        e.apply();
    }
}
