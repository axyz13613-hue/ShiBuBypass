package com.shibu.cloudvm;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class StreamActivity extends AppCompatActivity {
    private WebView web;
    private TextView streamStatus;
    private String url = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean destroyed;
    private ConnectivityManager connectivity;
    private ConnectivityManager.NetworkCallback networkCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_stream);
        url = getIntent().getStringExtra("stream_url");
        if (url == null) url = "";
        web = findViewById(R.id.webView);
        streamStatus = findViewById(R.id.txtStreamStatus);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                showStatus("Đang kết nối máy ảo...");
            }

            @Override public void onPageFinished(WebView view, String url) {
                showStatus("Đã kết nối • tự nối lại khi mạng chập chờn");
                handler.postDelayed(() -> hideStatus(), 2500);
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request == null || request.isForMainFrame()) scheduleReconnect("Mất kết nối • đang thử lại...");
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
                super.onReceivedHttpError(view, request, errorResponse);
                if (request == null || request.isForMainFrame()) scheduleReconnect("Stream chưa sẵn sàng • đang thử lại...");
            }

            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                showStatus("WebView vừa khởi động lại • đang phục hồi stream...");
                handler.postDelayed(() -> { if (!destroyed) recreate(); }, 1200);
                return true;
            }
        });
        findViewById(R.id.btnClose).setOnClickListener(v -> finish());
        findViewById(R.id.btnReconnect).setOnClickListener(v -> reconnectNow());
        registerNetworkCallback();
        reconnectNow();
    }

    private void showStatus(String text) {
        if (streamStatus == null) return;
        streamStatus.setText(text);
        streamStatus.setVisibility(View.VISIBLE);
    }

    private void hideStatus() {
        if (streamStatus != null) streamStatus.setVisibility(View.GONE);
    }

    private void reconnectNow() {
        handler.removeCallbacksAndMessages(null);
        if (destroyed || web == null || url.isEmpty()) return;
        showStatus("Đang kết nối lại...");
        web.stopLoading();
        web.loadUrl(url);
    }

    private void scheduleReconnect(String message) {
        if (destroyed) return;
        showStatus(message);
        handler.postDelayed(this::reconnectNow, 3000);
    }

    private void registerNetworkCallback() {
        connectivity = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity == null) return;
        networkCallback = new ConnectivityManager.NetworkCallback() {
            @Override public void onAvailable(Network network) {
                runOnUiThread(() -> {
                    showStatus("Mạng đã trở lại • đang nối lại...");
                    handler.postDelayed(StreamActivity.this::reconnectNow, 700);
                });
            }

            @Override public void onLost(Network network) {
                runOnUiThread(() -> showStatus("Mất mạng • máy ảo trên server vẫn tiếp tục chạy"));
            }
        };
        try { connectivity.registerDefaultNetworkCallback(networkCallback); } catch (Exception ignored) {}
    }

    @Override protected void onDestroy() {
        destroyed = true;
        handler.removeCallbacksAndMessages(null);
        if (connectivity != null && networkCallback != null) {
            try { connectivity.unregisterNetworkCallback(networkCallback); } catch (Exception ignored) {}
        }
        if (web != null) {
            web.stopLoading();
            web.setWebChromeClient(null);
            web.setWebViewClient(null);
            web.destroy();
        }
        super.onDestroy();
    }
}
