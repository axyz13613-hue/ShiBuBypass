package com.shibu.cloudvm;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ImportAppsActivity extends AppCompatActivity {
    private String vmId;
    private LinearLayout container;
    private TextView status;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import_apps);
        vmId = getIntent().getStringExtra("vm_id");
        if (vmId == null || vmId.isEmpty()) { finish(); return; }
        container = findViewById(R.id.appContainer);
        status = findViewById(R.id.txtImportStatus);
        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        loadApps();
    }

    private void loadApps() {
        status.setText("Đang đọc ứng dụng đã cài trên máy...");
        new Thread(() -> {
            PackageManager pm = getPackageManager();
            List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
            List<ApplicationInfo> filtered = new ArrayList<>();
            for (ApplicationInfo app : apps) {
                if (app.packageName.equals(getPackageName())) continue;
                if (pm.getLaunchIntentForPackage(app.packageName) == null) continue;
                if ((app.flags & ApplicationInfo.FLAG_SYSTEM) != 0 && (app.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) continue;
                filtered.add(app);
            }
            filtered.sort(Comparator.comparing(a -> pm.getApplicationLabel(a).toString().toLowerCase()));
            runOnUiThread(() -> {
                container.removeAllViews();
                for (ApplicationInfo app : filtered) addAppRow(pm, app);
                status.setText(filtered.isEmpty() ? "Không tìm thấy ứng dụng có thể nhập." : "Chọn ứng dụng để nhập vào máy Android trên server.");
            });
        }).start();
    }

    private void addAppRow(PackageManager pm, ApplicationInfo app) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        row.setBackground(Ui.card(this, Color.rgb(33,23,42), Color.rgb(73,55,90), false));
        row.setLayoutParams(Ui.matchWrap(this, 8));

        ImageView icon = new ImageView(this);
        icon.setImageDrawable(pm.getApplicationIcon(app));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(this, 52), Ui.dp(this, 52));
        ip.rightMargin = Ui.dp(this, 12);
        icon.setLayoutParams(ip);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView name = Ui.text(this, pm.getApplicationLabel(app).toString(), 16, Color.rgb(247,242,250), true);
        TextView pkg = Ui.text(this, app.packageName, 12, Color.rgb(185,172,191), false);
        pkg.setPadding(0, Ui.dp(this, 4), 0, 0);
        texts.addView(name); texts.addView(pkg);

        Button importBtn = new Button(this);
        importBtn.setText("Nhập");
        importBtn.setTextAllCaps(false);
        importBtn.setTextColor(Color.rgb(44,20,59));
        importBtn.setBackgroundResource(R.drawable.bg_primary);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 48));
        importBtn.setLayoutParams(bp);
        importBtn.setOnClickListener(v -> exportAndUpload(app, importBtn));

        row.addView(icon); row.addView(texts); row.addView(importBtn);
        container.addView(row);
    }

    private void exportAndUpload(ApplicationInfo app, Button button) {
        button.setEnabled(false);
        button.setText("Đang... ");
        status.setText("Đang đóng gói " + app.packageName + " từ điện thoại...");
        new Thread(() -> {
            File zip = null;
            try {
                zip = buildBundle(app);
                File finalZip = zip;
                runOnUiThread(() -> status.setText("Đang gửi ứng dụng lên máy Android trên server..."));
                ApiClient.uploadBundle(this, vmId, zip, new ApiClient.Callback() {
                    @Override public void onSuccess(String body) {
                        finalZip.delete();
                        runOnUiThread(() -> {
                            button.setEnabled(true); button.setText("Đã nhập");
                            status.setText("✓ Đã nhập ứng dụng vào máy ảo.");
                            Toast.makeText(ImportAppsActivity.this, "Nhập ứng dụng thành công", Toast.LENGTH_LONG).show();
                        });
                    }
                    @Override public void onError(String message) {
                        finalZip.delete();
                        runOnUiThread(() -> {
                            button.setEnabled(true); button.setText("Nhập");
                            status.setText("Lỗi nhập ứng dụng: " + message);
                        });
                    }
                });
            } catch (Exception e) {
                if (zip != null) zip.delete();
                String msg = e.getClass().getSimpleName() + ": " + e.getMessage();
                runOnUiThread(() -> {
                    button.setEnabled(true); button.setText("Nhập");
                    status.setText("Không thể xuất ứng dụng: " + msg);
                });
            }
        }).start();
    }

    private File buildBundle(ApplicationInfo app) throws Exception {
        File out = new File(getCacheDir(), "shibu-" + app.packageName.replace('.', '_') + "-" + System.currentTimeMillis() + ".zip");
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out))) {
            addApk(zos, new File(app.sourceDir), "base.apk");
            if (app.splitSourceDirs != null) {
                for (int i = 0; i < app.splitSourceDirs.length; i++) {
                    addApk(zos, new File(app.splitSourceDirs[i]), String.format("split-%03d.apk", i + 1));
                }
            }
        }
        return out;
    }

    private void addApk(ZipOutputStream zos, File apk, String name) throws Exception {
        if (!apk.exists()) throw new IllegalStateException("Không đọc được " + apk.getAbsolutePath());
        zos.putNextEntry(new ZipEntry(name));
        try (FileInputStream in = new FileInputStream(apk)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) zos.write(buf, 0, n);
        }
        zos.closeEntry();
    }
}
