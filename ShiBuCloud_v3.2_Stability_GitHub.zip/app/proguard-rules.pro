# ShiBu Cloud v3 - no custom ProGuard rules required for debug/MVP.
