#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -f .env ]; then
  echo "Thiếu server/.env. Hãy: cp .env.example .env rồi sửa SHIBU_API_TOKEN và SHIBU_PUBLIC_HOST"
  exit 1
fi
set -a
. ./.env
set +a
exec .venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8787
