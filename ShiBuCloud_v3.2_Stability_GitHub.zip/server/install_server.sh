#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "== ShiBu Cloud v3 Server preflight =="
if [ "$(uname -s)" != "Linux" ]; then echo "Cần Linux host."; exit 1; fi
if ! command -v docker >/dev/null 2>&1; then
  echo "Chưa có Docker. Cài Docker Engine trước rồi chạy lại."
  exit 1
fi
if ! docker info >/dev/null 2>&1; then
  echo "Docker có nhưng user hiện tại không truy cập được daemon."
  echo "Hãy dùng sudo hoặc thêm user vào group docker."
  exit 1
fi
if [ ! -e /dev/kvm ]; then
  echo "KHÔNG có /dev/kvm -> VPS này chưa hỗ trợ KVM/nested virtualization."
  echo "ShiBu Cloud VM kiểu Android emulator sẽ không chạy được trên host này."
  exit 2
fi

echo "✓ Docker OK"
echo "✓ /dev/kvm OK"
python3 -m venv .venv
. .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
if [ ! -f .env ]; then
  cp .env.example .env
  TOKEN=$(python3 - <<'PY'
import secrets
print(secrets.token_urlsafe(36))
PY
)
  sed -i "s#replace-with-a-long-random-token#$TOKEN#" .env
  echo "Đã tạo .env với token ngẫu nhiên. Hãy sửa SHIBU_PUBLIC_HOST trước khi chạy."
fi
mkdir -p data

echo
echo "Cài đặt xong. Chạy:"
echo "  cd $(pwd)"
echo "  nano .env"
echo "  ./run.sh"
echo
echo "Mở firewall TCP 8787 và dải stream 6200:6999 chỉ cho IP/VPN cần thiết."
