from __future__ import annotations

import json
import os
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import threading
import time
import uuid
import zipfile
from pathlib import Path
from typing import Any

from fastapi import Depends, FastAPI, File, Header, HTTPException, Request, UploadFile
from pydantic import BaseModel, Field

BASE = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("SHIBU_DATA_DIR", str(BASE / "data"))).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)
REGISTRY = DATA_DIR / "vms.json"
BACKUP_DIR = DATA_DIR / "backups"
BACKUP_DIR.mkdir(parents=True, exist_ok=True)
IMAGES_FILE = Path(os.getenv("SHIBU_IMAGES_FILE", str(BASE / "images.json"))).resolve()
API_TOKEN = os.getenv("SHIBU_API_TOKEN", "change-me-now")
PUBLIC_HOST = os.getenv("SHIBU_PUBLIC_HOST", "").strip()
STREAM_SCHEME = os.getenv("SHIBU_STREAM_SCHEME", "http").strip() or "http"
STREAM_PORT_MIN = int(os.getenv("SHIBU_STREAM_PORT_MIN", "6200"))
STREAM_PORT_MAX = int(os.getenv("SHIBU_STREAM_PORT_MAX", "6999"))
DEFAULT_DEVICE = os.getenv("SHIBU_EMULATOR_DEVICE", "Samsung Galaxy S10")
DEFAULT_DATA_PARTITION = os.getenv("SHIBU_DATA_PARTITION", "16384m").strip() or "16384m"

WATCHDOG_INTERVAL = max(10, int(os.getenv("SHIBU_WATCHDOG_INTERVAL", "20")))
WATCHDOG_FAIL_LIMIT = max(2, int(os.getenv("SHIBU_WATCHDOG_FAIL_LIMIT", "3")))
WATCHDOG_RESTART_COOLDOWN = max(60, int(os.getenv("SHIBU_WATCHDOG_RESTART_COOLDOWN", "180")))
APP_RESTART_COOLDOWN = max(20, int(os.getenv("SHIBU_APP_RESTART_COOLDOWN", "45")))
WATCHDOG_ENABLED = os.getenv("SHIBU_WATCHDOG_ENABLED", "true").lower() not in ("0", "false", "no")

app = FastAPI(title="ShiBu Cloud v3.2 Stability Server", version="3.2.0")
_watchdog_stop = threading.Event()
_watchdog_thread: threading.Thread | None = None


class VmCreate(BaseModel):
    image_id: str
    name: str = Field(default="ShiBu Android", min_length=1, max_length=80)
    cpu: int = Field(default=2, ge=1, le=16)
    ram_mb: int = Field(default=3072, ge=1024, le=32768)
    width: int = Field(default=1080, ge=480, le=3840)
    height: int = Field(default=1920, ge=800, le=4096)
    dpi: int = Field(default=420, ge=120, le=960)
    fps: int = Field(default=60, ge=15, le=120)


class GameWatchRequest(BaseModel):
    package_name: str | None = Field(default=None, max_length=180)


class VmSettings(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=80)
    cpu: int | None = Field(default=None, ge=1, le=16)
    ram_mb: int | None = Field(default=None, ge=1024, le=32768)
    width: int | None = Field(default=None, ge=480, le=3840)
    height: int | None = Field(default=None, ge=800, le=4096)
    dpi: int | None = Field(default=None, ge=120, le=960)
    fps: int | None = Field(default=None, ge=15, le=120)


def require_token(authorization: str | None = Header(default=None)) -> None:
    if API_TOKEN in ("", "change-me-now"):
        raise HTTPException(503, "Server chưa đặt SHIBU_API_TOKEN an toàn.")
    expected = f"Bearer {API_TOKEN}"
    if not authorization or not secrets.compare_digest(authorization, expected):
        raise HTTPException(401, "API token không hợp lệ.")


def run(cmd: list[str], timeout: int = 120, check: bool = True) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=check)


def docker_available() -> bool:
    try:
        return run(["docker", "info"], timeout=10).returncode == 0
    except Exception:
        return False


def load_images_raw() -> list[dict[str, Any]]:
    try:
        return json.loads(IMAGES_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        raise HTTPException(500, f"Không đọc được images.json: {e}")


def docker_image_info(image: str) -> tuple[bool, int]:
    if not image:
        return False, 0
    try:
        p = run(["docker", "image", "inspect", "--format", "{{.Size}}", image], timeout=10)
        return True, int((p.stdout or "0").strip() or 0)
    except Exception:
        return False, 0


def image_payload(item: dict[str, Any]) -> dict[str, Any]:
    downloaded, size_bytes = docker_image_info(item.get("image", ""))
    return {**item, "downloaded": downloaded, "size_bytes": size_bytes}


def image_by_id(image_id: str) -> dict[str, Any]:
    for item in load_images_raw():
        if item.get("id") == image_id:
            return item
    raise HTTPException(404, "Không tìm thấy Android image.")


def load_registry() -> dict[str, dict[str, Any]]:
    if not REGISTRY.exists():
        return {}
    try:
        return json.loads(REGISTRY.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_registry(data: dict[str, dict[str, Any]]) -> None:
    tmp = REGISTRY.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(REGISTRY)


def free_port() -> int:
    used = {int(v.get("stream_port", 0)) for v in load_registry().values()}
    for port in range(STREAM_PORT_MIN, STREAM_PORT_MAX + 1):
        if port in used:
            continue
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("0.0.0.0", port))
            return port
        except OSError:
            pass
        finally:
            s.close()
    raise HTTPException(503, "Không còn cổng stream trống.")


def container_state(name: str) -> str:
    try:
        p = run(["docker", "inspect", "-f", "{{.State.Status}}", name], timeout=10)
        return p.stdout.strip() or "unknown"
    except Exception:
        return "missing"


def adb_exec(vm: dict[str, Any], shell: str, timeout: int = 30, check: bool = True) -> subprocess.CompletedProcess:
    return run(["docker", "exec", vm["container_name"], "bash", "-lc", shell], timeout=timeout, check=check)


def adb_ready(vm: dict[str, Any]) -> bool:
    if container_state(vm["container_name"]) != "running":
        return False
    try:
        p = adb_exec(vm, "adb get-state && adb shell getprop sys.boot_completed", timeout=8)
        return "device" in p.stdout and p.stdout.strip().endswith("1")
    except Exception:
        return False


def container_metrics(vm: dict[str, Any]) -> dict[str, Any]:
    name = vm.get("container_name", "")
    if not name or container_state(name) != "running":
        return {"cpu_percent": 0.0, "mem_percent": 0.0, "mem_usage": "", "oom_killed": False}
    cpu = mem = 0.0
    mem_usage = ""
    oom_killed = False
    try:
        p = run(["docker", "stats", "--no-stream", "--format", "{{json .}}", name], timeout=8)
        data = json.loads((p.stdout or "{}").strip() or "{}")
        cpu = float(str(data.get("CPUPerc", "0")).replace("%", "") or 0)
        mem = float(str(data.get("MemPerc", "0")).replace("%", "") or 0)
        mem_usage = str(data.get("MemUsage", ""))
    except Exception:
        pass
    try:
        p = run(["docker", "inspect", "-f", "{{.State.OOMKilled}}", name], timeout=5)
        oom_killed = (p.stdout or "").strip().lower() == "true"
    except Exception:
        pass
    return {"cpu_percent": round(cpu, 1), "mem_percent": round(mem, 1), "mem_usage": mem_usage, "oom_killed": oom_killed}


def foreground_package(vm: dict[str, Any]) -> str:
    """Best effort: return the currently focused Android application package."""
    if not adb_ready(vm):
        return ""
    commands = [
        "adb shell dumpsys window windows | grep -E 'mCurrentFocus|mFocusedApp' | tail -n 1",
        "adb shell dumpsys activity activities | grep mResumedActivity | tail -n 1",
    ]
    for command in commands:
        try:
            out = (adb_exec(vm, command, timeout=8, check=False).stdout or "").strip()
            # Matches com.example.game/.MainActivity and similar forms.
            m = re.search(r"([A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+)/", out)
            if m:
                pkg = m.group(1)
                if pkg not in ("com.android.launcher3", "com.google.android.apps.nexuslauncher"):
                    return pkg
        except Exception:
            pass
    return ""


def app_running(vm: dict[str, Any], package_name: str) -> bool:
    if not package_name or not adb_ready(vm):
        return False
    try:
        p = adb_exec(vm, f"adb shell pidof {package_name}", timeout=8, check=False)
        return bool((p.stdout or "").strip())
    except Exception:
        return False


def launch_package(vm: dict[str, Any], package_name: str) -> bool:
    if not package_name or not adb_ready(vm):
        return False
    try:
        # monkey resolves the launcher activity without hardcoding it.
        p = adb_exec(vm, f"adb shell monkey -p {package_name} -c android.intent.category.LAUNCHER 1", timeout=15, check=False)
        return p.returncode == 0
    except Exception:
        return False


def persist_vm_runtime(vm_id: str, updates: dict[str, Any]) -> dict[str, Any] | None:
    reg = load_registry()
    vm = reg.get(vm_id)
    if not vm:
        return None
    vm.update(updates)
    reg[vm_id] = vm
    save_registry(reg)
    return vm


def watchdog_iteration() -> None:
    now = int(time.time())
    reg = load_registry()
    changed = False
    for vm_id, vm in list(reg.items()):
        vm.setdefault("desired_state", "running" if container_state(vm.get("container_name", "")) == "running" else "stopped")
        vm.setdefault("health_failures", 0)
        vm.setdefault("watchdog_restarts", 0)
        vm.setdefault("app_restarts", 0)
        vm["last_watchdog_at"] = now
        changed = True
        if vm.get("desired_state") != "running":
            vm["health_failures"] = 0
            continue
        if now < int(vm.get("maintenance_until", 0) or 0):
            continue
        state = container_state(vm["container_name"])
        # Docker process died/missing although VM is supposed to be running.
        if state == "missing":
            last = int(vm.get("last_watchdog_restart_at", 0) or 0)
            if now - last >= WATCHDOG_RESTART_COOLDOWN:
                try:
                    image = image_by_id(vm["image_id"])
                    vm["container_id"] = create_container(vm, image)
                    vm["watchdog_restarts"] = int(vm.get("watchdog_restarts", 0)) + 1
                    vm["last_watchdog_restart_at"] = now
                    vm["last_restart_reason"] = "container_missing"
                    vm["boot_grace_until"] = now + 240
                    vm["health_failures"] = 0
                except Exception as e:
                    vm["last_watchdog_error"] = str(e)[-300:]
            continue
        if state != "running":
            try:
                run(["docker", "start", vm["container_name"]], timeout=60, check=False)
                vm["watchdog_restarts"] = int(vm.get("watchdog_restarts", 0)) + 1
                vm["last_watchdog_restart_at"] = now
                vm["last_restart_reason"] = f"container_{state}"
                vm["boot_grace_until"] = now + 240
            except Exception as e:
                vm["last_watchdog_error"] = str(e)[-300:]
            continue

        if now < int(vm.get("boot_grace_until", 0) or 0):
            vm["health_failures"] = 0
            vm["last_metrics"] = container_metrics(vm)
            continue

        healthy = adb_ready(vm)
        metrics = container_metrics(vm)
        if metrics.get("oom_killed"):
            healthy = False
            vm["last_restart_reason"] = "oom_killed"
        if healthy:
            vm["health_failures"] = 0
            vm["last_healthy_at"] = now
            vm.pop("last_watchdog_error", None)
        else:
            vm["health_failures"] = int(vm.get("health_failures", 0)) + 1

        if int(vm.get("health_failures", 0)) >= WATCHDOG_FAIL_LIMIT:
            last = int(vm.get("last_watchdog_restart_at", 0) or 0)
            if now - last >= WATCHDOG_RESTART_COOLDOWN:
                try:
                    run(["docker", "restart", "-t", "10", vm["container_name"]], timeout=60, check=False)
                    vm["watchdog_restarts"] = int(vm.get("watchdog_restarts", 0)) + 1
                    vm["last_watchdog_restart_at"] = now
                    vm["last_restart_reason"] = vm.get("last_restart_reason") or "android_unresponsive"
                    vm["boot_grace_until"] = now + 240
                    vm["health_failures"] = 0
                except Exception as e:
                    vm["last_watchdog_error"] = str(e)[-300:]
            continue

        package_name = str(vm.get("watch_package", "") or "").strip()
        if healthy and package_name:
            if app_running(vm, package_name):
                vm["last_app_healthy_at"] = now
            else:
                last_app = int(vm.get("last_app_restart_at", 0) or 0)
                if now - last_app >= APP_RESTART_COOLDOWN and launch_package(vm, package_name):
                    vm["app_restarts"] = int(vm.get("app_restarts", 0)) + 1
                    vm["last_app_restart_at"] = now
        vm["last_metrics"] = metrics
    if changed:
        save_registry(reg)


def watchdog_loop() -> None:
    # Delay slightly so Docker/API startup can settle.
    _watchdog_stop.wait(5)
    while not _watchdog_stop.is_set():
        try:
            watchdog_iteration()
        except Exception:
            pass
        _watchdog_stop.wait(WATCHDOG_INTERVAL)


@app.on_event("startup")
def start_watchdog() -> None:
    global _watchdog_thread
    if not WATCHDOG_ENABLED or (_watchdog_thread and _watchdog_thread.is_alive()):
        return
    _watchdog_stop.clear()
    _watchdog_thread = threading.Thread(target=watchdog_loop, name="shibu-watchdog", daemon=True)
    _watchdog_thread.start()


@app.on_event("shutdown")
def stop_watchdog() -> None:
    _watchdog_stop.set()


def public_host(request: Request) -> str:
    if PUBLIC_HOST:
        return PUBLIC_HOST
    return request.url.hostname or "127.0.0.1"


def vm_payload(vm: dict[str, Any], request: Request) -> dict[str, Any]:
    image = image_by_id(vm["image_id"])
    state = container_state(vm["container_name"])
    ready = False
    if state == "running":
        last_healthy = int(vm.get("last_healthy_at", 0) or 0)
        if WATCHDOG_ENABLED and last_healthy:
            ready = int(time.time()) - last_healthy <= WATCHDOG_INTERVAL * 3
        else:
            ready = adb_ready(vm)
    stream_url = ""
    if state == "running":
        stream_url = f"{STREAM_SCHEME}://{public_host(request)}:{vm['stream_port']}/?autoconnect=true&resize=scale&password={vm['vnc_password']}"
    live = vm.get("last_metrics") or container_metrics(vm)
    return {
        **vm,
        "android_label": image.get("label", vm["image_id"]),
        "arch": image.get("arch", ""),
        "engine": image.get("engine", ""),
        "state": state,
        "boot_ready": ready,
        "stream_url": stream_url,
        "watchdog_enabled": WATCHDOG_ENABLED,
        "live": live,
    }


def get_vm_or_404(vm_id: str) -> dict[str, Any]:
    vm = load_registry().get(vm_id)
    if not vm:
        raise HTTPException(404, "Không tìm thấy máy ảo.")
    return vm


def container_command(vm: dict[str, Any], image: dict[str, Any]) -> list[str]:
    width = int(vm.get("width", 1080))
    height = int(vm.get("height", 1920))
    dpi = int(vm.get("dpi", 420))
    cpu = max(1, int(vm.get("cpu", 2)))
    ram_mb = max(1024, int(vm.get("ram_mb", 3072)))
    # Leave headroom for noVNC/ADB/container services instead of giving all RAM to the emulator.
    emulator_ram = max(768, min(8192, ram_mb - 768, int(ram_mb * 0.72)))
    emulator_cores = max(1, min(8, cpu))
    return [
        "docker", "run", "-d",
        "--name", vm["container_name"],
        "--restart", "unless-stopped",
        "--device", "/dev/kvm",
        "--cpus", str(cpu),
        "--memory", f"{ram_mb}m",
        "--shm-size", "2g",
        "-p", f"{vm['stream_port']}:6080",
        "-e", f"EMULATOR_DEVICE={DEFAULT_DEVICE}",
        "-e", "WEB_VNC=true",
        "-e", f"VNC_PASSWORD={vm['vnc_password']}",
        "-e", "EMULATOR_NO_SKIN=true",
        "-e", f"EMULATOR_DATA_PARTITION={DEFAULT_DATA_PARTITION}",
        "-e", f"EMULATOR_ADDITIONAL_ARGS=-no-snapshot-save -no-boot-anim -accel on -gpu swiftshader_indirect -netspeed full -cores {emulator_cores} -memory {emulator_ram} -skin {width}x{height}",
        "-v", f"{vm['volume_name']}:/home/androidusr",
        image["image"],
    ]


def create_container(vm: dict[str, Any], image: dict[str, Any]) -> str:
    result = run(container_command(vm, image), timeout=300)
    return result.stdout.strip()


def apply_runtime_settings(vm: dict[str, Any]) -> None:
    state = container_state(vm["container_name"])
    if state == "missing":
        return
    try:
        run([
            "docker", "update",
            "--cpus", str(vm.get("cpu", 2)),
            "--memory", f"{vm.get('ram_mb', 3072)}m",
            vm["container_name"],
        ], timeout=30)
    except Exception:
        pass
    if state != "running" or not adb_ready(vm):
        return
    width = int(vm.get("width", 1080))
    height = int(vm.get("height", 1920))
    dpi = int(vm.get("dpi", 420))
    fps = int(vm.get("fps", 60))
    command = (
        "adb shell wm size {w}x{h}; "
        "adb shell wm density {dpi}; "
        "adb shell settings put system peak_refresh_rate {fps}; "
        "adb shell settings put system min_refresh_rate {fps}; "
        "adb shell settings put global window_animation_scale 0.5; "
        "adb shell settings put global transition_animation_scale 0.5; "
        "adb shell settings put global animator_duration_scale 0.5"
    ).format(w=width, h=height, dpi=dpi, fps=fps)
    adb_exec(vm, command, timeout=30, check=False)


@app.get("/health")
def health() -> dict[str, Any]:
    return {
        "ok": True,
        "service": "ShiBu Cloud v3.2 Stability Server",
        "version": "3.2.0",
        "watchdog": WATCHDOG_ENABLED,
        "watchdog_interval": WATCHDOG_INTERVAL,
        "docker": docker_available(),
        "kvm": Path("/dev/kvm").exists(),
        "time": int(time.time()),
    }


@app.get("/v1/images", dependencies=[Depends(require_token)])
def list_images() -> list[dict[str, Any]]:
    return [image_payload(i) for i in load_images_raw()]


@app.post("/v1/images/{image_id}/pull", dependencies=[Depends(require_token)])
def pull_image(image_id: str) -> dict[str, Any]:
    if not docker_available():
        raise HTTPException(503, "Docker chưa hoạt động.")
    image = image_by_id(image_id)
    if not image.get("enabled") or not image.get("image"):
        raise HTTPException(400, "Phiên bản Android này chưa có image khả dụng trên server.")
    try:
        result = run(["docker", "pull", image["image"]], timeout=1800)
        return {"ok": True, "output": (result.stdout or "")[-2000:], **image_payload(image)}
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, f"Tải image thất bại: {(e.stderr or e.stdout).strip()[-2000:]}")


@app.get("/v1/vms", dependencies=[Depends(require_token)])
def list_vms(request: Request) -> list[dict[str, Any]]:
    return [vm_payload(v, request) for v in load_registry().values()]


@app.get("/v1/vms/{vm_id}", dependencies=[Depends(require_token)])
def get_vm(vm_id: str, request: Request) -> dict[str, Any]:
    return vm_payload(get_vm_or_404(vm_id), request)


@app.post("/v1/vms", dependencies=[Depends(require_token)])
def create_vm(spec: VmCreate, request: Request) -> dict[str, Any]:
    if not docker_available():
        raise HTTPException(503, "Docker chưa hoạt động hoặc user chạy API không có quyền Docker.")
    if not Path("/dev/kvm").exists():
        raise HTTPException(503, "Server không có /dev/kvm. Cần VPS/bare-metal hỗ trợ KVM/nested virtualization.")
    image = image_by_id(spec.image_id)
    if not image.get("enabled") or not image.get("image"):
        raise HTTPException(400, "Android image này chưa được bật/cấu hình trên server.")
    downloaded, _ = docker_image_info(image["image"])
    if not downloaded:
        raise HTTPException(409, "Hãy bấm Tải xuống hệ thống Android trước khi tạo máy.")

    vm_id = uuid.uuid4().hex[:12]
    vm = {
        "id": vm_id,
        "name": spec.name,
        "image_id": spec.image_id,
        "container_name": f"shibu_vm_{vm_id}",
        "volume_name": f"shibu_data_{vm_id}",
        "stream_port": free_port(),
        "vnc_password": secrets.token_urlsafe(12).replace("-", "A").replace("_", "B")[:16],
        "cpu": spec.cpu,
        "ram_mb": spec.ram_mb,
        "width": spec.width,
        "height": spec.height,
        "dpi": spec.dpi,
        "fps": spec.fps,
        "desired_state": "running",
        "health_failures": 0,
        "watchdog_restarts": 0,
        "app_restarts": 0,
        "watch_package": "",
        "boot_grace_until": int(time.time()) + 240,
        "maintenance_until": 0,
        "created_at": int(time.time()),
    }
    try:
        vm["container_id"] = create_container(vm, image)
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, f"Docker tạo máy thất bại: {(e.stderr or e.stdout).strip()[-2000:]}")
    except Exception as e:
        raise HTTPException(500, f"Docker tạo máy thất bại: {e}")
    reg = load_registry()
    reg[vm_id] = vm
    save_registry(reg)
    return vm_payload(vm, request)


@app.post("/v1/vms/{vm_id}/settings", dependencies=[Depends(require_token)])
def update_settings(vm_id: str, spec: VmSettings, request: Request) -> dict[str, Any]:
    reg = load_registry()
    vm = reg.get(vm_id)
    if not vm:
        raise HTTPException(404, "Không tìm thấy máy ảo.")
    changes = spec.model_dump(exclude_none=True)
    vm.update(changes)
    reg[vm_id] = vm
    save_registry(reg)
    apply_runtime_settings(vm)
    return vm_payload(vm, request)


@app.post("/v1/vms/{vm_id}/start", dependencies=[Depends(require_token)])
def start_vm(vm_id: str, request: Request) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    vm["desired_state"] = "running"
    vm["boot_grace_until"] = int(time.time()) + 240
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    try:
        if container_state(vm["container_name"]) == "missing":
            image = image_by_id(vm["image_id"])
            vm["container_id"] = create_container(vm, image)
            reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
        else:
            run(["docker", "start", vm["container_name"]], timeout=60)
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, (e.stderr or e.stdout).strip())
    vm["desired_state"] = "running"
    vm["health_failures"] = 0
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    return vm_payload(vm, request)


@app.post("/v1/vms/{vm_id}/stop", dependencies=[Depends(require_token)])
def stop_vm(vm_id: str, request: Request) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    vm["desired_state"] = "stopped"
    vm["health_failures"] = 0
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    try:
        run(["docker", "stop", "-t", "20", vm["container_name"]], timeout=45)
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, (e.stderr or e.stdout).strip())
    vm["desired_state"] = "stopped"
    vm["health_failures"] = 0
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    return vm_payload(vm, request)


@app.post("/v1/vms/{vm_id}/restart", dependencies=[Depends(require_token)])
def restart_vm(vm_id: str, request: Request) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    vm["desired_state"] = "running"
    vm["boot_grace_until"] = int(time.time()) + 240
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    try:
        run(["docker", "restart", "-t", "20", vm["container_name"]], timeout=60)
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, (e.stderr or e.stdout).strip())
    vm["desired_state"] = "running"
    vm["health_failures"] = 0
    vm["last_manual_restart_at"] = int(time.time())
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    return vm_payload(vm, request)


@app.post("/v1/vms/{vm_id}/repair", dependencies=[Depends(require_token)])
def repair_vm(vm_id: str, request: Request) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    image = image_by_id(vm["image_id"])
    state = container_state(vm["container_name"])
    try:
        if state == "missing":
            vm["container_id"] = create_container(vm, image)
        elif state != "running":
            run(["docker", "start", vm["container_name"]], timeout=60)
        apply_runtime_settings(vm)
        vm["desired_state"] = "running"
        vm["health_failures"] = 0
        vm["boot_grace_until"] = int(time.time()) + 240
        vm["maintenance_until"] = 0
        reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
        return vm_payload(vm, request)
    except Exception as e:
        raise HTTPException(500, f"Sửa chữa máy thất bại: {e}")


@app.post("/v1/vms/{vm_id}/reset", dependencies=[Depends(require_token)])
def reset_vm(vm_id: str, request: Request) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    image = image_by_id(vm["image_id"])
    vm["maintenance_until"] = int(time.time()) + 900
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    try:
        run(["docker", "rm", "-f", vm["container_name"]], timeout=60, check=False)
        run(["docker", "volume", "rm", "-f", vm["volume_name"]], timeout=60, check=False)
        vm["container_id"] = create_container(vm, image)
        vm["desired_state"] = "running"
        vm["health_failures"] = 0
        vm["boot_grace_until"] = int(time.time()) + 240
        vm["maintenance_until"] = 0
        vm["reset_at"] = int(time.time())
        reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
        return vm_payload(vm, request)
    except Exception as e:
        raise HTTPException(500, f"Đặt lại máy thất bại: {e}")


@app.get("/v1/vms/{vm_id}/backups", dependencies=[Depends(require_token)])
def list_backups(vm_id: str) -> list[dict[str, Any]]:
    get_vm_or_404(vm_id)
    items = []
    for p in sorted(BACKUP_DIR.glob(f"{vm_id}-*.tar.gz"), reverse=True):
        items.append({"name": p.name, "size_bytes": p.stat().st_size, "created_at": int(p.stat().st_mtime)})
    return items


@app.post("/v1/vms/{vm_id}/backup", dependencies=[Depends(require_token)])
def backup_vm(vm_id: str) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    vm["maintenance_until"] = int(time.time()) + 1200
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    state = container_state(vm["container_name"])
    was_running = state == "running"
    stamp = time.strftime("%Y%m%d-%H%M%S")
    filename = f"{vm_id}-{stamp}.tar.gz"
    try:
        if was_running:
            run(["docker", "stop", "-t", "20", vm["container_name"]], timeout=45)
        run([
            "docker", "run", "--rm",
            "-v", f"{vm['volume_name']}:/data:ro",
            "-v", f"{BACKUP_DIR}:/backup",
            "alpine:3.20", "sh", "-lc",
            f"cd /data && tar czf /backup/{filename} ."
        ], timeout=900)
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, f"Sao lưu lỗi: {(e.stderr or e.stdout).strip()[-2000:]}")
    finally:
        if was_running:
            run(["docker", "start", vm["container_name"]], timeout=60, check=False)
        reg = load_registry()
        current = reg.get(vm_id, vm)
        current["maintenance_until"] = 0
        if was_running:
            current["boot_grace_until"] = int(time.time()) + 240
        reg[vm_id] = current
        save_registry(reg)
    path = BACKUP_DIR / filename
    return {"ok": True, "name": filename, "size_bytes": path.stat().st_size if path.exists() else 0}


@app.post("/v1/vms/{vm_id}/restore-latest", dependencies=[Depends(require_token)])
def restore_latest(vm_id: str, request: Request) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    vm["maintenance_until"] = int(time.time()) + 1200
    reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
    backups = sorted(BACKUP_DIR.glob(f"{vm_id}-*.tar.gz"), reverse=True)
    if not backups:
        reg = load_registry()
        current = reg.get(vm_id, vm)
        current["maintenance_until"] = 0
        reg[vm_id] = current
        save_registry(reg)
        raise HTTPException(404, "Chưa có bản sao lưu nào cho máy này.")
    backup = backups[0]
    try:
        run(["docker", "stop", "-t", "20", vm["container_name"]], timeout=45, check=False)
        run([
            "docker", "run", "--rm",
            "-v", f"{vm['volume_name']}:/data",
            "-v", f"{BACKUP_DIR}:/backup:ro",
            "alpine:3.20", "sh", "-lc",
            f"rm -rf /data/* /data/.[!.]* /data/..?* 2>/dev/null || true; cd /data && tar xzf /backup/{backup.name}"
        ], timeout=900)
        run(["docker", "start", vm["container_name"]], timeout=60)
        vm["desired_state"] = "running"
        vm["health_failures"] = 0
        vm["boot_grace_until"] = int(time.time()) + 240
        vm["maintenance_until"] = 0
        reg = load_registry(); reg[vm_id] = vm; save_registry(reg)
        return vm_payload(vm, request)
    except subprocess.CalledProcessError as e:
        reg = load_registry()
        current = reg.get(vm_id, vm)
        current["maintenance_until"] = 0
        reg[vm_id] = current
        save_registry(reg)
        raise HTTPException(500, f"Khôi phục lỗi: {(e.stderr or e.stdout).strip()[-2000:]}")


@app.get("/v1/vms/{vm_id}/stability", dependencies=[Depends(require_token)])
def vm_stability(vm_id: str) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    return {
        "watchdog_enabled": WATCHDOG_ENABLED,
        "desired_state": vm.get("desired_state", "running"),
        "health_failures": int(vm.get("health_failures", 0)),
        "watchdog_restarts": int(vm.get("watchdog_restarts", 0)),
        "app_restarts": int(vm.get("app_restarts", 0)),
        "watch_package": vm.get("watch_package", ""),
        "last_healthy_at": int(vm.get("last_healthy_at", 0) or 0),
        "last_watchdog_at": int(vm.get("last_watchdog_at", 0) or 0),
        "last_restart_reason": vm.get("last_restart_reason", ""),
        "metrics": container_metrics(vm),
    }


@app.post("/v1/vms/{vm_id}/pin-foreground", dependencies=[Depends(require_token)])
def pin_foreground(vm_id: str, spec: GameWatchRequest, request: Request) -> dict[str, Any]:
    reg = load_registry()
    vm = reg.get(vm_id)
    if not vm:
        raise HTTPException(404, "Không tìm thấy máy ảo.")
    package_name = (spec.package_name or "").strip() or foreground_package(vm)
    if not package_name:
        raise HTTPException(409, "Không nhận diện được game đang mở. Hãy mở game trong máy ảo rồi thử lại.")
    if not re.fullmatch(r"[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+", package_name):
        raise HTTPException(400, "Package name không hợp lệ.")
    vm["watch_package"] = package_name
    vm["last_app_restart_at"] = 0
    reg[vm_id] = vm
    save_registry(reg)
    return vm_payload(vm, request)


@app.post("/v1/vms/{vm_id}/unpin-app", dependencies=[Depends(require_token)])
def unpin_app(vm_id: str, request: Request) -> dict[str, Any]:
    reg = load_registry()
    vm = reg.get(vm_id)
    if not vm:
        raise HTTPException(404, "Không tìm thấy máy ảo.")
    vm["watch_package"] = ""
    reg[vm_id] = vm
    save_registry(reg)
    return vm_payload(vm, request)


@app.delete("/v1/vms/{vm_id}", dependencies=[Depends(require_token)])
def delete_vm(vm_id: str) -> dict[str, bool]:
    reg = load_registry()
    vm = reg.get(vm_id)
    if not vm:
        raise HTTPException(404, "Không tìm thấy máy ảo.")
    vm["desired_state"] = "deleted"
    vm["maintenance_until"] = int(time.time()) + 600
    reg[vm_id] = vm
    save_registry(reg)
    try:
        run(["docker", "rm", "-f", vm["container_name"]], timeout=60, check=False)
        run(["docker", "volume", "rm", "-f", vm["volume_name"]], timeout=60, check=False)
    finally:
        reg.pop(vm_id, None)
        save_registry(reg)
    return {"ok": True}


@app.post("/v1/vms/{vm_id}/install-apk", dependencies=[Depends(require_token)])
def install_apk(vm_id: str, file: UploadFile = File(...)) -> dict[str, Any]:
    vm = get_vm_or_404(vm_id)
    if container_state(vm["container_name"]) != "running":
        raise HTTPException(409, "Máy Android chưa chạy.")
    if not (file.filename or "").lower().endswith(".apk"):
        raise HTTPException(400, "Chỉ nhận file .apk.")
    tmp_dir = Path(tempfile.mkdtemp(prefix="shibu-apk-"))
    host_apk = tmp_dir / "upload.apk"
    try:
        with host_apk.open("wb") as out:
            shutil.copyfileobj(file.file, out)
        if host_apk.stat().st_size > 4 * 1024 * 1024 * 1024:
            raise HTTPException(413, "APK quá lớn.")
        run(["docker", "cp", str(host_apk), f"{vm['container_name']}:/tmp/shibu-upload.apk"], timeout=120)
        result = adb_exec(vm, "adb wait-for-device && adb install -r /tmp/shibu-upload.apk; rc=$?; rm -f /tmp/shibu-upload.apk; exit $rc", timeout=300)
        return {"ok": True, "output": result.stdout.strip()[-1500:]}
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, f"ADB install lỗi: {(e.stderr or e.stdout).strip()[-1500:]}")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


@app.post("/v1/vms/{vm_id}/install-bundle", dependencies=[Depends(require_token)])
def install_bundle(vm_id: str, file: UploadFile = File(...)) -> dict[str, Any]:
    """Install base.apk + split APKs exported from an app already installed on the phone."""
    vm = get_vm_or_404(vm_id)
    if container_state(vm["container_name"]) != "running":
        raise HTTPException(409, "Máy Android chưa chạy.")
    if not (file.filename or "").lower().endswith(".zip"):
        raise HTTPException(400, "Bundle nhập ứng dụng phải là .zip.")
    tmp_dir = Path(tempfile.mkdtemp(prefix="shibu-bundle-"))
    archive = tmp_dir / "bundle.zip"
    extracted = tmp_dir / "apks"
    extracted.mkdir()
    try:
        with archive.open("wb") as out:
            shutil.copyfileobj(file.file, out)
        if archive.stat().st_size > 4 * 1024 * 1024 * 1024:
            raise HTTPException(413, "Bundle quá lớn.")
        with zipfile.ZipFile(archive) as zf:
            apk_members = [m for m in zf.infolist() if not m.is_dir() and m.filename.lower().endswith(".apk")]
            if not apk_members:
                raise HTTPException(400, "Bundle không chứa APK.")
            for idx, member in enumerate(apk_members):
                target = extracted / f"part-{idx:03d}.apk"
                with zf.open(member) as src, target.open("wb") as dst:
                    shutil.copyfileobj(src, dst)
        run(["docker", "exec", vm["container_name"], "bash", "-lc", "rm -rf /tmp/shibu-bundle && mkdir -p /tmp/shibu-bundle"], timeout=30)
        for apk in sorted(extracted.glob("*.apk")):
            run(["docker", "cp", str(apk), f"{vm['container_name']}:/tmp/shibu-bundle/{apk.name}"], timeout=120)
        result = adb_exec(vm, "adb wait-for-device && adb install-multiple -r /tmp/shibu-bundle/*.apk; rc=$?; rm -rf /tmp/shibu-bundle; exit $rc", timeout=360)
        return {"ok": True, "parts": len(list(extracted.glob('*.apk'))), "output": result.stdout.strip()[-1500:]}
    except zipfile.BadZipFile:
        raise HTTPException(400, "Bundle ZIP bị lỗi.")
    except subprocess.CalledProcessError as e:
        raise HTTPException(500, f"ADB install-multiple lỗi: {(e.stderr or e.stdout).strip()[-1500:]}")
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)
