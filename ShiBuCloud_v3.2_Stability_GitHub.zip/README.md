# ShiBu Cloud v3.2 Stability

ShiBu Cloud v3.2 là bản CloudVM ưu tiên treo Android/game lâu trên VPS/KVM. Ứng dụng Android trên điện thoại chỉ là bảng điều khiển và màn hình stream; VM tiếp tục chạy trên server khi người dùng thoát app hoặc tắt điện thoại, miễn server vẫn hoạt động.

## Điểm mới v3.2

- Server watchdog chạy độc lập với app điện thoại, mặc định kiểm tra mỗi 20 giây.
- Nếu container dừng/mất hoặc Android/ADB mất phản hồi liên tiếp, watchdog tự phục hồi/restart với cooldown để tránh vòng lặp boot.
- Boot grace 4 phút giúp Android có đủ thời gian khởi động trước khi bị đánh dấu lỗi.
- Trạng thái mong muốn `running/stopped` giúp watchdog không tự bật lại VM mà người dùng chủ động tắt.
- Chế độ bảo vệ game: mở game trong VM rồi bấm **Giữ game đang mở**. Server nhận diện package hiện tại, kiểm tra process và tự mở lại nếu game bị đóng.
- Dashboard ổn định hiển thị CPU, RAM, số lần watchdog phục hồi VM, số lần tự mở lại game và lỗi sức khỏe liên tiếp.
- Stream WebView tự thử nối lại khi mạng điện thoại chập chờn; VM trên server không bị dừng khi mất mạng phía điện thoại.
- Preset **Treo 24/7**, **Cân bằng**, **Hiệu năng** để chọn tài nguyên phù hợp.
- Backup/restore/reset có maintenance lock để watchdog không can thiệp giữa lúc bảo trì dữ liệu.

## Kiến trúc

`Điện thoại -> ShiBu Cloud APK -> ShiBu Server API -> Docker/KVM Android VM -> game/app`

VM sử dụng volume riêng để giữ dữ liệu. Server cần Docker và `/dev/kvm`. Nếu VPS không hỗ trợ KVM/nested virtualization, engine mặc định không thể tạo VM Android.

## Cài server

```bash
cd server
sudo bash install_server.sh
sudo nano /opt/shibu-cloud/server/.env
sudo systemctl restart shibu-cloud
```

Bắt buộc đổi `SHIBU_API_TOKEN` thành chuỗi dài ngẫu nhiên và đặt `SHIBU_PUBLIC_HOST` thành IP/domain mà điện thoại truy cập được.

Các biến watchdog có thể chỉnh trong `.env`:

```env
SHIBU_WATCHDOG_ENABLED=true
SHIBU_WATCHDOG_INTERVAL=20
SHIBU_WATCHDOG_FAIL_LIMIT=3
SHIBU_WATCHDOG_RESTART_COOLDOWN=180
SHIBU_APP_RESTART_COOLDOWN=45
```

Không nên đặt watchdog quá nhanh vì Android emulator có thể cần vài phút để boot sau restart.

## Dùng chế độ giữ game

1. Bật VM và chờ trạng thái **Android đang chạy • Sẵn sàng**.
2. Bấm **Vào máy ảo**, mở game và chờ game vào màn hình chính.
3. Quay lại trang chi tiết VM, bấm **Giữ game đang mở**.
4. ShiBu Server ghi nhớ package của game. Nếu process game mất trong khi Android vẫn khỏe, watchdog sẽ thử mở lại game sau cooldown.
5. Bấm **Tắt giữ game** khi không muốn watchdog tự mở game nữa.

## Preset gợi ý

- **Treo 24/7:** 2 CPU, 4 GB RAM, 720p, 30 FPS. Nhẹ và phù hợp VPS vừa phải.
- **Cân bằng:** 4 CPU, 4 GB RAM, 900p, 45 FPS.
- **Hiệu năng:** 4 CPU, 6 GB RAM, 1080p, 60 FPS. Cần VPS đủ mạnh.

Các con số chỉ là preset khởi điểm. Nếu host CPU bị quá tải hoặc không có GPU tăng tốc, hạ độ phân giải/FPS thường ổn định hơn việc tăng FPS.

## Giới hạn thực tế

Watchdog có thể phục hồi container, Android/ADB và tự mở lại game khi process game mất, nhưng không thể bảo đảm mọi game sẽ không bao giờ crash hoặc treo. Một game có thể đứng hình trong khi process vẫn tồn tại, hoặc máy chủ có thể thiếu CPU/RAM/GPU. Với engine mặc định dùng software rendering, game 3D nặng sẽ không đạt hiệu năng như hạ tầng cloud phone có GPU chuyên dụng.

Bản này tập trung vào khả năng tự phục hồi và quản lý 24/7; không thực hiện bypass anti-cheat, Play Integrity hay cơ chế phát hiện của game.
