# ShiBu Bypass Universal v3.1

Cross-platform URL resolver with a redesigned dark mint/cyan UI based on the ShiBu avatar.

## What it does
- Resolves standard HTTP/HTTPS redirects (301/302/303/307/308).
- Unwraps common outbound-link wrappers from Facebook/Messenger/Instagram/Google/YouTube/Discord.
- Shows redirect chain and current/final URL.
- Detects auth/session links, shortlinks, redirect-like URLs, and likely manual-verification pages without exposing token values.
- Local history and clipboard actions.
- Embedded WebView on Android/iOS/macOS; external browser fallback on Windows/Linux.
- Lets the user return the current WebView URL after manually completing a page.

## What it intentionally does not automate
CAPTCHA, anti-bot challenges, mandatory timers, ad/verification gates, access controls, or key-generation systems must be completed manually.

## Platforms
Android, iOS, Windows, macOS, Linux source is included via Flutter CI bootstrap.

Notes:
- Android output is a normal release APK.
- iOS CI output is unsigned. A physical iPhone requires Apple signing before installation.
- Desktop output is packaged as ZIP/TAR artifacts.
