# Third-party notices

ShiBu Cloud uses the **NewBlackbox / BlackBox virtual engine** at build time.

- Repository: https://github.com/ALEX5402/NewBlackbox
- Pinned source commit: `89b59836c66f173756a4ae258cf379a957649820`
- License reported by the upstream repository: Apache License 2.0
- Upstream credits include BlackBox, VirtualApp, VirtualAPK, Dobby, xDL, BlackReflection and FreeReflection.

The `tools/fetch_engine.sh` script fetches the pinned upstream source and copies the required engine modules into the build workspace. The engine source itself is not embedded in this ZIP before that script is run.

Do not remove upstream copyright/license notices from fetched source files when redistributing a built or source-complete derivative.
