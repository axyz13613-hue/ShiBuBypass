# Changelog

## v2.1.0

- Nút **Cài APK** được đổi thành **Thêm ứng dụng**.
- Thêm lựa chọn **Ứng dụng đã cài trên máy**.
- Có thể chọn nhiều app/game cùng lúc rồi đưa vào không gian ảo ShiBu Cloud.
- Tự ẩn app đã có trong không gian ảo để tránh thêm trùng.
- Chỉ quét app người dùng có biểu tượng launcher; không yêu cầu quyền `QUERY_ALL_PACKAGES`.
- Vẫn giữ tùy chọn cài từ file APK.
- Dữ liệu của app gốc trên máy không bị sao chép/chỉnh sửa; bản trong ShiBu Cloud bắt đầu bằng dữ liệu riêng.
