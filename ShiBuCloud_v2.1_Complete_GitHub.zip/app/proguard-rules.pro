# ShiBu Cloud - currently no shrinking rules required because minifyEnabled=false.
