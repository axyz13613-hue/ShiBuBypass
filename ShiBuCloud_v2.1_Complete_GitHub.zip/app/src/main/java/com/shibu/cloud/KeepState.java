package com.shibu.cloud;

import android.content.Context;
import android.content.SharedPreferences;

public final class KeepState {
    private static final String PREFS = "shibu_keep_state";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_PACKAGE = "package";

    private KeepState() {}

    public static void set(Context context, boolean enabled, String packageName) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        editor.putBoolean(KEY_ENABLED, enabled);
        if (packageName == null) editor.remove(KEY_PACKAGE); else editor.putString(KEY_PACKAGE, packageName);
        editor.apply();
    }

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
    }

    public static String getPackage(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_PACKAGE, null);
    }
}
