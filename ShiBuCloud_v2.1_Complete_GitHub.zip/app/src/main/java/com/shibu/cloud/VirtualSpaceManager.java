package com.shibu.cloud;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;

public final class VirtualSpaceManager {
    public static final int USER_ID = 0;
    private static volatile VirtualSpaceManager instance;
    private final Context context;

    public static final class DeviceApp {
        public final String label;
        public final String packageName;

        DeviceApp(String label, String packageName) {
            this.label = label;
            this.packageName = packageName;
        }
    }

    private VirtualSpaceManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public static VirtualSpaceManager get(Context context) {
        if (instance == null) {
            synchronized (VirtualSpaceManager.class) {
                if (instance == null) instance = new VirtualSpaceManager(context);
            }
        }
        return instance;
    }

    public List<PackageInfo> getInstalledPackages() {
        try {
            List<PackageInfo> list = BlackBoxCore.get().getInstalledPackages(0, USER_ID);
            return list == null ? new ArrayList<>() : list;
        } catch (Throwable error) {
            return new ArrayList<>();
        }
    }

    /**
     * Returns user-installed apps on the real phone that have a launcher activity
     * and are not already present in the ShiBu Cloud virtual user.
     *
     * Using an explicit MAIN/LAUNCHER query avoids requesting QUERY_ALL_PACKAGES.
     */
    public List<DeviceApp> getImportableDeviceApps() {
        PackageManager pm = context.getPackageManager();
        Intent launcherQuery = new Intent(Intent.ACTION_MAIN);
        launcherQuery.addCategory(Intent.CATEGORY_LAUNCHER);

        List<ResolveInfo> resolved;
        try {
            resolved = pm.queryIntentActivities(launcherQuery, 0);
        } catch (Throwable error) {
            resolved = Collections.emptyList();
        }

        Set<String> alreadyVirtual = new HashSet<>();
        for (PackageInfo info : getInstalledPackages()) {
            if (info != null && info.packageName != null) alreadyVirtual.add(info.packageName);
        }

        Set<String> seen = new HashSet<>();
        List<DeviceApp> result = new ArrayList<>();

        for (ResolveInfo resolveInfo : resolved) {
            if (resolveInfo == null || resolveInfo.activityInfo == null) continue;
            ApplicationInfo ai = resolveInfo.activityInfo.applicationInfo;
            if (ai == null || ai.packageName == null) continue;

            String pkg = ai.packageName;
            if (pkg.equals(context.getPackageName())) continue;
            if (alreadyVirtual.contains(pkg) || !seen.add(pkg)) continue;

            // Keep the picker focused on apps/games the user actually installed.
            boolean system = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            boolean updatedSystem = (ai.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0;
            if (system && !updatedSystem) continue;

            CharSequence label = ai.loadLabel(pm);
            result.add(new DeviceApp(label == null ? pkg : label.toString(), pkg));
        }

        result.sort(Comparator.comparing(app -> app.label.toLowerCase(java.util.Locale.ROOT)));
        return result;
    }

    public InstallResult installApk(File apk) {
        return BlackBoxCore.get().installPackageAsUser(apk, USER_ID);
    }

    /** Import an app that is already installed on the physical phone. */
    public InstallResult installFromDevice(String packageName) {
        return BlackBoxCore.get().installPackageAsUser(packageName, USER_ID);
    }

    public boolean launch(String packageName) {
        try {
            return BlackBoxCore.get().launchApk(packageName, USER_ID);
        } catch (Throwable error) {
            return false;
        }
    }

    public boolean isRunning(String packageName) {
        try {
            return BlackBoxCore.isRunningApplication(packageName, USER_ID);
        } catch (Throwable error) {
            return false;
        }
    }

    public void clearData(String packageName) {
        try {
            BlackBoxCore.get().clearPackage(packageName, USER_ID);
        } catch (Throwable ignored) {
        }
    }

    public void uninstall(String packageName) {
        try {
            BlackBoxCore.get().uninstallPackageAsUser(packageName, USER_ID);
        } catch (Throwable ignored) {
        }
    }

    public Drawable loadIcon(PackageInfo info) {
        try {
            if (info.applicationInfo != null) return info.applicationInfo.loadIcon(context.getPackageManager());
        } catch (Throwable ignored) {
        }
        return context.getDrawable(android.R.drawable.sym_def_app_icon);
    }

    public String loadLabel(PackageInfo info) {
        try {
            if (info.applicationInfo != null) {
                CharSequence label = info.applicationInfo.loadLabel(context.getPackageManager());
                if (label != null) return label.toString();
            }
        } catch (Throwable ignored) {
        }
        return info.packageName;
    }
}
