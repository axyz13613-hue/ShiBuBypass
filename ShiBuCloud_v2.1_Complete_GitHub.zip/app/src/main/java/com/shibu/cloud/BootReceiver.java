package com.shibu.cloud;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!KeepState.isEnabled(context)) return;
        String pkg = KeepState.getPackage(context);
        if (pkg == null || pkg.isEmpty()) return;

        Intent service = new Intent(context, GameKeepAliveService.class);
        service.setAction(GameKeepAliveService.ACTION_WATCH_PACKAGE);
        service.putExtra(GameKeepAliveService.EXTRA_PACKAGE, pkg);
        ContextCompat.startForegroundService(context, service);
    }
}
