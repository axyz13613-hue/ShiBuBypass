package com.shibu.cloud;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import top.niunaijun.blackbox.entity.pm.InstallResult;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_INSTALL = 1001;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private LinearLayout appListContainer;
    private TextView appCount;
    private TextView emptyState;
    private TextView keepStatus;
    private VirtualSpaceManager virtualSpace;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        virtualSpace = VirtualSpaceManager.get(this);
        appListContainer = findViewById(R.id.appListContainer);
        appCount = findViewById(R.id.appCount);
        emptyState = findViewById(R.id.emptyState);
        keepStatus = findViewById(R.id.keepStatus);

        findViewById(R.id.btnInstall).setOnClickListener(v -> showAddAppDialog());
        findViewById(R.id.btnRefresh).setOnClickListener(v -> loadVirtualApps());
        findViewById(R.id.btnBattery).setOnClickListener(v -> requestBatteryExemption());
        findViewById(R.id.btnStopKeep).setOnClickListener(v -> stopWatching());
        findViewById(R.id.btnLaunchWatched).setOnClickListener(v -> launchWatched());

        updateKeepStatus();
        loadVirtualApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateKeepStatus();
    }

    private void showAddAppDialog() {
        String[] sources = {
                "Ứng dụng đã cài trên máy",
                "Chọn file APK"
        };
        new AlertDialog.Builder(this)
                .setTitle("Thêm ứng dụng vào ShiBu Cloud")
                .setItems(sources, (dialog, which) -> {
                    if (which == 0) showDeviceAppPicker();
                    else pickAndInstallApk();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    private void showDeviceAppPicker() {
        Toast.makeText(this, "Đang quét ứng dụng trên máy…", Toast.LENGTH_SHORT).show();
        executor.execute(() -> {
            List<VirtualSpaceManager.DeviceApp> apps = virtualSpace.getImportableDeviceApps();
            runOnUiThread(() -> {
                if (apps.isEmpty()) {
                    Toast.makeText(this, "Không tìm thấy ứng dụng mới để thêm", Toast.LENGTH_LONG).show();
                    return;
                }

                CharSequence[] names = new CharSequence[apps.size()];
                boolean[] checked = new boolean[apps.size()];
                for (int i = 0; i < apps.size(); i++) {
                    VirtualSpaceManager.DeviceApp app = apps.get(i);
                    names[i] = app.label + "\n" + app.packageName;
                }

                AlertDialog picker = new AlertDialog.Builder(this)
                        .setTitle("Ứng dụng trên máy")
                        .setMultiChoiceItems(names, checked, (dialog, which, isChecked) -> checked[which] = isChecked)
                        .setNegativeButton("Hủy", null)
                        .setPositiveButton("Thêm đã chọn", null)
                        .create();

                picker.setOnShowListener(ignored -> picker.getButton(AlertDialog.BUTTON_POSITIVE)
                        .setOnClickListener(v -> {
                            List<VirtualSpaceManager.DeviceApp> selected = new java.util.ArrayList<>();
                            for (int i = 0; i < apps.size(); i++) {
                                if (checked[i]) selected.add(apps.get(i));
                            }
                            if (selected.isEmpty()) {
                                Toast.makeText(this, "Hãy chọn ít nhất 1 ứng dụng", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            picker.dismiss();
                            importDeviceApps(selected);
                        }));
                picker.show();
            });
        });
    }

    private void importDeviceApps(List<VirtualSpaceManager.DeviceApp> apps) {
        Toast.makeText(this, "Đang thêm " + apps.size() + " ứng dụng…", Toast.LENGTH_LONG).show();
        executor.execute(() -> {
            int success = 0;
            StringBuilder failed = new StringBuilder();

            for (VirtualSpaceManager.DeviceApp app : apps) {
                try {
                    InstallResult result = virtualSpace.installFromDevice(app.packageName);
                    if (result != null && result.success) {
                        success++;
                    } else {
                        if (failed.length() > 0) failed.append(", ");
                        failed.append(app.label);
                    }
                } catch (Throwable error) {
                    if (failed.length() > 0) failed.append(", ");
                    failed.append(app.label);
                }
            }

            int finalSuccess = success;
            runOnUiThread(() -> {
                if (failed.length() == 0) {
                    Toast.makeText(this, "Đã thêm " + finalSuccess + " ứng dụng vào ShiBu Cloud", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this,
                            "Đã thêm " + finalSuccess + "/" + apps.size() + ". Không thêm được: " + failed,
                            Toast.LENGTH_LONG).show();
                }
                loadVirtualApps();
            });
        });
    }

    private void loadVirtualApps() {
        emptyState.setText("Đang quét ứng dụng ảo…");
        emptyState.setVisibility(View.VISIBLE);
        appListContainer.removeAllViews();

        executor.execute(() -> {
            List<PackageInfo> apps = virtualSpace.getInstalledPackages();
            runOnUiThread(() -> renderApps(apps));
        });
    }

    private void renderApps(List<PackageInfo> apps) {
        appListContainer.removeAllViews();
        appCount.setText(apps.size() + " ứng dụng");
        emptyState.setText(R.string.empty_apps);
        emptyState.setVisibility(apps.isEmpty() ? View.VISIBLE : View.GONE);

        for (PackageInfo info : apps) {
            if (info == null || info.packageName == null) continue;
            addAppRow(virtualSpace.loadLabel(info), info.packageName, virtualSpace.loadIcon(info));
        }
    }

    private void addAppRow(String label, String packageName, Drawable icon) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(10), dp(10));
        row.setBackgroundResource(R.drawable.bg_app_row);
        row.setClickable(true);
        row.setFocusable(true);
        row.setElevation(dp(1));

        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        rowParams.setMargins(0, 0, 0, dp(10));
        row.setLayoutParams(rowParams);

        ImageView appIcon = new ImageView(this);
        appIcon.setImageDrawable(icon);
        appIcon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams iconParams = new LinearLayout.LayoutParams(dp(48), dp(48));
        iconParams.setMargins(0, 0, dp(12), 0);
        row.addView(appIcon, iconParams);

        LinearLayout textBlock = new LinearLayout(this);
        textBlock.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);

        TextView title = new TextView(this);
        title.setText(label);
        title.setTextColor(ContextCompat.getColor(this, R.color.text_primary));
        title.setTextSize(16);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);

        TextView subtitle = new TextView(this);
        subtitle.setText(packageName);
        subtitle.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        subtitle.setTextSize(12);
        subtitle.setSingleLine(true);

        textBlock.addView(title);
        textBlock.addView(subtitle);
        row.addView(textBlock, textParams);

        TextView keepChip = new TextView(this);
        keepChip.setText("Treo");
        keepChip.setTextSize(12);
        keepChip.setTextColor(ContextCompat.getColor(this, R.color.mint_700));
        keepChip.setGravity(Gravity.CENTER);
        keepChip.setBackgroundResource(R.drawable.bg_count_chip);
        keepChip.setPadding(dp(10), dp(6), dp(10), dp(6));
        keepChip.setOnClickListener(v -> startWatching(packageName, true));
        LinearLayout.LayoutParams keepParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        keepParams.setMargins(dp(6), 0, dp(6), 0);
        row.addView(keepChip, keepParams);

        TextView more = new TextView(this);
        more.setText("⋮");
        more.setTextSize(24);
        more.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        more.setGravity(Gravity.CENTER);
        more.setOnClickListener(v -> showAppActions(label, packageName));
        row.addView(more, new LinearLayout.LayoutParams(dp(36), dp(48)));

        row.setOnClickListener(v -> startWatching(packageName, true));
        appListContainer.addView(row);
    }

    private void showAppActions(String label, String packageName) {
        String[] items = {"Mở + treo game", "Chỉ mở", "Dừng treo", "Xóa dữ liệu ảo", "Gỡ khỏi ShiBu Cloud"};
        new AlertDialog.Builder(this)
                .setTitle(label)
                .setItems(items, (dialog, which) -> {
                    if (which == 0) startWatching(packageName, true);
                    else if (which == 1) launchOnly(packageName);
                    else if (which == 2) stopWatching();
                    else if (which == 3) confirmClear(packageName);
                    else if (which == 4) confirmUninstall(packageName);
                })
                .show();
    }

    private void confirmClear(String packageName) {
        new AlertDialog.Builder(this)
                .setTitle("Xóa dữ liệu ảo?")
                .setMessage("Dữ liệu của ứng dụng trong ShiBu Cloud sẽ bị xóa.")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Xóa", (d, w) -> executor.execute(() -> {
                    virtualSpace.clearData(packageName);
                    runOnUiThread(() -> Toast.makeText(this, "Đã yêu cầu xóa dữ liệu", Toast.LENGTH_SHORT).show());
                }))
                .show();
    }

    private void confirmUninstall(String packageName) {
        new AlertDialog.Builder(this)
                .setTitle("Gỡ ứng dụng ảo?")
                .setMessage("Ứng dụng sẽ bị gỡ khỏi không gian ShiBu Cloud.")
                .setNegativeButton("Hủy", null)
                .setPositiveButton("Gỡ", (d, w) -> executor.execute(() -> {
                    virtualSpace.uninstall(packageName);
                    if (packageName.equals(KeepState.getPackage(this))) KeepState.set(this, false, null);
                    runOnUiThread(() -> {
                        updateKeepStatus();
                        loadVirtualApps();
                    });
                }))
                .show();
    }

    private void startWatching(String packageName, boolean launchNow) {
        KeepState.set(this, true, packageName);
        Intent service = new Intent(this, GameKeepAliveService.class);
        service.setAction(GameKeepAliveService.ACTION_WATCH_PACKAGE);
        service.putExtra(GameKeepAliveService.EXTRA_PACKAGE, packageName);
        ContextCompat.startForegroundService(this, service);
        updateKeepStatus();

        if (launchNow) launchOnly(packageName);
    }

    private void launchOnly(String packageName) {
        executor.execute(() -> {
            boolean ok = virtualSpace.launch(packageName);
            if (!ok) runOnUiThread(() -> Toast.makeText(this, "Không khởi chạy được ứng dụng ảo", Toast.LENGTH_LONG).show());
        });
    }

    private void launchWatched() {
        String pkg = KeepState.getPackage(this);
        if (pkg == null || pkg.isEmpty()) {
            Toast.makeText(this, "Chưa chọn game để treo", Toast.LENGTH_SHORT).show();
            return;
        }
        startWatching(pkg, true);
    }

    private void stopWatching() {
        KeepState.set(this, false, null);
        Intent service = new Intent(this, GameKeepAliveService.class);
        service.setAction(GameKeepAliveService.ACTION_STOP_WATCH);
        startService(service);
        updateKeepStatus();
    }

    private void updateKeepStatus() {
        boolean enabled = KeepState.isEnabled(this);
        String pkg = KeepState.getPackage(this);
        boolean batteryOk = isIgnoringBatteryOptimizations();

        if (enabled && pkg != null) {
            keepStatus.setText("● Đang treo: " + pkg + (batteryOk ? " · Pin OK" : " · cần tắt tối ưu pin"));
            keepStatus.setTextColor(ContextCompat.getColor(this, R.color.mint_700));
        } else {
            keepStatus.setText("○ Chưa chọn game để treo" + (batteryOk ? " · Pin OK" : " · nên tắt tối ưu pin"));
            keepStatus.setTextColor(ContextCompat.getColor(this, R.color.text_secondary));
        }
    }

    private boolean isIgnoringBatteryOptimizations() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void requestBatteryExemption() {
        try {
            if (isIgnoringBatteryOptimizations()) {
                Toast.makeText(this, "ShiBu Cloud đã được bỏ tối ưu pin", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Throwable error) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Throwable ignored) {
                Toast.makeText(this, "Không mở được cài đặt pin", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void pickAndInstallApk() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/vnd.android.package-archive");
        startActivityForResult(intent, REQUEST_INSTALL);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_INSTALL || resultCode != RESULT_OK || data == null || data.getData() == null) return;

        Uri uri = data.getData();
        executor.execute(() -> {
            File tempApk = new File(getCacheDir(), "shibu_install_" + System.currentTimeMillis() + ".apk");
            try (InputStream in = getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(tempApk)) {
                if (in == null) throw new IllegalStateException("Không đọc được APK");
                byte[] buffer = new byte[1024 * 64];
                int length;
                while ((length = in.read(buffer)) != -1) out.write(buffer, 0, length);

                InstallResult result = virtualSpace.installApk(tempApk);
                runOnUiThread(() -> {
                    if (result != null && result.success) {
                        Toast.makeText(this, "Đã thêm " + result.packageName + " vào ShiBu Cloud", Toast.LENGTH_SHORT).show();
                        loadVirtualApps();
                    } else {
                        String msg = result == null ? "Không rõ nguyên nhân" : result.msg;
                        Toast.makeText(this, "Cài APK thất bại: " + msg, Toast.LENGTH_LONG).show();
                    }
                });
            } catch (Throwable error) {
                runOnUiThread(() -> Toast.makeText(this, "Không thể đọc/cài APK: " + error.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                //noinspection ResultOfMethodCallIgnored
                tempApk.delete();
            }
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
