package com.shibu.cloud;

import android.app.Application;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.util.Log;

import androidx.multidex.MultiDex;

import java.io.File;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;

public class VApp extends Application {
    private static final String TAG = "ShiBuCloud";

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);

        try {
            BlackBoxCore.get().closeCodeInit();
        } catch (Throwable ignored) {
        }

        try {
            BlackBoxCore.get().onBeforeMainApplicationAttach(this, base);
        } catch (Throwable error) {
            Log.w(TAG, "before attach hook failed", error);
        }

        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {
                @Override
                public String getHostPackageName() {
                    return base.getPackageName();
                }

                @Override
                public boolean isEnableDaemonService() {
                    return true;
                }

                @Override
                public boolean isHideRoot() {
                    return false;
                }

                @Override
                public boolean isUseVpnNetwork() {
                    return false;
                }

                @Override
                public boolean isDisableFlagSecure() {
                    return false;
                }

                @Override
                public boolean requestInstallPackage(File file, int userId) {
                    return false;
                }
            });
        } catch (Throwable error) {
            Log.e(TAG, "BlackBox attach failed", error);
        }

        try {
            BlackBoxCore.get().onAfterMainApplicationAttach(this, base);
        } catch (Throwable error) {
            Log.w(TAG, "after attach hook failed", error);
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannels();

        try {
            BlackBoxCore.get().doCreate();
        } catch (Throwable error) {
            Log.e(TAG, "BlackBox create failed", error);
        }
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                NotificationChannel keep = new NotificationChannel(
                        GameKeepAliveService.CHANNEL_ID,
                        "ShiBu Cloud - Treo game",
                        NotificationManager.IMPORTANCE_LOW
                );
                keep.setDescription("Giữ không gian ảo và game được chọn hoạt động");
                manager.createNotificationChannel(keep);
            }
        }
    }
}
