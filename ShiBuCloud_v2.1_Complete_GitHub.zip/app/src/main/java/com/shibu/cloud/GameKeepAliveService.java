package com.shibu.cloud;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;

import androidx.core.app.NotificationCompat;

public class GameKeepAliveService extends Service {
    public static final String CHANNEL_ID = "shibu_keep_game";
    public static final String ACTION_WATCH_PACKAGE = "com.shibu.cloud.WATCH_PACKAGE";
    public static final String ACTION_STOP_WATCH = "com.shibu.cloud.STOP_WATCH";
    public static final String EXTRA_PACKAGE = "package";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private WifiManager.WifiLock wifiLock;
    private String packageName;
    private long lastLaunchAttempt;
    private int consecutiveFailures;

    private final Runnable watchdog = new Runnable() {
        @Override
        public void run() {
            tick();
            handler.postDelayed(this, 20_000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        acquireLocks();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP_WATCH.equals(intent.getAction())) {
            KeepState.set(this, false, null);
            stopSelf();
            return START_NOT_STICKY;
        }

        String requested = intent == null ? null : intent.getStringExtra(EXTRA_PACKAGE);
        if (requested == null || requested.isEmpty()) requested = KeepState.getPackage(this);
        packageName = requested;

        if (packageName == null || packageName.isEmpty()) {
            stopSelf();
            return START_NOT_STICKY;
        }

        KeepState.set(this, true, packageName);
        startForeground(2002, buildNotification("Đang giữ " + packageName));
        handler.removeCallbacks(watchdog);
        handler.post(watchdog);
        return START_STICKY;
    }

    private void tick() {
        if (packageName == null || packageName.isEmpty()) return;

        VirtualSpaceManager manager = VirtualSpaceManager.get(this);
        boolean running = manager.isRunning(packageName);
        if (running) {
            consecutiveFailures = 0;
            updateNotification("Game đang hoạt động");
            return;
        }

        long now = SystemClock.elapsedRealtime();
        long cooldown = consecutiveFailures >= 3 ? 120_000L : 30_000L;
        if (now - lastLaunchAttempt < cooldown) {
            updateNotification("Đang chờ trước khi thử mở lại");
            return;
        }

        lastLaunchAttempt = now;
        boolean launched = manager.launch(packageName);
        if (launched) {
            consecutiveFailures = 0;
            updateNotification("Đã khởi động lại game");
        } else {
            consecutiveFailures++;
            updateNotification("Không mở lại được · lần thử " + consecutiveFailures);
        }
    }

    private void acquireLocks() {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ShiBuCloud:GameKeepAlive");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Throwable ignored) {
        }

        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ShiBuCloud:WifiKeepAlive");
                wifiLock.setReferenceCounted(false);
                wifiLock.acquire();
            }
        } catch (Throwable ignored) {
        }
    }

    private Notification buildNotification(String message) {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent content = PendingIntent.getActivity(this, 0, open, flags);

        Intent stop = new Intent(this, GameKeepAliveService.class);
        stop.setAction(ACTION_STOP_WATCH);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, flags);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_cloud)
                .setContentTitle("ShiBu Cloud · Treo game")
                .setContentText(message)
                .setContentIntent(content)
                .addAction(0, "Dừng treo", stopPi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    private void updateNotification(String message) {
        android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(2002, buildNotification(message));
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (KeepState.isEnabled(this) && packageName != null) {
            Intent restart = new Intent(getApplicationContext(), GameKeepAliveService.class);
            restart.setAction(ACTION_WATCH_PACKAGE);
            restart.putExtra(EXTRA_PACKAGE, packageName);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(restart);
                else startService(restart);
            } catch (Throwable ignored) {
            }
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {
        }
        try {
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
        } catch (Throwable ignored) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
