#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENGINE_DIR="$ROOT/.engine-src"
REPO="https://github.com/ALEX5402/NewBlackbox.git"
COMMIT="89b59836c66f173756a4ae258cf379a957649820"

rm -rf "$ENGINE_DIR"
git clone --no-tags --filter=blob:none "$REPO" "$ENGINE_DIR"
git -C "$ENGINE_DIR" checkout "$COMMIT"

rm -rf "$ROOT/Bcore" "$ROOT/black-reflection" "$ROOT/compiler"
cp -a "$ENGINE_DIR/Bcore" "$ROOT/Bcore"
cp -a "$ENGINE_DIR/black-reflection" "$ROOT/black-reflection"
cp -a "$ENGINE_DIR/compiler" "$ROOT/compiler"

mkdir -p "$ROOT/gradle/wrapper"
cp "$ENGINE_DIR/gradlew" "$ROOT/gradlew"
cp "$ENGINE_DIR/gradlew.bat" "$ROOT/gradlew.bat"
cp -a "$ENGINE_DIR/gradle/wrapper/." "$ROOT/gradle/wrapper/"
chmod +x "$ROOT/gradlew"

echo "BlackBox engine $COMMIT installed into project."
