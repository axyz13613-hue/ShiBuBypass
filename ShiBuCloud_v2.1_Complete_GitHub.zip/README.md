# ShiBu Cloud v2.1

ShiBu Cloud is an Android virtual-container host with a custom ShiBu UI and a foreground game keep-alive layer.

## What this version adds

- ShiBu Cloud branding, app icon and mascot UI.
- Open-source BlackBox virtual-engine integration (downloaded at build time and pinned to a fixed commit).
- Add apps/games that are already installed on the physical phone directly into ShiBu Cloud (no APK download needed).
- Install APK files into the virtual space as a fallback.
- Launch virtual apps from the ShiBu Cloud home screen.
- One-tap **Treo** mode for a selected game.
- Foreground service + PARTIAL_WAKE_LOCK + high-performance Wi-Fi lock.
- 20-second watchdog: if the selected virtual process is no longer running, ShiBu Cloud attempts to launch it again with cooldown/backoff.
- Restores treo mode after normal device boot or after the host app is updated.
- Button to request removal from Android battery optimization.
- Clear virtual app data and uninstall virtual apps from the app menu.
- ARM64 + ARMv7 builds plus a universal APK.


## Add a game that is already on your phone

1. Open ShiBu Cloud.
2. Tap **Thêm ứng dụng**.
3. Choose **Ứng dụng đã cài trên máy**.
4. Select one or more games/apps.
5. Tap **Thêm đã chọn**.
6. The selected app is installed into the virtual user with its own fresh data. The original app/data on the phone is not modified.

The picker intentionally lists normal user-installed launcher apps instead of requesting broad `QUERY_ALL_PACKAGES` access.

## Important limitation

This is a **virtual container on the phone**, not a remote cloud phone. Android, the device vendor, thermal throttling, low-memory killing, a game anti-cheat system, or an engine incompatibility can still terminate/freeze a game. The watchdog can restart a stopped virtual process, but no generic Android app can guarantee that every game will remain responsive indefinitely.

For long sessions, open **Tắt tối ưu pin** in ShiBu Cloud and allow the exemption. Also avoid Samsung Device Care putting ShiBu Cloud into Sleeping/Deep sleeping apps.

## Build on GitHub

1. Upload all files/folders from this project to a new GitHub repository.
2. Commit/push to `main` or `master`.
3. Open **Actions** → **Build ShiBu Cloud APK**.
4. Wait for the workflow to finish.
5. Download artifact **ShiBuCloud-v2.1.0**.
6. Prefer the APK whose filename contains `universal` if you are unsure which ABI to use.

The workflow automatically downloads Android SDK/NDK and the pinned BlackBox engine source.

## Local build

Requirements: Git, JDK 21, Android SDK 35, NDK `29.0.13846066`.

```bash
./tools/fetch_engine.sh
./gradlew :app:assembleDebug
```

## Engine lock

See `engine.lock` and `THIRD_PARTY_NOTICES.md`.
