package com.shibu.bypass

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL

class MainActivity : Activity() {
    private lateinit var input: EditText
    private lateinit var result: TextView
    private lateinit var progress: ProgressBar
    private lateinit var webView: WebView
    private lateinit var historyText: TextView

    private var currentWebUrl: String? = null
    private val prefs by lazy { getSharedPreferences("shibu_bypass", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handleIncomingIntent(intent)
        renderHistory()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            setBackgroundColor(Color.rgb(10, 19, 24))
        }

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
        }

        val logo = ImageView(this).apply {
            setImageResource(com.shibu.bypass.R.drawable.shibu_logo)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "ShiBu Bypass logo"
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(64), dp(64)).apply {
            marginEnd = dp(12)
        })

        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        val title = TextView(this).apply {
            text = "ShiBu Bypass"
            textSize = 25f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val subtitle = TextView(this).apply {
            text = "URL Resolver • Redirect • WebView"
            textSize = 13f
            setTextColor(Color.rgb(159, 225, 204))
            setPadding(0, dp(2), 0, 0)
        }
        brandText.addView(title)
        brandText.addView(subtitle)
        brandRow.addView(brandText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        input = EditText(this).apply {
            hint = "Dán link http/https vào đây..."
            setHintTextColor(Color.rgb(130, 139, 158))
            setTextColor(Color.WHITE)
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(31, 36, 48))
        }

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val pasteBtn = makeButton("Dán")
        val resolveBtn = makeButton("Giải redirect")
        row1.addView(pasteBtn, weightParams())
        row1.addView(resolveBtn, weightParams())

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val openBtn = makeButton("Mở trang")
        val copyBtn = makeButton("Sao chép URL")
        val clearBtn = makeButton("Xóa")
        row2.addView(openBtn, weightParams())
        row2.addView(copyBtn, weightParams())
        row2.addView(clearBtn, weightParams())

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }

        result = TextView(this).apply {
            text = "Sẵn sàng. Nhập hoặc chia sẻ một URL vào ứng dụng."
            textSize = 13f
            setTextColor(Color.rgb(215, 220, 231))
            setPadding(dp(4), dp(10), dp(4), dp(10))
        }

        historyText = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(153, 163, 184))
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }

        webView = WebView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply { topMargin = dp(6) }

            setBackgroundColor(Color.WHITE)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.userAgentString = settings.userAgentString + " ShiBuBypass/2.1"

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                }
            }

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val url = request?.url?.toString()
                    if (!url.isNullOrBlank()) updateCurrentUrl(url)
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    if (!url.isNullOrBlank()) updateCurrentUrl(url)
                }
            }
        }

        pasteBtn.setOnClickListener { pasteFromClipboard() }

        resolveBtn.setOnClickListener {
            val raw = input.text.toString().trim()
            if (!isHttpUrl(raw)) {
                showResult("URL không hợp lệ. Chỉ hỗ trợ http/https.")
                return@setOnClickListener
            }
            progress.visibility = View.VISIBLE
            progress.isIndeterminate = true
            showResult("Đang kiểm tra chuỗi redirect HTTP...")
            Thread {
                val outcome = resolveRedirects(raw)
                runOnUiThread {
                    progress.isIndeterminate = false
                    progress.visibility = View.GONE
                    currentWebUrl = outcome.finalUrl
                    showResult(outcome.message)
                    outcome.finalUrl?.let { saveHistory(it) }
                }
            }.start()
        }

        openBtn.setOnClickListener {
            val raw = input.text.toString().trim()
            if (!isHttpUrl(raw)) {
                showResult("URL không hợp lệ. Chỉ hỗ trợ http/https.")
                return@setOnClickListener
            }
            currentWebUrl = raw
            saveHistory(raw)
            webView.loadUrl(raw)
        }

        copyBtn.setOnClickListener {
            val value = currentWebUrl ?: extractUrlFromResult(result.text.toString())
            if (value.isNullOrBlank()) {
                Toast.makeText(this, "Chưa có URL để sao chép", Toast.LENGTH_SHORT).show()
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ShiBu URL", value))
                Toast.makeText(this, "Đã sao chép URL", Toast.LENGTH_SHORT).show()
            }
        }

        clearBtn.setOnClickListener {
            input.text.clear()
            currentWebUrl = null
            webView.loadUrl("about:blank")
            showResult("Đã xóa. Sẵn sàng nhận URL mới.")
        }

        root.addView(brandRow)
        root.addView(input)
        root.addView(row1)
        root.addView(row2)
        root.addView(progress)
        root.addView(result)
        root.addView(historyText)
        root.addView(webView)
        setContentView(root)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val candidate = when (intent.action) {
            Intent.ACTION_SEND -> intent.getStringExtra(Intent.EXTRA_TEXT)?.let { extractFirstHttpUrl(it) }
            Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }
        if (!candidate.isNullOrBlank() && isHttpUrl(candidate)) {
            input.setText(candidate)
            currentWebUrl = candidate
            showResult("Đã nhận URL từ Android. Bạn có thể Giải redirect hoặc Mở trang.")
        }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        val url = extractFirstHttpUrl(text)
        if (url == null) {
            Toast.makeText(this, "Clipboard không có URL http/https", Toast.LENGTH_SHORT).show()
            return
        }
        input.setText(url)
        input.setSelection(url.length)
        showResult("Đã dán URL từ clipboard.")
    }

    private fun updateCurrentUrl(url: String) {
        currentWebUrl = url
        saveHistory(url)
        showResult("URL hiện tại:\n$url")
    }

    private fun resolveRedirects(start: String): ResolveOutcome {
        var current = start
        return try {
            repeat(15) { hop ->
                val conn = (URL(current).openConnection() as HttpURLConnection).apply {
                    instanceFollowRedirects = false
                    connectTimeout = 8000
                    readTimeout = 8000
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Android) ShiBuBypass/2.1")
                    setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                }

                val code = conn.responseCode
                if (code in 300..399) {
                    val location = conn.getHeaderField("Location")
                    conn.disconnect()
                    if (location.isNullOrBlank()) {
                        return ResolveOutcome(current, "Redirect HTTP $code nhưng không có Location.\nURL gần nhất:\n$current")
                    }
                    current = URI(current).resolve(location).toString()
                } else {
                    conn.disconnect()
                    return if (code in 200..299) {
                        ResolveOutcome(
                            current,
                            "Hoàn tất sau ${hop + 1} bước kiểm tra.\nURL cuối theo HTTP redirect:\n$current\n\nNếu trang còn CAPTCHA, bộ đếm, quảng cáo bắt buộc hoặc xác minh, hãy dùng ‘Mở trang’ và tự hoàn tất bước đó."
                        )
                    } else {
                        ResolveOutcome(current, "Máy chủ trả HTTP $code.\nURL gần nhất:\n$current")
                    }
                }
            }
            ResolveOutcome(current, "Chuỗi redirect quá dài.\nURL gần nhất:\n$current")
        } catch (e: Exception) {
            ResolveOutcome(current, "Không thể giải URL: ${e.message ?: e.javaClass.simpleName}\nURL gần nhất:\n$current")
        }
    }

    private fun isHttpUrl(value: String): Boolean {
        return try {
            val uri = URI(value)
            (uri.scheme.equals("http", true) || uri.scheme.equals("https", true)) && !uri.host.isNullOrBlank()
        } catch (_: Exception) {
            false
        }
    }

    private fun extractFirstHttpUrl(text: String): String? {
        return Regex("https?://[^\\s<>'\\\"]+").find(text)?.value?.trimEnd('.', ',', ';', ')', ']')
    }

    private fun extractUrlFromResult(text: String): String? = extractFirstHttpUrl(text)

    private fun saveHistory(url: String) {
        val existing = prefs.getString("history", "").orEmpty()
            .split("\n")
            .filter { it.isNotBlank() && it != url }
            .toMutableList()
        existing.add(0, url)
        val compact = existing.take(5)
        prefs.edit().putString("history", compact.joinToString("\n")).apply()
        renderHistory()
    }

    private fun renderHistory() {
        val items = prefs.getString("history", "").orEmpty()
            .split("\n")
            .filter { it.isNotBlank() }
        historyText.text = if (items.isEmpty()) {
            "Lịch sử: chưa có URL"
        } else {
            "Gần đây: " + items.take(3).joinToString("  •  ") { compactUrl(it) }
        }
    }

    private fun compactUrl(url: String): String {
        return try {
            val u = Uri.parse(url)
            val host = u.host ?: url
            if (host.length > 26) host.take(23) + "..." else host
        } catch (_: Exception) {
            url.take(26)
        }
    }

    private fun showResult(message: String) {
        result.text = message
    }

    private fun makeButton(label: String): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(55, 65, 91))
        }
    }

    private fun weightParams(): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            setMargins(dp(3), dp(5), dp(3), 0)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    data class ResolveOutcome(val finalUrl: String?, val message: String)
}
