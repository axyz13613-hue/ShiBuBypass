plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shibu.bypass"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.shibu.bypass"
        minSdk = 21
        targetSdk = 35
        versionCode = 3
        versionName = "2.1"

        // Không có thư viện native, nên một APK có thể dùng cho ARM32/ARM64/x86/x86_64.
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}
