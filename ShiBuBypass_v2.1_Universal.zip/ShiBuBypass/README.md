# ShiBu Bypass 2.1

Android URL resolver với icon **ShiBu Bypass** riêng.

## Thay đổi trong 2.1

- Gắn avatar ShiBu Bypass làm **launcher icon** và logo trong giao diện.
- Tên hiển thị: **ShiBu Bypass**.
- Hỗ trợ Android **5.0 (API 21) trở lên**.
- Không dùng thư viện native/ABI riêng: APK tạo ra là dạng universal, dùng được trên ARM32, ARM64, x86 và x86_64 miễn là thiết bị chạy Android 5.0+.
- Bố cục co giãn cho điện thoại, tablet và màn hình lớn.
- Nhận link từ **Chia sẻ** và ACTION_VIEW.
- Dán link từ clipboard.
- Theo chuỗi HTTP 3xx redirect hợp lệ.
- WebView tích hợp, thanh tiến trình, sao chép URL và lịch sử gần đây.

## Giới hạn

Ứng dụng không tự động vượt CAPTCHA, anti-bot, bộ đếm thời gian, paywall, quảng cáo bắt buộc hoặc bước xác minh của dịch vụ rút gọn link. Với các trang đó, mở WebView và tự hoàn tất bước được yêu cầu.

## Build trên AndroidIDE

1. Giải nén thư mục `ShiBuBypass`.
2. Mở thư mục bằng AndroidIDE.
3. Cài JDK/SDK mà AndroidIDE yêu cầu.
4. Sync Gradle và chọn build APK trong AndroidIDE.
5. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Build trên Android Studio

1. Open project.
2. Chờ Gradle Sync hoàn tất.
3. Chọn **Build > Build App Bundles or APKs > Build APK(s)**.
4. APK debug nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

Khuyến nghị JDK 17.
