package com.shibu.shibu_bypass;

import java.net.URI;
import java.util.Locale;

/** Pure-Java URL policy shared by the Android WebView and automated tests. */
public final class NavigationPolicy {
    private NavigationPolicy() {}

    private static String hostOf(String url) {
        try {
            String host = new URI(url).getHost();
            if (host == null) return null;
            host = host.toLowerCase(Locale.ROOT);
            if (host.startsWith("www.")) host = host.substring(4);
            return host;
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String pathOf(String url) {
        try {
            String path = new URI(url).getPath();
            return path == null ? "" : path.toLowerCase(Locale.ROOT);
        } catch (Exception ignored) {
            return "";
        }
    }

    public static boolean isHttpUrl(String url) {
        try {
            String scheme = new URI(url).getScheme();
            return scheme != null && (scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https"));
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean isLink4m(String url) {
        String host = hostOf(url);
        if (host == null) return false;
        return host.equals("link4m.org") || host.endsWith(".link4m.org") ||
               host.equals("link4m.net") || host.endsWith(".link4m.net");
    }

    public static boolean isVerificationUrl(String url) {
        String host = hostOf(url);
        if (host == null) return false;
        String path = pathOf(url);
        if ((host.equals("google.com") || host.endsWith(".google.com")) && path.contains("/recaptcha/")) return true;
        if (host.equals("recaptcha.net") || host.endsWith(".recaptcha.net")) return true;
        if (host.equals("gstatic.com") || host.endsWith(".gstatic.com")) return true;
        if (host.equals("hcaptcha.com") || host.endsWith(".hcaptcha.com")) return true;
        return host.equals("challenges.cloudflare.com");
    }

    /** Candidate only means the browser has left Link4m/verification; it does not skip any gate. */
    public static boolean isFinalCandidate(String url) {
        return isHttpUrl(url) && !isLink4m(url) && !isVerificationUrl(url);
    }
}
