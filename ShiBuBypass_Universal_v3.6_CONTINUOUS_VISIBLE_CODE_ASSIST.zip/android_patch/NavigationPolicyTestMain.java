package com.shibu.shibu_bypass;

public final class NavigationPolicyTestMain {
    private static void expect(boolean value, String label) {
        if (!value) throw new AssertionError(label);
    }

    public static void main(String[] args) {
        expect(NavigationPolicy.isLink4m("https://link4m.org/uuTLBV"), "org short link");
        expect(NavigationPolicy.isLink4m("https://link4m.org/go/uuTLBV"), "org /go link");
        expect(NavigationPolicy.isLink4m("https://link4m.net/go/3LJQIbCU"), "net video link");
        expect(!NavigationPolicy.isFinalCandidate("https://link4m.org/go/uuTLBV"), "intermediate not final");
        expect(!NavigationPolicy.isFinalCandidate("https://www.google.com/recaptcha/api2/anchor"), "recaptcha not final");
        expect(NavigationPolicy.isFinalCandidate("https://ronnei.github.io/skibidi/cloverfreekey.html"), "known destination final");
        expect(NavigationPolicy.isFinalCandidate("https://example.com/final"), "ordinary destination final");
        expect(!NavigationPolicy.isFinalCandidate("javascript:alert(1)"), "non-http rejected");
        System.out.println("NavigationPolicy tests: PASS");
    }
}
