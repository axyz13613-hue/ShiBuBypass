package com.shibu.shibu_bypass

import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.platform.PlatformView

/**
 * Direct android.webkit.WebView embedded inside Flutter through PlatformView.
 * It never solves/automates verification. It simply keeps one browser session
 * alive so user-driven CAPTCHA/timer/form steps and the site's own redirects
 * can continue without returning to the HTTP resolver screen.
 */
class NativeInlineWebView(
    context: Context,
    viewId: Int,
    params: Map<String, Any?>,
    messenger: BinaryMessenger
) : PlatformView {
    private val root = FrameLayout(context)
    private val mainWebView = WebView(context)
    private var popupWebView: WebView? = null
    private val channel = MethodChannel(messenger, "shibu/native_inline_webview/$viewId")

    init {
        root.setBackgroundColor(android.graphics.Color.WHITE)
        configure(mainWebView)
        root.addView(
            mainWebView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        channel.setMethodCallHandler { call, result ->
            when (call.method) {
                "back" -> {
                    val active = activeWebView()
                    when {
                        active.canGoBack() -> active.goBack()
                        popupWebView != null -> closePopup()
                    }
                    result.success(null)
                }
                "forward" -> {
                    val active = activeWebView()
                    if (active.canGoForward()) active.goForward()
                    result.success(null)
                }
                "reload" -> {
                    activeWebView().reload()
                    result.success(null)
                }
                "currentUrl" -> result.success(activeWebView().url)
                "fillVisibleCode" -> fillVisibleCode(activeWebView(), result)
                else -> result.notImplemented()
            }
        }

        val startUrl = params["url"] as? String
        if (startUrl != null && NavigationPolicy.isHttpUrl(startUrl)) {
            // Exact browser navigation. No HEAD preflight, no form replay, no
            // private endpoint/token extraction, and no verification automation.
            mainWebView.loadUrl(startUrl)
        } else {
            channel.invokeMethod("mainFrameError", "URL http/https không hợp lệ")
        }
    }

    private fun activeWebView(): WebView = popupWebView ?: mainWebView

    private fun emitNavigation(view: WebView?, url: String?, phase: String) {
        if (url.isNullOrBlank() || !NavigationPolicy.isHttpUrl(url)) return
        val isPopup = view != null && view !== mainWebView
        channel.invokeMethod(
            "navigationEvent",
            mapOf("url" to url, "phase" to phase, "isPopup" to isPopup)
        )
    }

    private fun emitUrl(url: String?) {
        if (url.isNullOrBlank() || !NavigationPolicy.isHttpUrl(url)) return
        channel.invokeMethod("urlChanged", url)
    }

    private fun configure(target: WebView) {
        target.setBackgroundColor(android.graphics.Color.WHITE)
        target.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = false
            cacheMode = WebSettings.LOAD_DEFAULT
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            // Keep Android WebView's stock UA. Appending a custom UA can make
            // anti-bot/browser compatibility logic behave differently.
        }

        CookieManager.getInstance().setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(target, true)
        }

        target.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (view === activeWebView()) channel.invokeMethod("progress", newProgress)
            }

            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val transport = resultMsg?.obj as? WebView.WebViewTransport ?: return false
                closePopup(restoreMain = false)
                val popup = WebView(target.context)
                popupWebView = popup
                configure(popup)
                mainWebView.visibility = View.GONE
                root.addView(
                    popup,
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                transport.webView = popup
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) {
                if (window != null && window === popupWebView) closePopup()
            }
        }

        target.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (!NavigationPolicy.isHttpUrl(url)) return true
                emitNavigation(view, url, "override")
                return false
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                if (url.isNullOrBlank()) return false
                if (!NavigationPolicy.isHttpUrl(url)) return true
                emitNavigation(view, url, "override")
                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                emitNavigation(view, url, "started")
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                emitNavigation(view, url, "commit")
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                emitNavigation(view, url, "finished")
                CookieManager.getInstance().flush()
                detectVerificationUi(view)
                // Safe convenience: some pages render a code into visible DOM a little
                // after load. Retry a few times and fill it only if it is already visible.
                scheduleVisibleCodeAssist(view)
                installVisibleCodeObserver(view)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                emitNavigation(view, url, "history")
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    val description = error?.description?.toString() ?: "Lỗi tải main frame"
                    channel.invokeMethod("mainFrameError", description)
                }
            }
        }
    }


    /**
     * Detects whether the currently rendered page visibly contains a manual
     * verification gate. This only reports UI state to Flutter; it never
     * clicks, fills, solves, submits, or extracts CAPTCHA/verification data.
     */
    private fun detectVerificationUi(view: WebView?) {
        val webView = view ?: return
        val script = """
            (function() {
              try {
                var text = (document.body && document.body.innerText || '').toLowerCase();
                var hasCaptcha = !!document.querySelector(
                  '.g-recaptcha, [data-sitekey], iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="challenges.cloudflare.com"]'
                );
                var hasCodeInput = !!document.querySelector(
                  'input[placeholder*="mã" i], input[name*="code" i], input[id*="code" i], input[name*="captcha" i]'
                );
                var hasWords = text.indexOf('tôi không phải là người máy') >= 0 ||
                  text.indexOf('vui lòng nhập mã') >= 0 ||
                  text.indexOf('captcha') >= 0 ||
                  text.indexOf('xác minh') >= 0 ||
                  text.indexOf('verification') >= 0;
                return !!(hasCaptcha || (hasCodeInput && hasWords));
              } catch (e) {
                return false;
              }
            })();
        """.trimIndent()
        webView.evaluateJavascript(script) { raw ->
            val detected = raw == "true"
            channel.invokeMethod("verificationState", detected)
        }
    }



    /**
     * Retries the visible-code convenience after dynamic page rendering. This does not
     * search external pages, read hidden fields, click/submit forms, or interact with
     * CAPTCHA. It only fills an empty code field from text visibly rendered in this page.
     */
    private fun scheduleVisibleCodeAssist(view: WebView?) {
        val webView = view ?: return
        val delays = longArrayOf(350L, 900L, 1800L, 3200L)
        delays.forEach { delayMs ->
            webView.postDelayed({
                if (webView === activeWebView()) {
                    fillVisibleCodeInternal(webView) { json ->
                        try {
                            val obj = org.json.JSONObject(json)
                            if (obj.optBoolean("ok", false)) {
                                channel.invokeMethod("visibleCodeAssist", json)
                            }
                        } catch (_: Exception) { }
                    }
                }
            }, delayMs)
        }
    }


    /**
     * Keeps Visible Code Assist active while the user completes manual steps.
     * It watches DOM mutations only inside the current page and fills only a
     * visibly rendered code into an empty visible code field. It never submits,
     * clicks, reads hidden values, opens search instructions, or touches CAPTCHA.
     */
    private fun installVisibleCodeObserver(view: WebView?) {
        val webView = view ?: return
        val script = """
            (function() {
              try {
                if (window.__shibuVisibleCodeObserverInstalled) return true;
                window.__shibuVisibleCodeObserverInstalled = true;

                function visible(el) {
                  if (!el) return false;
                  var st = window.getComputedStyle(el);
                  return st && st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0' && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
                }
                function clean(v) { return (v || '').replace(/\s+/g, ' ').trim(); }
                function tryFill() {
                  try {
                    var input = document.querySelector('input[placeholder*="mã" i], input[name*="code" i], input[id*="code" i], input[name*="key" i], input[id*="key" i]');
                    if (!input || !visible(input) || clean(input.value)) return false;
                    var rx = /(?:mã|code|key)\s*[:=-]?\s*([A-Za-z0-9_-]{4,32})/i;
                    var nodes = Array.prototype.slice.call(document.querySelectorAll('p,div,span,strong,b,code,pre,li,td,label'));
                    for (var i = 0; i < nodes.length; i++) {
                      var el = nodes[i];
                      if (!visible(el)) continue;
                      var txt = clean(el.innerText || el.textContent || '');
                      if (!txt || txt.length > 220) continue;
                      var m = txt.match(rx);
                      if (m && m[1]) {
                        input.focus();
                        input.value = m[1];
                        input.dispatchEvent(new Event('input', {bubbles:true}));
                        input.dispatchEvent(new Event('change', {bubbles:true}));
                        return true;
                      }
                    }
                  } catch (_) {}
                  return false;
                }

                var timer = null;
                var observer = new MutationObserver(function() {
                  clearTimeout(timer);
                  timer = setTimeout(function() { tryFill(); }, 180);
                });
                var root = document.documentElement || document.body;
                if (root) observer.observe(root, {subtree:true, childList:true, characterData:true});
                tryFill();
                return true;
              } catch (e) { return false; }
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    private fun visibleCodeScript(): String = """
            (function() {
              try {
                var input = document.querySelector(
                  'input[placeholder*="mã" i], input[name*="code" i], input[id*="code" i], input[name*="key" i], input[id*="key" i]'
                );
                if (!input) return JSON.stringify({ok:false, reason:'no_input'});
                if ((input.value || '').trim()) return JSON.stringify({ok:false, reason:'already_filled'});

                function visible(el) {
                  if (!el) return false;
                  var st = window.getComputedStyle(el);
                  return st && st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0' && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
                }
                function clean(v) { return (v || '').replace(/\s+/g, ' ').trim(); }
                var rx = /(?:mã|code|key)\s*[:=-]?\s*([A-Za-z0-9_-]{4,32})/i;
                var nodes = Array.prototype.slice.call(document.querySelectorAll('p,div,span,strong,b,code,pre,li,td,label'));
                var candidate = '';
                for (var i = 0; i < nodes.length; i++) {
                  var el = nodes[i];
                  if (!visible(el)) continue;
                  var txt = clean(el.innerText || el.textContent || '');
                  if (!txt || txt.length > 220) continue;
                  var m = txt.match(rx);
                  if (m && m[1]) { candidate = m[1]; break; }
                }
                if (!candidate) return JSON.stringify({ok:false, reason:'not_visible'});
                input.focus();
                input.value = candidate;
                input.dispatchEvent(new Event('input', {bubbles:true}));
                input.dispatchEvent(new Event('change', {bubbles:true}));
                return JSON.stringify({ok:true, code:candidate});
              } catch (e) {
                return JSON.stringify({ok:false, reason:'error'});
              }
            })();
        """.trimIndent()

    private fun fillVisibleCodeInternal(webView: WebView, done: (String) -> Unit) {
        webView.evaluateJavascript(visibleCodeScript()) { raw ->
            val decoded = try {
                org.json.JSONTokener(raw).nextValue() as? String ?: raw
            } catch (_: Exception) { raw }
            done(decoded)
        }
    }

    /**
     * Convenience only: if the current page itself visibly displays a code/key
     * next to words such as "mã", "code" or "key", copy that already-rendered
     * value into an empty code input. It never reads hidden fields, never follows
     * keyword/search instructions, never submits a form and never touches CAPTCHA.
     */
    private fun fillVisibleCode(webView: WebView, result: MethodChannel.Result) {
        fillVisibleCodeInternal(webView) { decoded -> result.success(decoded) }
    }

    private fun closePopup(restoreMain: Boolean = true) {
        val popup = popupWebView ?: return
        popupWebView = null
        try {
            root.removeView(popup)
            popup.stopLoading()
            popup.destroy()
        } catch (_: Exception) {
        }
        if (restoreMain) {
            mainWebView.visibility = View.VISIBLE
            emitNavigation(mainWebView, mainWebView.url, "popupClosed")
        }
    }

    override fun getView(): View = root

    override fun dispose() {
        channel.setMethodCallHandler(null)
        popupWebView?.let { popup ->
            try {
                root.removeView(popup)
                popup.stopLoading()
                popup.destroy()
            } catch (_: Exception) {
            }
        }
        popupWebView = null
        try {
            root.removeView(mainWebView)
            mainWebView.stopLoading()
            mainWebView.destroy()
        } catch (_: Exception) {
        }
    }
}
