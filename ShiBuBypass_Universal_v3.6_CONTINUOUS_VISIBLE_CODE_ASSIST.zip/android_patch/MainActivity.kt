package com.shibu.shibu_bypass

import android.content.Intent
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val shareChannelName = "shibu/share"
    private var pendingSharedText: String? = null
    private var shareChannel: MethodChannel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        captureShare(intent, notifyFlutter = false)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        captureShare(intent, notifyFlutter = true)
    }

    private fun captureShare(intent: Intent?, notifyFlutter: Boolean) {
        val type = intent?.type ?: return
        if (intent.action == Intent.ACTION_SEND && type.startsWith("text/")) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!text.isNullOrBlank()) {
                pendingSharedText = text
                if (notifyFlutter) shareChannel?.invokeMethod("sharedText", text)
            }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        shareChannel = MethodChannel(flutterEngine.dartExecutor.binaryMessenger, shareChannelName)
        shareChannel?.setMethodCallHandler { call, result ->
            if (call.method == "getSharedText") {
                val text = pendingSharedText
                pendingSharedText = null
                result.success(text)
            } else {
                result.notImplemented()
            }
        }

        flutterEngine.platformViewsController.registry.registerViewFactory(
            "shibu/native_inline_webview",
            NativeInlineWebViewFactory(flutterEngine.dartExecutor.binaryMessenger)
        )
    }
}
