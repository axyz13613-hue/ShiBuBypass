# ShiBu Bypass Universal v3.6

Cross-platform URL resolver / redirect inspector / WebView helper.

## v3.6 WebView-first

- Trang trung gian cần thao tác được ưu tiên mở **ngay trong ShiBu WebView**.
- WebView bắt đầu từ **URL gốc người dùng dán**, không nhảy thẳng vào `/go/...`; cách này giúp website tự tạo đúng cookie/session qua chuỗi GET và redirect bình thường.
- Giữ JavaScript và phiên WebView trong cùng màn hình; không tự lặp lại POST khi gặp `ERR_CACHE_MISS`.
- Nếu có `ERR_CACHE_MISS`, nút chính chạy lại **từ link gốc** trong cùng WebView thay vì resubmit POST cũ.
- Sau khi người dùng hoàn thành bước xác minh bắt buộc và URL thật sự chuyển tiếp, ShiBu có thể nhận URL mới, tiếp tục redirect và sao chép URL cuối.
- Chrome là phương án dự phòng khi WebView thật sự không tải được; Android Share vẫn được hỗ trợ để đưa URL trở lại ShiBu.

## Giới hạn

ShiBu chỉ xử lý redirect và theo dõi URL. CAPTCHA/reCAPTCHA, anti-bot, timer/quảng cáo bắt buộc, đăng nhập và hệ thống cấp key phải được hoàn thành theo cơ chế của website.

## v3.6 Native Popup Final (build 40)

- Không còn coi Android WebView error code `-12` là `ERR_CACHE_MISS`; `-12` là lỗi URL xấu.
- Bỏ qua lỗi tài nguyên phụ (`iframe`, ảnh, font, quảng cáo, tracker) khi main frame vẫn dùng được.
- Thẻ lỗi chỉ xuất hiện với lỗi main frame và hiển thị mã/loại/URL lỗi thật để chẩn đoán.
- Bật third-party cookies trên Android WebView trước request đầu tiên để giữ tốt hơn các phiên nhiều domain.
- Cho phép các scheme nội bộ `about:`, `data:`, `blob:` trong WebView; vẫn chặn `file:`, `content:` và scheme ngoài không rõ.
- Không biến trang POST hiện tại thành GET khi bấm retry; nút retry luôn chạy lại từ URL gốc trong cùng cookie jar.
- CAPTCHA/anti-bot/timer/login/xác minh bắt buộc vẫn do người dùng hoàn thành thủ công.


## Kotlin compile patch

- Fixed `WebChromeClient.onProgressChanged()` scope so the native `ProgressBar` compiles correctly on Android.
- Visible app version remains **3.6.0**; build number is **40**.

## Android Native FIX

Android mở các trang cần xác minh bằng `android.webkit.WebView` native thông qua MethodChannel. Native WebView để website tự quản lý redirect, cookie, session và form POST; ShiBu không tự giải CAPTCHA/anti-bot/timer/ads/key gate. Người dùng hoàn thành các bước bắt buộc trên trang. Khi main-frame thực sự rời `link4m.org` sang một URL HTTP/HTTPS khác và trang đó ổn định, Native WebView tự trả URL về Flutter sau một khoảng trễ ngắn. Nút **Dùng URL này** vẫn được giữ làm phương án thủ công. Việc tự nhận URL không giải CAPTCHA/anti-bot/timer/login và không bỏ qua bước xác minh bắt buộc.


## Auto Final URL

- Chỉ tự nhận sau khi **top-level page** đã tải xong và URL ổn định khoảng 1.2 giây.
- Không tự trả các URL còn thuộc `link4m.org`.
- Bỏ qua các URL reCAPTCHA/hCaptcha/Cloudflare verification phổ biến để tránh nhận nhầm trang xác minh.
- Nếu trang đích không được nhận tự động, nút **Dùng URL này** vẫn hoạt động như trước.


## v3.6 Native Video Mode (build 42)
- Mục tiêu: hành vi giống bản trong video tham chiếu: giữ WebView mở và hiển thị URL hiện tại trong suốt chuỗi điều hướng.
- Android dùng android.webkit.WebView native để giữ cookie, session, JavaScript, POST/form navigation và popup/new-window.
- Không tự đóng WebView khi gặp domain khác; người dùng hoàn thành thủ công CAPTCHA/timer/xác minh nếu website yêu cầu, sau đó chọn “Dùng URL này” khi đã tới trang đích.
- Không tự động giải hoặc bỏ qua CAPTCHA/anti-bot/access gate.


## v3.6 +47 — Visible Code Assist
- Adds a WebView toolbar action to fill a code only when that code is already visibly rendered on the current page.
- Does not inspect hidden fields, follow keyword/search instructions, submit forms, solve CAPTCHA, or bypass verification.
- Keeps Post Verify Capture behavior for the final main-frame URL.


## v3.6 +48 Visible Code Assist Analyzer Fix
- Fixes Flutter analyzer compile error by importing dart:convert for jsonDecode used by Visible Code Assist.
- Keeps existing manual CAPTCHA/verification flow unchanged.


## v3.6 +49 Visible Code Assist Auto Retry
- Automatically retries visible-code assist after dynamic page rendering.
- Fills only a code already visibly rendered in the current page into an empty code field.
- Never searches keyword instructions, reads hidden fields, submits forms, or interacts with CAPTCHA.
- CAPTCHA/identity verification remains manual; final main-frame URL capture remains automatic.


## v3.6 +50 Continuous Visible Code Assist
- Keeps visible-code detection active while the user completes manual verification steps.
- Uses a DOM MutationObserver on the current page to fill only an already-visible code into an empty visible code field.
- Never submits forms, clicks continue, reads hidden values, follows keyword/search instructions, or automates CAPTCHA.
- Final URL capture remains main-frame-only after the site legitimately redirects away.
