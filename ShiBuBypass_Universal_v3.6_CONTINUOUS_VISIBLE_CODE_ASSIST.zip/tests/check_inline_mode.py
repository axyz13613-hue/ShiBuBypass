from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / "lib" / "main.dart").read_text()
native = (root / "android_patch" / "NativeInlineWebView.kt").read_text()
activity = (root / "android_patch" / "MainActivity.kt").read_text()

checks = {
    "inline AndroidView exists": "viewType: _nativeInlineWebViewType" in main,
    "Link4m .org supported": "h == 'link4m.org'" in main,
    "Link4m .net supported": "h == 'link4m.net'" in main,
    "resolve opens WebView first": "if (_shouldUseInlineWebViewFirst(start))" in main,
    "paste opens WebView first": "if (_shouldUseInlineWebViewFirst(parsed))" in main,
    "native view registered": 'registerViewFactory(' in activity and 'shibu/native_inline_webview' in activity,
    "stock UA preserved": 'userAgentString =' not in native,
    "third-party cookies enabled": "setAcceptThirdPartyCookies(target, true)" in native,
    "popup supported": "onCreateWindow" in native,
    "verification UI detection event": 'verificationState' in native and 'detectVerificationUi' in native,
    "auto captures final URL": "Đã bắt và sao chép URL đích" in main and "_capturedFinalUrl" in main,
    "no CAPTCHA automation hooks": all(x not in native.lower() for x in ["grecaptcha.execute", "captcha token", "recaptcha token", ".click()", "dispatchEvent"]),
}
failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)
if failed:
    raise SystemExit("Static checks failed: " + ", ".join(failed))
