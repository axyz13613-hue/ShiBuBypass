#!/usr/bin/env python3
import re
import subprocess
import time
import xml.etree.ElementTree as ET

PKG = "com.shibu.shibu_bypass"
ACT = f"{PKG}/.{ 'MainActivity' }"
TEST_URL = "https://link4m.org/go/uuTLBV"


def sh(*args, check=True):
    p = subprocess.run(args, text=True, capture_output=True)
    if check and p.returncode != 0:
        raise RuntimeError(f"command failed: {' '.join(args)}\n{p.stdout}\n{p.stderr}")
    return p.stdout + p.stderr


def dump_xml():
    sh("adb", "shell", "uiautomator", "dump", "/sdcard/window.xml")
    xml = sh("adb", "shell", "cat", "/sdcard/window.xml")
    start = xml.find("<?xml")
    if start >= 0:
        xml = xml[start:]
    return xml


def center(bounds):
    nums = list(map(int, re.findall(r"\d+", bounds)))
    if len(nums) != 4:
        raise ValueError(bounds)
    x1, y1, x2, y2 = nums
    return (x1 + x2) // 2, (y1 + y2) // 2


def tap_text(label):
    xml = dump_xml()
    root = ET.fromstring(xml)
    for node in root.iter("node"):
        text = node.attrib.get("text", "")
        desc = node.attrib.get("content-desc", "")
        if label in text or label in desc:
            x, y = center(node.attrib["bounds"])
            sh("adb", "shell", "input", "tap", str(x), str(y))
            return
    raise AssertionError(f"Không tìm thấy nút/text {label!r} trong UI dump")


# Start with the same Link4m URL through Android's share intent. This only
# populates the app; it does not automate any CAPTCHA/timer/verification step.
sh("adb", "shell", "am", "force-stop", PKG)
sh(
    "adb", "shell", "am", "start",
    "-a", "android.intent.action.SEND",
    "-t", "text/plain",
    "--es", "android.intent.extra.TEXT", TEST_URL,
    "-n", ACT,
)
time.sleep(3)

# The regression being fixed: Resolve on Link4m must open the inline native
# WebView instead of stopping at an HTTP-200 resolver card.
tap_text("Giải redirect")
time.sleep(5)
# Inline panel sits below the status card; scroll it into the viewport.
for _ in range(3):
    sh("adb", "shell", "input", "swipe", "500", "1600", "500", "450", "500")
    time.sleep(0.8)
xml = dump_xml()
if "ShiBu Native WebView" not in xml:
    raise AssertionError("Inline native WebView panel did not appear after Resolve")

# Ensure the app stayed alive and no package crash was recorded.
resumed = sh("adb", "shell", "dumpsys", "activity", "activities")
if PKG not in resumed:
    raise AssertionError("ShiBu activity is not present after opening inline WebView")
crash = sh("adb", "logcat", "-d", "-b", "crash", check=False)
if PKG in crash and "FATAL EXCEPTION" in crash:
    raise AssertionError("Crash log contains a fatal exception for ShiBu")

print("Android inline WebView runtime smoke test: PASS")
