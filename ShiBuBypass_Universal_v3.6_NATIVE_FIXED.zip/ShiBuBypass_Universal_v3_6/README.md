# ShiBu Bypass Universal v3.6

Cross-platform URL resolver / redirect inspector / WebView helper.

## v3.6 WebView-first

- Trang trung gian cần thao tác được ưu tiên mở **ngay trong ShiBu WebView**.
- WebView bắt đầu từ **URL gốc người dùng dán**, không nhảy thẳng vào `/go/...`; cách này giúp website tự tạo đúng cookie/session qua chuỗi GET và redirect bình thường.
- Giữ JavaScript và phiên WebView trong cùng màn hình; không tự lặp lại POST khi gặp `ERR_CACHE_MISS`.
- Nếu có `ERR_CACHE_MISS`, nút chính chạy lại **từ link gốc** trong cùng WebView thay vì resubmit POST cũ.
- Sau khi người dùng hoàn thành bước xác minh bắt buộc và URL thật sự chuyển tiếp, ShiBu có thể nhận URL mới, tiếp tục redirect và sao chép URL cuối.
- Chrome là phương án dự phòng khi WebView thật sự không tải được; Android Share vẫn được hỗ trợ để đưa URL trở lại ShiBu.

## Giới hạn

ShiBu chỉ xử lý redirect và theo dõi URL. CAPTCHA/reCAPTCHA, anti-bot, timer/quảng cáo bắt buộc, đăng nhập và hệ thống cấp key phải được hoàn thành theo cơ chế của website.

## v3.6 Native FIX (build 37)

- Không còn coi Android WebView error code `-12` là `ERR_CACHE_MISS`; `-12` là lỗi URL xấu.
- Bỏ qua lỗi tài nguyên phụ (`iframe`, ảnh, font, quảng cáo, tracker) khi main frame vẫn dùng được.
- Thẻ lỗi chỉ xuất hiện với lỗi main frame và hiển thị mã/loại/URL lỗi thật để chẩn đoán.
- Bật third-party cookies trên Android WebView trước request đầu tiên để giữ tốt hơn các phiên nhiều domain.
- Cho phép các scheme nội bộ `about:`, `data:`, `blob:` trong WebView; vẫn chặn `file:`, `content:` và scheme ngoài không rõ.
- Không biến trang POST hiện tại thành GET khi bấm retry; nút retry luôn chạy lại từ URL gốc trong cùng cookie jar.
- CAPTCHA/anti-bot/timer/login/xác minh bắt buộc vẫn do người dùng hoàn thành thủ công.


## Android Native FIX

Android mở các trang cần xác minh bằng `android.webkit.WebView` native thông qua MethodChannel. Native WebView để website tự quản lý redirect, cookie, session và form POST; ShiBu không tự giải CAPTCHA/anti-bot/timer/ads/key gate. Người dùng hoàn thành các bước bắt buộc trên trang và bấm **Dùng URL này** để trả URL hiện tại về Flutter.
